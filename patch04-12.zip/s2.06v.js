// Pressure from the hall.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'visitor', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '2.2',
  actors: { maya: 'counter', visitor: 'exit', omar: 'colleague' },
  shots: [[0,'hall'], [S(1),'counter'], [S(3),'her'], [S(6),'counter'], [S(10),'file'], [S(11),'staff'], [S(12),'counter'], [S(13),'hall'], [S(14),'her']],
  walks: { visitor: [[S(1),E(1),'visitor'], [S(12),E(12),'exit']] },
  leave: { visitor: E(12) },
  file: [],
  landline: true,
  actions: {
    visitor: [[S(2),E(3),'talk','maya'], [S(4),S(12),'listen','maya']],
    maya: [[S(1),S(10),'listen','visitor'], [S(10),S(11),'file'], [S(11),E(12),'extension'], [S(14),D.T,'type']],
    omar: [[S(1),S(13),'listen','maya']],
  },
  displays: { counter: [[S(11),E(12),'mobile','Internal directory','safe']] },
  plates: [[S(2),E(2),'Full case file requested'], [S(3),E(3),'The official is waiting'], [S(10),E(10),'File stays closed'], [S(12),E(12),'No release authorised']],
  pages: [
    hero(S(6), S(7), 'Authority + urgency = pause', 'made/id_badge+clock', [
      ['Claimed authority', S(6), 'v-amber'],
    ]),
    hero(S(7), S(10), 'Pressure is a warning sign', 'clock+made/case_folder', [
      ['Demand for immediate release', S(7), 'v-amber'],
    ]),
    hero((S(11)+E(11))/2, S(12), 'Verify through a known contact', 'made/register_book+mobile', [
      ['Hamad’s internal extension', S(11), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Report through the approved route', 'clock+file-text+bell', [
      ['Time and description', S(14), 'v-teal'],
    ]),
  ],
}));
