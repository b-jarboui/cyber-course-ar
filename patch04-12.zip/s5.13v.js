// Polished is not proven.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['omar', 'maya', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '5.3',
  actors: { omar: 'desk', maya: 'beside', official: 'deskGuest' },
  enter: { official: S(12) },
  shots: [[0, 'desk'], [S(2), 'display'], [S(3), 'pair'], [S(8), 'display'], [S(9), 'pair'], [S(12), 'pair'], [S(14), 'desk']],
  actions: {
    omar: [[0, S(2), 'type'], [S(2), S(3), 'read'], [S(3), S(8), 'listen', 'maya'], [S(8), S(11), 'read'], [S(11), S(12), 'type'], [S(12), D.T, 'listen', 'official']],
    maya: [[0, S(3), 'listen', 'omar'], [S(3), S(4), 'talk', 'omar'], [S(4), S(8), 'listen', 'omar'], [S(8), S(11), 'read'], [S(11), S(12), 'listen', 'omar'], [S(12), D.T, 'listen', 'official']],
    official: [[S(12), S(14), 'paper'], [S(14), D.T, 'talk', 'omar']],
  },
  displays: {
    desk: [
      [0, S(2), 'computer', 'Pending requests table', 'neutral'],
      [S(2), S(9), 'file-text', 'AI summary report', 'neutral'],
      [S(9), S(11), 'zoom', 'Figures do not match', 'alert'],
      [S(11), D.T, 'tick', 'Figures verified', 'safe'],
    ],
  },
  plates: [
    [S(2), E(2), 'One-page AI report'],
    [S(9), E(9), 'Figures do not match'],
    [S(11), E(11), 'AI assistance noted'],
    [S(12), E(12), 'Reviewed by Hamad'],
  ],
  pages: [
    hero(S(4), S(6), 'Check the input data', 'folder+zoom+shield', [
      ['Wrong input leads to wrong results', S(4), 'v-amber'],
      ['Quick review catches hidden errors', S(5), 'v-teal'],
    ]),
    hero(S(6), S(8), 'A second person reviews', 'made/id_badge+file-text+tick', [
      ['Human review for official work', S(7), 'v-teal'],
    ]),
    hero(S(9), S(12), 'Recalculate key figures', 'made/balance_scale+file-text', [
      ['Check arithmetic against the source', S(9), 'v-coral'],
      ['Unsupported reasons are guesses', S(10), 'v-amber'],
    ]),
    hero(S(13), D.T, 'Say that AI helped', 'file-text+made/rubber_stamp+bell', [
      ['Trace every claim to evidence', S(13), 'v-teal'],
      ['Strange results? Stop and report', S(16), 'v-amber'],
    ]),
  ],
}));
