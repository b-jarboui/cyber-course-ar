// A photo of a moment that never happened
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["lena", "maya", "omar", "citizen"];
export default chapterHall((S, E, D) => ({
  lesson: "3.2",
  actors: { lena: 'exit', maya: 'counter', omar: 'colleague', citizen: 'door' },
  walks: { lena: [[S(0),E(0),'visitor']] }, enter: { citizen: D.T },
  shots: [[0,'hall'], [S(1),'counter'], [S(3),'her'], [S(11),'gathering'], [S(14),'counter'], [S(15),'her']],
  actions: { lena: [[S(1),S(11),'text'], [S(11),S(13),'talk','omar'], [S(13),S(15),'text']], maya: [[0,S(3),'listen','lena'], [S(3),E(3),'talk','lena'], [S(11),S(14),'listen','lena'], [S(14),D.T,'type']], omar: [[0,S(11),'listen','lena'], [S(11),E(11),'text'], [S(12),D.T,'listen','maya']] },
  setupProps: evidence({
    surfaces: { 'phone:lena': [[S(1),S(2),'counterPhoto','Shared photo'], [S(2),S(11),'counterVideo','Shared video']] },
    inserts: [[S(1),E(2),'phone:lena']],
  }),
  plates: [[S(1),E(1),'Shared photo'], [S(2),E(2),'Shared video'], [S(3),E(3),'It never happened']],
  pages: [
    hero(S(4), S(5), "Deepfake: realistic but false images, video or audio", "mobile+made/headset", [
      ["Shared photo", S(4), "v-navy"],
    ]),
    hero(S(5), S(11), "Seeing is not proof", "mobile+made/laptop", [
      ["Views and reshares", S(6), "v-amber"],
    ]),
    hero(S(12), S(15), "Don't share; check the source and report", "mobile+link", [
      ["Save the link and time", S(14), "v-teal"],
    ]),
  ],
}));
