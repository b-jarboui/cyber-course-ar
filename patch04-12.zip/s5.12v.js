// Sure of itself, and wrong.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '5.3',
  actors: { omar: 'desk', maya: 'aisle' },
  walks: { maya: [[S(3), E(3), 'beside']] },
  shots: [[0, 'desk'], [S(2), 'display'], [S(3), 'pair'], [S(11), 'display'], [S(12), 'pair'], [S(14), 'desk']],
  actions: {
    omar: [[0, S(2), 'type'], [S(2), S(3), 'read'], [S(3), S(4), 'listen', 'maya'], [S(4), S(12), 'read'], [S(12), D.T, 'type']],
    maya: [[S(3), S(4), 'talk', 'omar'], [S(4), S(11), 'listen', 'omar'], [S(11), S(12), 'read'], [S(12), D.T, 'listen', 'omar']],
  },
  displays: {
    desk: [
      [0, S(2), 'computer', 'Approved AI assistant', 'neutral'],
      [S(2), S(11), 'file-text', 'Unverified circular', 'alert'],
      [S(11), D.T, 'tick', 'Official register', 'safe'],
    ],
  },
  plates: [
    [S(2), E(2), 'Tidy AI note'],
    [S(3), E(3), 'Where is this circular?'],
    [S(11), E(11), 'Circular not found'],
    [S(12), E(12), 'Rewritten from official text'],
  ],
  pages: [
    hero(S(4), S(6), 'AI hallucination', 'computer+file-text', [
      ['Invented facts, references or quotes', S(4), 'v-coral'],
    ]),
    hero(S(6), S(11), 'Confident does not mean correct', 'made/register_book+zoom', [
      ['Smooth wording can hide fake citations', S(8), 'v-amber'],
      ['Check for inaccuracy and bias', S(10), 'v-teal'],
    ]),
    hero(S(13), S(14), 'A draft, not a source', 'file-text+tools', [
      ['Verify before copying or sending', S(13), 'v-teal'],
    ]),
    hero(S(14), D.T, 'Check numbers, names and quotes', 'zoom+made/register_book+bell', [
      ['Cannot find it? Do not use it', S(15), 'v-amber'],
      ['Error sent out? Report at once', S(16), 'v-coral'],
    ]),
  ],
}));
