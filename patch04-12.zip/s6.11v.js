// An assistant answers, an agent acts.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['admin', 'official', 'maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '6.4',
  actors: { admin: 'team', official: 'director', maya: 'counter', omar: 'colleague' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'gathering'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'her'], [S(9), 'counterDisplay'], [S(10), 'gathering'], [S(14), 'counter']],
  actions: {
    admin: [[0, S(2), 'talk', 'maya'], [S(2), D.T, 'listen', 'official']],
    official: [[0, S(2), 'listen', 'admin'], [S(2), S(10), 'paper'], [S(10), D.T, 'talk', 'maya']],
    maya: [[0, S(1), 'listen', 'admin'], [S(1), S(2), 'talk', 'official'], [S(2), S(10), 'listen', 'official'], [S(10), D.T, 'read']],
    omar: [[0, S(10), 'listen', 'official'], [S(10), S(14), 'paper'], [S(14), D.T, 'listen', 'official']],
  },
  displays: {
    counter: [
      [0, S(2), 'folder', 'Pilot · Check case files', 'neutral'],
      [S(2), S(9), 'computer', 'Answers vs. Acts', 'neutral'],
      [S(9), D.T, 'key', 'Pilot files only · Shaima approves', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Small AI agent pilot'],
    [S(2), E(2), 'Two boxes: Answers · Acts'],
    [S(9), E(9), 'Hamad owns pilot · Shaima approves'],
    [S(10), E(10), 'Cannot send, pay or delete'],
  ],
  pages: [
    hero(S(3), S(6), 'An assistant answers; an agent acts', 'made/own_chat+made/own_computer', [
      ['Given a goal, chooses steps and uses tools', S(3), 'v-navy'],
      ['Tool use turns words into actions', S(5), 'v-amber'],
    ]),
    hero(S(6), S(9), 'More autonomy, more impact if it goes wrong', 'made/balance_scale+made/padlock_open', [
      ['Match controls to the level of autonomy', S(6), 'v-teal'],
      ['Approve each action, monitor, or unreviewed', S(7), 'v-amber'],
    ]),
    hero(S(9), S(14), 'Human leads, AI enables', 'made/id_badge+made/rubber_stamp', [
      ['Start with low-risk, well-defined tasks', S(11), 'v-teal'],
      ['Plan for an agent that misbehaves', S(13), 'v-coral'],
    ]),
    hero(S(14), D.T, 'Know its limits before use', 'made/register_book+made/own_bell', [
      ['Never link an agent without approval', S(14), 'v-coral'],
      ['Unexpected action? Stop, verify and report', S(15), 'v-amber'],
    ]),
  ],
}));
