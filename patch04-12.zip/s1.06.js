// 1.06 Responsibilities assemble around the service; a failed access control is caught by monitoring.
import { THREE,C,V,mesh,mat,rbox,box,cyl,sph,group,bar,laptop,ramp,pulse,lerp } from './kit.js';
import { createPerson } from './people.js';
import { desk,model } from './sets.js';
import { label,sign,showSprite } from './objects.js';
import { conduit,caseCard,badge,frameShots,quietScreens,frac,clearForeground } from './astra.js';
import { placePerson,side,clamp,dome,backOut } from './round2.js';
import { enter,hit,land,sentence } from './motion.js';
import { weight, eye, acknowledge, beatWindow } from './colleagues.js';
export const texts=[1,7,10];
export const cast=['lena','maya','omar','priya'];
export default async function({stage,scene,b,S,E,ui}) {
 clearForeground(b);
 const lena=createPerson('lena',scene),maya=createPerson('maya',scene),omar=createPerson('omar',scene),priya=createPerson('priya',scene),all=[lena,maya,omar,priya];
 desk(scene,-1.35,-.8,.78,2.4,1.2);
 await model('server-rack',scene,4.7,0,-3.95,2.05);
 const lap=laptop(scene,-1.7,.78,-1.45,.5+Math.PI,1.05);
 const lock=sign('ok',scene,-1.7,1.25,-1.45,.22);
 const root=group(scene,-1.35,.85,-.8);root.rotation.y=Math.PI/4;
 const hub=group(root,0,1.95,0),layers=[],openings=[],layerMats=[],layerLabels=[];
 const colours=[C.teal,C.powderD,C.tealD,C.amber,C.navyL];
 const names=['Access controls','Maintained software','Restricted connections','Monitoring','Recovery'];
 // Nested, split shells surround the same record. The open segment is real geometry.
 for(let i=0;i<5;i++) {
  const r=1.52-i*.23,g=group(hub);layers.push(g);
  const m=new THREE.MeshStandardMaterial({color:colours[i],roughness:.42,metalness:.18,emissive:colours[i],emissiveIntensity:.07});layerMats.push(m);
  const fixed=mesh(new THREE.TorusGeometry(r,.035,10,80,Math.PI*1.5),m,0,0,0,g);fixed.rotation.z=Math.PI/4;
  const opening=group(g);openings.push(opening);
  const arc=mesh(new THREE.TorusGeometry(r,.035,10,28,Math.PI/2),m,0,0,0,opening);arc.rotation.z=Math.PI*7/4;
  // Mechanical tabs identify separate controls, not one magical shield.
  for(let j=0;j<4;j++){const a=j*Math.PI/2+i*.12;const o=mesh(rbox(.12,.14,.09,.02),colours[i],Math.cos(a)*r,Math.sin(a)*r,0,g);o.rotation.z=a;}
  layerLabels.push(label(names[i],root,0,4.1,.35,.22,colours[i]));
 }
 const record=caseCard(hub,0,0,.15,1.1);record.rotation.x=1.3;
 const caseLabel=label('Public service · Case 2048',root,0,.12,.4,.2);
 const plinth=mesh(rbox(2.5,.13,1.35,.04),C.navy,0,.2,0,root);
 bar(V(-.8,.25,0),V(-.8,.7,0),.028,C.metal,root);bar(V(.8,.25,0),V(.8,.7,0),.028,C.metal,root);
 const observations=Array.from({length:8},(_,i)=>mesh(sph(.05),C.amber,0,0,0,layers[3]));
 const scan=mesh(new THREE.RingGeometry(.79,.81,64),mat(C.amber,{transparent:true,opacity:.19,side:THREE.DoubleSide,depthWrite:false}),0,0,.02,layers[3]);
 const maintenance=mesh(rbox(.19,.22,.18,.02),C.powderD,-1.13,0,0,layers[1]);
 const ports=[];
 for(let i=0;i<3;i++) {
  const p=group(layers[2],0,0,0),a=Math.PI*.7+i*.45;
  p.rotation.z=a;p.position.set(Math.cos(a)*1.08,Math.sin(a)*1.08,0);
  mesh(rbox(.28,.09,.14,.02),C.tealD,.07,0,0,p);ports.push(p);
 }
 const containment=mesh(rbox(.07,.7,.2,.025),C.teal,.8,0,.15,hub);
 const attempt=mesh(sph(.09),C.amber,2.3,0,.12,hub);
 const stopped=sign('stop',root,1.55,2.4,.35,.3),detected=sign('alert',root,.85,2.35,.35,.3);
 const failure=label('Access failed · Monitoring detected',root,0,3.83,.45,.19,C.amber);
 const blocked=label('Unauthorized attempt stopped',root,0,3.83,.45,.19,C.teal);
 const backup=caseCard(root,-1.2,.6,.1,.65);backup.rotation.x=1.25;
 const restore=conduit(root,[V(-1.2,.65,.1),V(-1.5,1.4,.45),V(-.8,2.55,.55),V(0,1.95,.15)],C.teal,.023);
 const recovered=sign('ok',root,0,2.6,.3,.3);
 const recoveryLabel=label('Restore · Check · Practice',root,0,3.83,.45,.2,C.teal);
 const governance=label('Policy · Oversight · Risk decisions',scene,-1.3,2.7,-.9,.2);
 const rolePeople=[lena,maya,omar,priya,maya];
 const roleNames=['Leadership','Service owner','Security + technology','Procurement + privacy','Staff'];
 const roleLabels=rolePeople.map((p,i)=>label(roleNames[i],scene,0,0,0,.18));
 const cards=all.map(()=>caseCard(scene,0,0,0,.38));
 const responsibility=all.map((p,i)=>({
  beam:mesh(cyl(.014,.014,1,10),colours[i],0,0,0,scene),
  bead:mesh(sph(.027),C.sand,0,0,0,scene)
 }));
 const linkStart=V(0,0,0),linkEnd=V(0,0,0),linkDir=V(0,0,0);
 const hp=V(0,0,0),mid=V(-1.35,1.25,-.8);
 const origin=V(.25,0,1.5);
 // Five protections stand around one record, each with its own shell. One can fail; the others remain.
 const vault=group(scene);vault.rotation.y=Math.PI/4;vault.position.copy(origin).add(side(0,0,.8));
 mesh(cyl(1.14,1.2,.09,72),C.navy,0,.045,0,vault);
 mesh(cyl(.15,.2,.34,32),C.paper,0,.26,0,vault);
 const treasure=caseCard(vault,0,.58,0,.58);treasure.rotation.x=1.15;
 const shells=[[1.05,C.teal,'#7fd8cf'],[.9,C.powderD,'#c3d6ee'],[.75,C.tealD,'#6fc3bb'],[.6,C.amber,'#f3c572'],[.45,C.navyL,'#9aa8d8']].map(([r,c,l])=>dome(vault,r,c,l));
 // The existing containment bar must belong to the model that remains on screen.
 vault.add(containment);
 const threat=mesh(sph(.09),new THREE.MeshStandardMaterial({color:C.coral,emissive:C.coral,emissiveIntensity:.5,roughness:.35}),0,.36,.3,vault);
 return t=>{
  all.forEach((p,i)=>{p.reset();p.idle(t,i);p.smile=.28;});
  lena.at(-2.5,-1.9,.78);maya.at(-1.75,-1.95,.5);omar.at(0,-2,.1);priya.at(.45,-.9,-.5);
  all.forEach(p=>p.look(mid,.8));quietScreens(ui,t);
  const role=t>=S(1)&&t<S(6)?Math.min(4,Math.max(0,[1,2,3,4,5].filter(i=>t>=S(i)).length-1)):-1;
  rolePeople.forEach((p,i)=>{
   const on=pulse(t,S(i+1),S(i+1)+.6,S(i+2)-.5,S(i+2));p.present(i<2?'L':'R',mid,on);
   const pos=p.g.position;roleLabels[i].position.set(pos.x,2.18,pos.z);showSprite(roleLabels[i],on);
  });
  all.forEach((p,i)=>{
   const held=role>=0&&rolePeople[role]===p;cards[i].visible=held;
   if(held){const side=role<2?'L':'R';p.grip[side]=.9;p.handPos(side,hp);cards[i].position.copy(hp).add(V(0,.025,0));cards[i].rotation.set(.2,p.g.rotation.y,0,'YXZ');}
  });
  const locking=pulse(t,S(5)+.6,S(5)+1.3,S(5)+2,S(5)+2.5);
  maya.reach('R',V(-1.72,.9,-1.35),locking);
  // Keep the held object on the solved hand even while the laptop-lock action overrides the pose.
  if(role===4){maya.handPos('R',cards[1].position);cards[1].position.y+=.025;}
  showSprite(lock,pulse(t,S(5)+1.3,S(5)+1.8,S(6)-.5,S(6)));
  showSprite(governance,pulse(t,S(6),S(6)+.6,E(6)-.4,S(7)));
  const expand=ramp(t,S(7)-1.5,S(7)+.8)-ramp(t,S(11)+3,E(11)-.2);
  root.position.set(lerp(-1.1,5.1,expand),lerp(.82,.1,expand),lerp(-.55,.1,expand));root.scale.setScalar(lerp(.18,1,expand));
  root.updateMatrixWorld(true);linkEnd.copy(root.localToWorld(V(0,1.95,0)));
  responsibility.forEach((l,i)=>{
   const k=t<S(6)&&role>=0&&rolePeople[role]===all[i]?1:pulse(t,S(6),S(6)+.8,E(6)-.5,S(7));
   all[i].handPos(role>=0&&role<2?'L':'R',linkStart);
   linkDir.copy(linkEnd).sub(linkStart);const len=Math.max(.001,linkDir.length());linkDir.normalize();
   l.beam.visible=l.bead.visible=k>.001;l.beam.scale.y=len*k;
   l.beam.position.copy(linkStart).addScaledVector(linkDir,len*k*.5);
   l.beam.quaternion.setFromUnitVectors(V(0,1,0),linkDir);
   l.bead.position.copy(linkStart).lerp(linkEnd,frac(t*.4)*k);
  });
  const active=t>=S(8)&&t<S(9)?Math.min(4,Math.floor((t-S(8))/(E(8)-S(8))*5)):-1;
  const failureK=pulse(t,S(9),S(9)+.7,E(9)-.2,S(10));
  const open=ramp(t,S(9),S(9)+.8)*(1-ramp(t,S(10),S(10)+.6));
  layers.forEach((g,i)=>{
   g.rotation.x=.08*Math.sin(t*.6+i);g.rotation.y=.13*Math.sin(t*.45+i);
   g.position.z=-i*.1*expand;
   layerMats[i].emissiveIntensity=active===i?.6:.07;
   openings[i].rotation.y=i===0?open*1.5:.12*Math.sin(t*.8+i);
   showSprite(layerLabels[i],active===i?1:0);
  });
  maintenance.position.x=-1.13-.35*(1-ramp(t,S(3)+.5,S(3)+1.8));
  ports.forEach((p,i)=>p.scale.x=i===1?1:1-.7*ramp(t,S(4)+.6,S(4)+1.6));
  observations.forEach((o,i)=>{const a=t*.8+i*Math.PI/4;o.position.set(Math.cos(a)*.82,Math.sin(a)*.82,.03);});
  scan.rotation.z=t;scan.scale.setScalar(1+.06*Math.sin(t*2));
  containment.visible=t>=S(9)+1.5&&t<S(10);containment.position.y=lerp(.8,0,ramp(t,S(9)+1,S(9)+1.7));
  attempt.visible=t>=S(7)&&t<S(8)||t>=S(9)&&t<S(10);
  const advance=ramp(t,S(9)+.1,S(9)+1.5);
  attempt.position.x=t<S(9)?lerp(2.3,1.62,ramp(t,S(7)+.2,S(7)+1.2)):lerp(1.62,.91,advance);
  attempt.scale.setScalar(1-ramp(t,S(9)+3,S(9)+4));
  showSprite(stopped,t>=S(7)&&t<S(8)?ramp(t,S(7)+.8,S(7)+1.2):0);
  showSprite(detected,t>=S(9)?pulse(t,S(9)+1,S(9)+1.6,E(9)-.3,S(10)):0);
  showSprite(blocked,t>=S(7)&&t<S(8)?1:0);showSprite(failure,failureK);
  const restoring=ramp(t,S(11),S(11)+3);
  backup.visible=t>=S(11);backup.position.copy(restore.curve.getPointAt(restoring));backup.rotation.y=restoring*Math.PI*2;
  restore.update(t,t>=S(11)?1:0,.25);restore.bead.visible=false;
  showSprite(recovered,ramp(t,S(11)+2.6,S(11)+3.2));showSprite(recoveryLabel,ramp(t,S(11),S(11)+.6));
  record.visible=!(t>=S(11)&&restoring<1);
  const who=(x,y,z,w=2.8)=>({x,y,z,w,e:.43,f:.43});
  frameShots(stage,t,[who(-1.35,1.5,-1.2,4.8),
   {t0:S(1)-.4,t1:S(1)+.6,...who(-2.2,1.5,-1.6,2.6)},
   {t0:S(2)-.4,t1:S(2)+.6,...who(-1.7,1.5,-1.6,2.6)},
   {t0:S(3)-.4,t1:S(3)+.6,...who(-.3,1.5,-1.7,2.6)},
   {t0:S(4)-.4,t1:S(4)+.6,...who(.1,1.5,-.9,2.6)},
   {t0:S(5)-.4,t1:S(5)+.6,...who(-1.7,1.5,-1.6,2.6)},
   {t0:S(6)-.4,t1:S(6)+.7,...who(-1.35,1.6,-1.2,4.8)},
   {t0:S(7)-1.5,t1:S(7)+.8,x:5.1,y:2.15,z:.1,w:4.3,e:.5,f:.46},
   {t0:S(10)-.4,t1:S(10)+.6,x:5.1,y:2.1,z:.1,w:4.5,e:.55,f:.46},
   {t0:S(11)-.4,t1:S(11)+.7,x:5.1,y:2.1,z:.1,w:4.2,e:.5,f:.46},
   {t0:S(11)+3,t1:E(11)-.2,...who(-1.35,1.5,-1.2,4.8)}]);
  // Keep the demonstration below the face band, including the old 72-second transition.
  const activePerson=role>=0?rolePeople[role]:null;
  all.forEach((p,i)=>{
   p.reset();p.idle(t,i);
   const u=[-.98,-.33,.33,.98][i];
   placePerson(p,origin,u,-.4,.78);
   p.g.visible=true;
   p.look(origin.clone().add(side(.1,.65,.9)),1);p.smile=.08;
  });
  root.position.copy(origin).add(side(0,.02,.55));
  // The full circles clear the floor as well as the faces; do not bury their lower arcs.
  root.scale.setScalar(.46);hub.position.y=1.55;
  lock.visible=false;
  plinth.visible=false;root.children.filter(o=>o.geometry?.type==='CylinderGeometry').forEach(o=>o.visible=false);
  // A role contributes directly to a full-size tab on the common model.
  responsibility.forEach(l=>{l.beam.visible=l.bead.visible=false;});cards.forEach(c=>c.visible=false);
  if(activePerson){
   const hand='L',target=root.localToWorld(V(-1.05,2.55,0));
   activePerson.reach(hand,target,1);
   const card=cards[all.indexOf(activePerson)];card.visible=true;activePerson.handPos(hand,card.position);card.rotation.set(.25,.78,0);
   // Each role contributes to the same model; roles are not assigned one control each.
   const press=pulse(t,S(role+1)+.4,S(role+1)+.8,E(role+1)-.5,E(role+1));
   layerMats.forEach(m=>m.emissiveIntensity=.18+.18*press);
   layers[0].position.x=.09*press;
  }
  layers.forEach((g,i)=>{if(!activePerson||i!==0)g.position.x=0;});
  // Recovery follows the lowered hub rather than the former overhead position.
  restore.g.visible=false;backup.visible=t>=S(11);
  backup.position.set(lerp(-1.2,0,restoring),lerp(.1,hub.position.y,restoring),.15);
  const beat=sentence(t,S,12),start=S(beat),age=t-start;
  record.rotation.set(1.3,0,0);record.position.set(0,0,.15);
  layers.forEach((g,i)=>{g.scale.setScalar(1);g.rotation.z=0;g.position.x=g.position.y=0;});
  maintenance.rotation.z=0;containment.rotation.z=0;
  if(activePerson){
   const approach=ramp(t,start,start+.65),press=pulse(t,start+.8,start+1.4,E(beat)-1,E(beat)-.3);
   // Keep each person's place in the team; step forward and back without a role-change jump.
   const stepOut=ramp(t,start,start+.65)*(1-ramp(t,E(beat)-.65,E(beat)));
   placePerson(activePerson,origin,[-.98,-.33,.33,.98][all.indexOf(activePerson)],-.4+.25*stepOut,.78);
   const step=pulse(t,start,start+.18,start+.45,start+.7);
   activePerson.walk(age*6,.18*step);activePerson.bend=.065*press;
   // The card stays within its holder's reach, beside the model rather than through it.
   const u=[-.98,-.33,.33,.98][all.indexOf(activePerson)];
   const target=origin.clone().add(side(u*.78,1.04+.06*press,.12+.06*press));
   activePerson.reach('L',target,ramp(t,start,start+.45)*(1-ramp(t,E(beat)-.45,E(beat))));
   activePerson.present('R',root.localToWorld(V(.65,1.55,0)),.75*press);
   activePerson.look(target,1);activePerson.smile=.1+.06*press;
   const card=cards[all.indexOf(activePerson)];activePerson.handPos('L',card.position);
   card.rotation.set(.25+(role===1?.65:role===3?-.45:0)*press,.78+.35*hit(t,start+1.4),.12*hit(t,start+1.4),'YXZ');
   // The full model responds to each contribution, with a distinct physical operation.
   if(role===0)layers.forEach((g,i)=>{g.position.y=.09*hit(t,start+1.4+i*.09);});
   if(role===1){record.position.x=-.32*press;record.rotation.z=.22*Math.sin(press*Math.PI);}
   if(role===2){maintenance.position.x=-1.13-.45*(1-press);maintenance.rotation.z=.18*hit(t,start+1.4);layers.forEach((g,i)=>openings[i].rotation.y=.8*(1-press));}
   if(role===3){record.rotation.y=.45*press;layers.forEach((g,i)=>g.rotation.z=(i%2?-.08:.08)*press);}
   if(role===4){openings.forEach((o,i)=>o.rotation.y=1.2*(1-enter(t,start+.7+i*.11,.45)));card.rotation.x=.25+.6*ramp(t,start+3,start+4);activePerson.present('R',origin.clone().add(side(.5,.85,.5)),ramp(t,start+3,start+3.6));}
  }else{
   layers.forEach(g=>g.position.y=0);record.rotation.y=0;
  }
  // Small cards travel from the team to the common model, below the faces.
  if(beat===0||beat===6){
   all.forEach((p,i)=>{
    const at=start+i*.55,k=ramp(t,at+.25,at+1.2),hand=i<2?'L':'R';
    const from=origin.clone().add(side((i-1.5)*.55,.85,.2)),to=root.localToWorld(V(0,hub.position.y,.2));
    p.reach(hand,from,.35+.65*pulse(t,at,at+.4,at+1,at+1.5));p.bend=.09*pulse(t,at,at+.4,at+1,at+1.5);
    cards[i].visible=k<1&&t>=at;cards[i].position.copy(p.handPos(hand)).lerp(to,k);cards[i].position.y+=.025+.13*Math.sin(k*Math.PI);cards[i].rotation.set(.3,.78,k*.3,'YXZ');
    if(beat===6){p.look(all[(i+1)%all.length].g.position.clone().setY(1.5),pulse(t,at+.2,at+.6,at+1.3,at+1.7));}
   });
   layers.forEach((g,i)=>{g.rotation.z=.1*hit(t,start+i*.55+1.2);});
  }
  if(beat>=7){
   // Split shells arrive and close one after another; the threat hits and rebounds.
   layers.forEach((g,i)=>{
    const at=beat===8?start+i*(E(8)-start)/5:start+i*.28;
    const close=enter(t,at,.5);
    g.position.x=.3*(1-close);g.rotation.z=.07*hit(t,at+.5);
    if(beat===7||beat===8)openings[i].rotation.y=1.5*(1-close);
    if(beat===8&&i===1)maintenance.position.x=-1.13-.4*(1-close);
    if(beat===8&&i===2)ports.forEach((p,n)=>p.scale.x=n===1?1:1-.7*clamp((t-at)/.55));
   });
   hub.position.y=1.55+land(t,start,.16,.4);
   if(beat===7){
    const contact=start+1.65,coming=ramp(t,start+.4,contact),bounce=ramp(t,contact,contact+.8);
    attempt.position.x=lerp(2.35,1.62,coming)+.7*bounce;
    attempt.position.y=.12*Math.sin(bounce*Math.PI);attempt.scale.setScalar(1.25);
    layers[0].position.x+=.07*hit(t,contact);
   }
   if(beat===9){
    containment.position.y=lerp(.9,0,enter(t,start+1.2,.4));containment.rotation.z=.08*hit(t,start+1.6);
    attempt.position.x=lerp(1.62,.91,advance)+.22*ramp(t,start+1.6,start+2.3);attempt.position.y=0;
    layers[3].rotation.z+=.12*hit(t,start+1.5);
   }
   if(beat===10){
    // Isolate one layer briefly, then close the rest around it: one is no guarantee.
    layers.forEach((g,i)=>{g.position.x=(i-2)*.14*pulse(t,start+.3,start+.8,start+1.2,start+2.2);openings[i].rotation.y=i===0?.95*pulse(t,start+.3,start+.7,start+1.1,start+1.8):0;});
    record.position.y=.09*hit(t,start+2.2);
   }
   if(beat===11){
    backup.position.y+=.14*Math.sin(restoring*Math.PI)+.04*hit(t,start+3);
    layers.forEach((g,i)=>g.rotation.z=.06*hit(t,start+3+i*.15));
   }
   all.forEach((p,i)=>{
    const act=pulse(t,start+i*.12,start+.5+i*.12,E(beat)-.6,E(beat));
    p.bend=(beat===9?-.06:.07)*act;p.smile=beat===9?.04:beat===11?.4:.24;
    p.present(i<2?'R':'L',root.localToWorld(V(0,hub.position.y,0)),.6*act);
   });
  }
  // From "defence in depth" on, the flat rings give way to the shells.
  const shown=backOut(clamp((t-S(7)+.1)/.7));
  vault.visible=t>=S(7)-.1;vault.scale.setScalar(Math.max(.001,shown));
  hub.visible=t<S(7)+.2;hub.scale.setScalar(Math.max(.001,1-ramp(t,S(7)-.4,S(7)+.2)));
  if(t>=S(7))backup.visible=false;
  stopped.visible=detected.visible=recovered.visible=false;
  const slot=(E(8)-S(8))/5,failed=pulse(t,S(9)+1,S(9)+1.3,S(10)+.2,S(10)+1);
  shells.forEach((d,i)=>{
   const preview=S(7)+i*.28,at=S(8)+i*slot,k=backOut(clamp((t-preview)/.5)),named=t>=at&&t<at+slot&&t<S(9);
   const caught=i===3?pulse(t,S(9)+2.2,S(9)+2.35,S(9)+3,S(9)+3.8):0,bump=t>=S(11)?.03*hit(t,S(11)+.6+i*.5):0;
   d.visible=t>=preview;d.scale.setScalar(Math.max(.001,k)*(1+bump+.05*caught));
   const fill=d.userData.fill.material,gone=i===0?failed:0;
   fill.opacity=(.1+.2*(named?1:0)+.25*caught)*(1-.8*gone);fill.emissiveIntensity=named||caught>.1?.8:.25;
   d.userData.net.material.opacity=.7*(1-gone);d.userData.net.rotation.y=(i%2?-1:1)*t*.15;
  });
  // A threat gets past the first control, then monitoring stops it.
  const hit1=S(9)+1,hit2=S(9)+2.2,move=ramp(t,S(9)+.1,hit1),deep=ramp(t,hit1,hit2),back=ramp(t,hit2,hit2+.6);
  threat.visible=t>=S(9)&&t<S(9)+3.8;threat.position.x=lerp(lerp(lerp(2.1,1.07,move),.63,deep),.86,back);
  threat.position.y=.36+.14*Math.sin(back*Math.PI);threat.scale.setScalar(Math.max(.001,1-ramp(t,S(9)+3.1,S(9)+3.8)));
  containment.visible=t>=hit2&&t<S(10);
  containment.position.set(.63,.36+.65*(1-enter(t,hit2,.35)),.3);
  containment.rotation.set(0,0,.06*hit(t,hit2+.35));
  // Keep the whole team listening during Leaders through Staff. Attention moves
  // from the contribution to its owner; different response times avoid a chorus.
  all.forEach((p,i)=>{
   weight(p,t,i+1);
   if(activePerson){
    const peer=all[(all.indexOf(activePerson)+1)%all.length];
    if(p===activePerson){
     p.look(eye(peer),beatWindow(t,start+1.7,Math.min(E(beat),start+3.5)));
    }else{
     p.look(eye(activePerson),.85);
     p.look(cards[all.indexOf(activePerson)].position,beatWindow(t,start+.25+i*.12,start+1.5+i*.12));
     p.bend=.025*beatWindow(t,start+.4+i*.12,start+2+i*.12);
     acknowledge(p,t,start+2+i*.27,false,.65);
    }
   }else if(beat===7||beat===9){
    const alarm=beatWindow(t,start+1.1,start+2.7);
    p.bend=-.045*alarm;
    p.look(eye(all[(i+1)%all.length]),beatWindow(t,start+2.35+i*.12,start+3.7+i*.12));
    p.smile=beat===9?.01:.07+.12*ramp(t,start+2,start+2.8);
   }else if(beat===10||beat===11){
    p.smile=.12+.08*ramp(t,start+1,start+2);
    acknowledge(p,t,start+2+i*.24,false,.7);
    p.look(eye(all[(i+1)%all.length]),beatWindow(t,start+1.3+i*.2,start+3+i*.2));
   }
  });
  // Refresh the held card after the final posture, so the fingers stay on it.
  if(activePerson)activePerson.handPos('L',cards[all.indexOf(activePerson)].position);
  stage.focus=activePerson?layers[0]:t<S(7)?hub:null;
  const team={x:origin.x,y:.75,z:origin.z,w:3.05,e:.24,f:.39};
  frameShots(stage,t,[team,{t0:S(7)-.5,t1:S(7)+.5,...team,w:3.1,e:.34}]);
 };
}
