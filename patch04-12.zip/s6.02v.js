// Where the answer comes from.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '6.1',
  actors: { maya: 'counter', omar: 'colleague', official: 'director' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'counterDisplay'], [S(2), 'staff'], [S(3), 'gathering'], [S(4), 'her'], [S(12), 'counterDisplay'], [S(13), 'gathering']],
  actions: {
    maya: [[0, S(2), 'type'], [S(2), S(3), 'listen', 'omar'], [S(3), S(12), 'listen', 'official'], [S(12), D.T, 'read']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(3), 'talk', 'maya'], [S(3), D.T, 'listen', 'official']],
    official: [[0, S(3), 'listen', 'maya'], [S(3), S(12), 'paper'], [S(12), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'computer', 'Case 2048 · Late request', 'neutral'],
      [S(1), S(12), 'file', 'Circular cited in answer', 'neutral'],
      [S(12), D.T, 'folder', 'Read rules only · No changes', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048 · Late request'],
    [S(1), E(1), 'Circular cited in answer'],
    [S(3), E(3), 'Documents · Mail · Case system'],
    [S(12), E(12), 'Read rules only · No changes'],
  ],
  pages: [
    hero(S(4), S(7), 'Search first, then answer', 'made/filing_cabinet+made/own_computer', [
      ['Searches the approved knowledge base first', S(4), 'v-teal'],
      ['Old, wrong or planted text harms answers', S(6), 'v-coral'],
    ]),
    hero(S(7), S(10), 'Every source and tool is a door', 'made/own_mail+made/own_calendar+made/case_folder', [
      ['Tools let the assistant act, not only answer', S(8), 'v-amber'],
      ['Every door must be known and approved', S(9), 'v-navy'],
    ]),
    hero(S(10), S(13), 'Limit reach to the task', 'made/key_cabinet+made/safe', [
      ['Start with well-defined, low-risk tasks', S(11), 'v-teal'],
      ['Reads rules; cannot edit files or send mail', S(12), 'v-navy'],
    ]),
    hero(S(13), D.T, 'Approved sources and tools only', 'made/register_book+made/own_bell', [
      ['Never link personal folders, mail or add-ons', S(13), 'v-coral'],
      ['Unknown source or action? Stop and report', S(14), 'v-amber'],
    ]),
  ],
}));
