// The role, the case and the master key.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['official', 'maya', 'priya', 'admin'];
export default chapterHall((S, E, D) => ({
  lesson: '4.3',
  actors: { official: 'desk', maya: 'counter', priya: 'beside', admin: 'door' },
  shots: [[0, 'desk'], [S(1), 'counter'], [S(2), 'pair'], [S(3), 'display'], [S(7), 'door'], [S(12), 'desk'], [S(13), 'pair']],
  actions: {
    official: [[0, S(12), 'read'], [S(12), S(13), 'type'], [S(13), D.T, 'talk', 'priya']],
    maya: [[0, D.T, 'read']],
    priya: [[0, D.T, 'listen', 'official']],
    admin: [[0, D.T, 'paper']],
  },
  displays: {
    desk: [[0, S(7), 'folder', 'Case 2048 · Roles', 'neutral'], [S(7), S(12), 'key', 'Privileged account', 'alert'], [S(12), D.T, 'tick', 'Scoped access approved', 'safe']],
    counter: [[0, D.T, 'folder', 'Case 2048', 'safe']],
  },
  plates: [[S(0), E(0), 'Hamad · Manager'], [S(1), E(1), 'Caseworker role'], [S(2), E(2), 'Finance fields only'], [S(7), E(7), 'Privileged administrator'], [S(12), E(12), 'Scoped access approved']],
  pages: [
    hero(S(3), S(5), 'Access follows the job role', 'made/id_badge+made/filing_cabinet', [
      ['Role-based access control', S(4), 'v-teal'],
    ]),
    hero(S(5), S(7), 'Context can narrow access', 'clock+computer+made/signpost', [
      ['Attribute-based access control', S(6), 'v-teal'],
    ]),
    hero(S(8), S(12), 'Privileged accounts need stronger control', 'key+made/safe+shield', [
      ['Not for daily office work', S(8), 'v-amber'],
      ['One accountable person', S(10), 'v-teal'],
    ]),
    hero(S(13), D.T, 'Review and remove unused access', 'made/register_book+bell', [
      ['Report excessive permissions', S(14), 'v-teal'],
    ]),
  ],
}));
