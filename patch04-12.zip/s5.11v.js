// Only what the task needs.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '5.3',
  actors: { maya: 'counter', omar: 'desk' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'counter'], [S(1), 'her'], [S(2), 'counterDisplay'], [S(8), 'counter'], [S(9), 'counterDisplay'], [S(11), 'her'], [S(13), 'file'], [S(14), 'her']],
  actions: {
    maya: [[0, S(1), 'file'], [S(1), S(8), 'read'], [S(8), S(13), 'type'], [S(13), S(14), 'file'], [S(14), D.T, 'type']],
    omar: [[0, D.T, 'read']],
  },
  displays: {
    counter: [
      [0, S(8), 'file-text', 'Reply letter draft', 'neutral'],
      [S(8), S(13), 'key', 'Coded prompt · Safe', 'safe'],
      [S(13), D.T, 'tick', 'Final letter in case system', 'safe'],
    ],
    desk: [[0, D.T, 'folder', 'Case records', 'neutral']],
  },
  plates: [
    [S(0), E(0), 'Approved AI assistant'],
    [S(8), E(8), 'Name replaced with code'],
    [S(13), E(13), 'Signed by Shaima'],
  ],
  pages: [
    hero(S(3), S(5), 'Only what the task needs', 'file-text+zoom', [
      ['Leave out names, IDs and diagnoses', S(3), 'v-teal'],
      ['Minimum personal data principle', S(3), 'v-navy'],
    ]),
    hero(S(5), S(7), 'Replace names with codes', 'made/id_badge+key', [
      ['Keep the linking table separate', S(5), 'v-teal'],
      ['Anonymisation removes identity for good', S(6), 'v-navy'],
    ]),
    hero(S(7), S(9), 'Coded data is still personal data', 'lock+made/case_folder', [
      ['Reduces risk, not anonymisation', S(7), 'v-amber'],
    ]),
    hero(S(11), D.T, 'Decisions stay human', 'made/rubber_stamp+shield+bell', [
      ['Staff decide approval and payment', S(12), 'v-teal'],
      ['Entered too much? Report at once', S(16), 'v-amber'],
    ]),
  ],
}));
