// A letter on our letterhead that we never sent
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["lena", "citizen"];
export default chapterHall((S, E, D) => ({
  lesson: "3.3",
  actors: { lena: 'counter', citizen: 'visitor' },
  shots: [[0,'counter'], [S(1),'file'], [S(3),'counter'], [S(10),'her'], [S(11),'counterDisplay'], [S(12),'counter'], [S(14),'her']],
  actions: { lena: [[0,S(1),'listen','citizen'], [S(1),S(11),'paper'], [S(11),S(12),'type'], [S(12),S(13),'talk','citizen'], [S(13),E(13),'paper'], [S(14),D.T,'type']], citizen: [[0,S(3),'talk','lena'], [S(3),S(12),'listen','lena'], [S(12),E(12),'text'], [S(13),D.T,'listen','lena']] },
  setupProps: evidence({ surfaces: { 'paper:lena': [[0,D.T,'letter','Penalty notice']], counter: [[S(11),S(14),'lookup','Reference not found']] }, inserts: [[S(1),E(2),'paper:lena'], [S(11),E(11),'counter']] }),
  displays: { counter: [[0,S(11),'folder','Official record','neutral'], [S(11),S(14),'zoom','Reference not found','alert'], [S(14),D.T,'bell','Report sent','safe']] },
  plates: [[S(0),E(0),'Enquiries desk'], [S(2),E(2),'Pay within 48 hours'], [S(3),E(3),'Request for secrecy'], [S(11),E(11),'Reference not found']],
  pages: [
    hero(S(4), S(8), "Criminals impersonate public institutions", "made/headset+file-text", [
      ["Penalty notice", S(4), "v-amber"],
    ]),
    hero(S(8), S(10), "A logo and a stamp can be forged", "made/rubber_stamp+file-text", [
      ["Printed signature", S(8), "v-amber"],
    ]),
    hero(S(11), S(13), "Check the reference in our own system", "made/laptop+made/register_book", [
      ["Reference not found", S(11), "v-teal"],
    ]),
  ],
}));
