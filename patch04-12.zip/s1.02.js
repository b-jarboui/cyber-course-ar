// 1.02 A cutaway foundation unfolds under the service; one lost dependency stops the case.
import { THREE,C,V,mesh,mat,rbox,box,cyl,sph,group,bar,folder,laptop,ramp,pulse,lerp } from './kit.js';
import { createPerson } from './people.js';
import { atCounter,SHOT } from './sets.js';
import { label,sign,showSprite,records,appModule,chipId,aiCore,tower,terminal,powerBox,gate } from './objects.js';
import { conduit,caseCard,badge,frameShots,quietScreens,clearForeground } from './astra.js';
import { placePerson,side,carousel,dome,clamp,libraryModel } from './round2.js';
import { enter,hit,land,sentence } from './motion.js';
import { weight, exchange, acknowledge, beatWindow } from './colleagues.js';
import { identityService,paymentTerminal,telecomTower,powerTransformer,civicHospital,trafficSignal,waterPump } from './detailed-props.js';
export const texts=[1,3,5];
export const cast=['maya','citizen'];
export default async function({stage,scene,b,createCounter,S,E,ui}) {
 clearForeground(b);
 createCounter(scene);
 const maya=createPerson('maya',scene),applicant=createPerson('citizen',scene);
 const file=folder(scene,-2.28,1.09,.1,1.05);file.rotation.y=.3;file.userData.open(1);
 const root=group(scene,1.9,.18,.1);root.rotation.y=Math.PI/4;
 const decks=[],titles=[],contents=[];
 for(let i=0;i<3;i++) {
  const d=group(root,0,.35+i*1.25,0);decks.push(d);
  mesh(rbox(2.85,.1,1.08,.04),i===0?C.sand:'#dce8e6',0,0,0,d);
  bar(V(-1.35,.07,.52),V(1.35,.07,.52),.016,C.teal,d);
  titles.push(label(['Information assets','Digital identities','Outside dependencies'][i],root,0,.18+i*1.25,.75,.19));
  contents.push(group(d,0,.06,0));
 }
 const assets=[records(contents[0],-1.08,0,0,.75),records(contents[0],-.54,0,0,.75,C.teal),laptop(contents[0],0,0,0,0,.85),appModule(contents[0],.56,0,0,.85),records(contents[0],1.12,0,0,.8,C.navyD)];
 const assetNames=['Applicant record','Employee file','Device','Application','Systems'];
 const assetLabels=assets.map((_,i)=>label(assetNames[i],root,-1.08+i*.55,1.1,.18,.145));
 const scan=mesh(rbox(.51,.02,.7,.02),mat(C.teal,{transparent:true,opacity:.25}),-1.08,.85,0,root);
 const magnified=caseCard(root,0,1.05,.6,1.3);
 const tokens=[badge(contents[1]),chipId(contents[1],0,0,0,1.3,C.powderD),appModule(contents[1],0,0,0,.85),aiCore(contents[1],0,0,0,.7)];
 const tokenLabels=tokens.map((_,i)=>label(['Person','Device','Application','AI agent'][i],root,-1.05+i*.7,2.34,.1,.15));
 const access=gate(root,0,1.67,.47,0,.66,C.teal);
 const allowed=sign('ok',root,0,2.25,.65,.3),denied=sign('stop',root,1.08,2.25,.65,.3);
 const scope=label('Outside permitted scope',root,0,2.62,.65,.17,C.coral);
 const suppliers=[],bridges=[],feeds=[],supplierLabels=[];
 const identityRack=await libraryModel('server-rack',null,.46);
 const makers=[p=>identityService(p,identityRack),paymentTerminal,telecomTower,powerTransformer];
 for(let i=0;i<4;i++) {
  const x=-1.05+i*.7,p=group(contents[2],x,0,-.95);suppliers.push(p);
  mesh(rbox(.58,.07,.62,.03),C.paper,0,0,0,p);makers[i](p);
  const h=group(contents[2],x,0,-.25);bridges.push(h);mesh(rbox(.14,.045,.64,.01),C.teal,0,0,-.32,h);
  supplierLabels.push(label(['ID check','Payments','Telecom','Power'][i],root,x,3.67,-.95,.15));
  feeds.push(conduit(root,[V(x,2.98,-.95),V(x,3.1,-.45),V(x,2.98,.1)],C.teal,.016));
 }
 const line=conduit(root,[V(-1.1,.5,.5),V(-1.5,1.15,.6),V(0,1.75,.6),V(1.5,2.35,.6),V(1.05,3.05,.1)],C.teal,.022);
 const fromCounter=conduit(scene,[V(-2.28,1.12,.1),V(-1.6,.3,1.4),V(1.9,.55,.1)],C.teal,.022);
 const service=label('Case 2048 · Waiting',root,0,.75,.8,.18,C.amber);
 const seam=label('Sadeed / Other providers',root,0,3.25,.75,.17);
 // Three connected miniature civic services all depend on the same supply.
 const city=group(root,0,4.15,-.2),windows=[];
 const hospital=civicHospital(city,windows),traffic=trafficSignal(city,windows);
 const {g:pump,fan}=waterPump(city,windows);
 const cityLabel=label('Critical infrastructure',root,0,5.15,0,.2),blackOut=sign('alert',root,0,4.65,.4,.35);
 // Use the bundled graph renderer, with fixed coordinates and no simulation ticks.
 // Both the identity and supplier views occupy the same demonstration space.
 window.THREE=THREE;
 if(!window.ThreeForceGraph)await new Promise((resolve,reject)=>{
  const script=document.createElement('script');script.src='vendor/three-forcegraph.min.js';script.onload=resolve;script.onerror=reject;document.head.append(script);
 });
 const origin=V(-.3,0,1.3),map=group(scene);map.rotation.y=Math.PI/4;
 const nodes=[{id:'service',x:0,y:1.18,z:0,type:'service'},
  ...Array.from({length:8},(_,i)=>({id:'n'+i,x:-1.08+(i%4)*.72,y:.38,z:0,type:i<4?'identity':'supplier',slot:i%4}))];
 nodes.forEach(n=>Object.assign(n,{fx:n.x,fy:n.y,fz:n.z}));
 const links=nodes.slice(1).map(n=>({source:n.id,target:'service',type:n.type,slot:n.slot}));
 const graph=new window.ThreeForceGraph().warmupTicks(0).cooldownTicks(0)
  .nodeThreeObject(n=>{
   const p=group();n.object=p;
   if(n.type==='service'){caseCard(p,0,0,0,1.15).rotation.x=1.1;}
   else {
    mesh(cyl(.3,.32,.065,40),C.paper,0,-.035,0,p);
    const obj=n.type==='identity'?[q=>badge(q),q=>chipId(q,0,0,0,1),q=>appModule(q,0,0,0,.8),q=>aiCore(q,0,0,0,.65)][n.slot](p):makers[n.slot](p);
    // Stand the flat device tokens up, then give every node a readable silhouette.
    if(n.type==='identity'&&n.slot===1)obj.rotation.x=Math.PI/2;
    if(n.type==='identity'&&n.slot===2)obj.rotation.x=1.05;
    const size=new THREE.Box3().setFromObject(obj).getSize(V(0,0,0));
    obj.scale.multiplyScalar(Math.min(.52/size.y,.57/size.x,.6/size.z));
    obj.position.y-=new THREE.Box3().setFromObject(obj).min.y;
   }
   return p;
  }).linkWidth(.045).linkOpacity(1).linkColor(l=>l.slot===3?C.amber:C.teal);
 map.add(graph);
 await new Promise(resolve=>{graph.onFinishUpdate(resolve);graph.graphData({nodes,links});});
 graph.tickFrame(); // Builds the fixed links; cooldownTicks=0 prevents a physics step.
 const flow=new THREE.MeshStandardMaterial({color:'#ffd27a',emissive:'#f0a93a',emissiveIntensity:.9,roughness:.3});
 const beads=links.flatMap(l=>[0,1,2].map(j=>({l,j,m:mesh(sph(.07),flow,0,0,0,graph)})));
 beads.forEach(b=>b.m.castShadow=false);
 const stoppedFan=mat(C.metalD),litWindow=mat(C.sand);
 tokens.forEach(o=>root.add(o));
 // Reuse the five assets on Claude's turntable, keeping their individual silhouettes.
 assets.forEach(o=>{o.position.set(0,0,0);o.scale.setScalar(1.08);});
 const turntable=carousel(root,assets,.78),cover=dome(root,.9);
 const assetTimes=assets.map((_,i)=>S(2)+(E(2)-S(2))*i/5);
 const tableEntry=(a,b,i,n)=>a+(b-a)*i/n;
 return t=>{
  atCounter(maya,applicant,t,ramp(t,S(1),S(1)+.8));quietScreens(ui,t);
  const rise=ramp(t,S(1)-.5,S(1)+1.2);root.visible=rise>0;root.position.y=lerp(-1.3,.18,rise);
  decks.forEach((d,i)=>d.position.y=lerp(.35,.35+i*1.25,ramp(t,S(3)-.8+i*.15,S(3)+.6+i*.15)));
  decks[1].visible=t>=S(3)-.5;decks[2].visible=t>=S(5)-.5;
  titles.forEach((o,i)=>showSprite(o,ramp(t,S([1,3,5][i]),S([1,3,5][i])+.6)));
  const focus=Math.min(4,Math.floor(ramp(t,S(2),E(2))*5));
  scan.position.x=lerp(-1.08,1.12,ramp(t,S(2),E(2)));scan.position.y=.82;scan.visible=t>=S(2)&&t<S(3);scan.rotation.y=t*.1;
  assetLabels.forEach((o,i)=>showSprite(o,t>=S(2)&&t<S(3)&&focus===i?1:0));
  magnified.visible=t<S(2);magnified.rotation.y=.15*Math.sin(t);magnified.position.y=.85+.06*Math.sin(t*1.5);
  access.visible=t>=S(3);
  const step=Math.min(3,Math.floor(Math.max(0,(t-S(4))/(E(4)-S(4)))*4));
  tokens.forEach((o,i)=>{o.position.x=-1.05+i*.7;o.position.z=.25*ramp(t,S(4)+i*2,S(4)+i*2+.8);o.rotation.y=.2*Math.sin(t+i);});
  access.userData.open(t>=S(4)&&step<3?ramp(t,S(4)+step*2,S(4)+step*2+.6):0);
  tokenLabels.forEach((o,i)=>showSprite(o,t>=S(3)&&t<S(5)&&(i===step||t<S(4))?1:0));
  showSprite(allowed,t>=S(4)&&t<S(5)&&step<3?1:0);showSprite(denied,t>=S(4)&&t<S(5)&&step===3?1:0);
  showSprite(scope,t>=S(4)&&t<S(5)&&step===3?1:0);
  suppliers.forEach((p,i)=>{const k=ramp(t,S(5)+i*.35,S(5)+i*.35+1);p.position.z=lerp(-.2,-.95,k);bridges[i].rotation.x=lerp(-Math.PI/2,0,k);showSprite(supplierLabels[i],k);});
  const interrupted=pulse(t,S(7)+.7,S(7)+1.3,E(7)-.4,S(8));bridges[3].rotation.x-=interrupted*1.3;
  feeds.forEach((f,i)=>f.update(t,ramp(t,S(5)+i*.35,S(5)+i*.35+1)*(i===3?1-interrupted:1),.45,i*.2));
  line.update(t,ramp(t,S(3)-.5,S(3)+.5),.13);fromCounter.update(t,rise,.22);
  city.visible=t>=S(7)-.5&&t<S(8)+.5;city.position.y=lerp(3.1,4.15,ramp(t,S(7)-.5,S(7)+.5));
  showSprite(cityLabel,pulse(t,S(7)-.4,S(7)+.2,E(7)-.2,S(8)+.4));showSprite(blackOut,interrupted);
  windows.forEach(o=>o.material=mat(interrupted>.5?C.metalD:C.sand));fan.rotation.z=2*Math.min(t,S(7)+1);
  showSprite(seam,pulse(t,S(8),S(8)+.4,E(8)-.3,S(9)));
  const idDown=pulse(t,S(9),S(9)+.6,E(9)-.4,S(10));bridges[0].rotation.x-=idDown*1.3;
  feeds[0].update(t,ramp(t,S(5),S(5)+1)*(1-idDown),.45);line.bead.visible=idDown<.1&&t>=S(3);showSprite(service,idDown);
  frameShots(stage,t,[SHOT.counter,
   {t0:S(1)-.5,t1:S(1)+1,x:1.9,y:1.1,z:.1,w:3.3,e:.65,f:.45},
   {t0:S(3)-.7,t1:S(3)+.7,x:1.9,y:1.95,z:.1,w:3.5,e:.6,f:.45},
   {t0:S(5)-.7,t1:S(5)+1,x:1.9,y:2.8,z:-.1,w:4.1,e:.7,f:.45},
   {t0:S(7)-.7,t1:S(7)+.6,x:1.9,y:4.5,z:-.2,w:3.8,e:.6,f:.45},
   {t0:S(8)-.3,t1:S(8)+.7,x:1.9,y:2.5,z:.1,w:4.2,e:.6,f:.44},
   {t0:S(10)+3,t1:E(10),x:-1.65,y:1.2,z:-.15,w:3.2,e:.45,f:.42}]);
  // Portrait teaching composition: faces above the hand-operated demonstration.
  for(const [i,p] of [maya,applicant].entries()){
   p.reset();p.idle(t,i);placePerson(p,origin,i===0?-.88:.88,.15,i===0?1.02:.48);
   p.look(origin.clone().add(side(0,.8,.45)),1);
  }
  file.visible=false;fromCounter.g.visible=false;line.g.visible=false;
  root.position.copy(origin).add(side(0,.08,.58));root.scale.setScalar(1);root.visible=true;
  decks.forEach(d=>d.visible=false);titles.forEach(o=>o.visible=false);assetLabels.forEach(o=>o.visible=false);
  const recap=t>=S(10)?Math.min(2,Math.floor(ramp(t,S(10),E(10))*3)):-1;
  const identity=t>=S(3)&&t<S(5)||recap===1,network=t>=S(4)&&t<S(10)||recap===2;
  contents[0].visible=false;
  turntable.g.visible=t<S(3)||recap===0;cover.visible=turntable.g.visible&&t<S(2);
  turntable.update(t,assetTimes);turntable.g.position.y=.12+land(t,S(0),.3,.42);
  assets.forEach((o,i)=>{o.visible=t>=S(2)||i===0;o.position.set(0,land(t,t<S(2)?S(0):assetTimes[i],.24,.35),0);o.scale.setScalar(1.08);o.rotation.z=.06*hit(t,assetTimes[i]+.35);});
  cover.position.y=.12;cover.scale.set(1,Math.max(.01,enter(t,S(1)+.3,.7)),1);
  magnified.visible=false;scan.visible=false;
  access.visible=identity&&!network;access.position.set(0,.5,.1);access.scale.setScalar(.95);
  tokens.forEach((o,i)=>{o.visible=(t>=S(3)&&t<S(4)||recap===1)&&i===0;o.position.set(-.65,.35,.25);});
  // The old stacked supplier decks and their hairline feeds are replaced by the graph.
  feeds.forEach(f=>f.g.visible=false);suppliers.forEach(o=>o.visible=false);bridges.forEach(o=>o.visible=false);
  map.position.copy(origin).add(side(0,-.3,.65));map.visible=network;
  nodes.forEach(n=>{n.object.visible=n.type==='service'||n.type===(t<S(5)?'identity':'supplier');});
  links.forEach(l=>{
   if(l.__lineObj){l.__lineObj.visible=l.type===(t<S(5)?'identity':'supplier');
   }
  });
  // A disconnected supply is a physical missing connection, not a thin warning line.
  const outage=interrupted,missing=t>=S(9)?idDown:outage;
  links.forEach(l=>{if(l.__lineObj&&l.type==='supplier'&&l.slot===(t>=S(9)?0:3))l.__lineObj.visible=missing<.5;});
  nodes.filter(n=>n.type==='supplier').forEach(n=>{n.object.position.y=n.y-(n.slot===3?.14*outage:0);});
  city.visible=t>=S(7)&&t<S(8);city.position.set(0,.48,.25);city.scale.setScalar(.85);
  windows.forEach(o=>o.material=outage>.5?stoppedFan:litWindow);
  fan.rotation.z=2*Math.min(t,S(7)+1); // Stops exactly, including after backward seeks.
  stage.outage=outage;
  maya.smile=.3-.28*missing;applicant.smile=.25-.25*missing;
  [allowed,denied,scope,blackOut].forEach(o=>o.visible=false);
  const beat=sentence(t,S,11),start=S(beat),age=t-start;
  // An identity lands, approaches the gate and waits for a deliberate opening.
  if(beat===3){
   access.position.y=.5+land(t,start,.25,.4);
   const open=pulse(t,start+.55,start+1,start+1.4,E(3));access.userData.open(open);
   tokens[0].position.set(lerp(-.65,.28,ramp(t,start+.6,E(3)-.15)),.35+land(t,start,.28,.4),.25);
  }
  const kind=t<S(5)?'identity':'supplier',listing=beat===4||beat===6;
  const networkStart=recap===2?S(10)+2*(E(10)-S(10))/3:start;
  const selected=listing?Math.min(3,Math.floor(clamp(age/(E(beat)-start))*4)):-1;
  // Nodes land in sequence. The fixed graph never advances a physics simulation.
  nodes.forEach(n=>{
   const at=n.type==='service'?networkStart:listing?tableEntry(start,E(beat),n.slot,4):networkStart+n.slot*.12;
   n.object.position.set(n.x,n.y+(network?land(t,at,n.type==='service'?.2:.24,.4):0),n.z);
   n.object.rotation.z=.04*hit(t,at+.4);
   const emphasis=n.type===kind&&n.slot===selected?1+.18*pulse(t,at,at+.35,at+1,at+1.4):1;
   n.object.scale.setScalar(emphasis);
   if(beat===7&&n.type==='supplier'&&n.slot===3)n.object.position.y-=.18*outage;
   if(beat===8&&n.type==='supplier')n.object.position.y-=.12*ramp(t,start+.3,start+1);
  });
  links.forEach(l=>{
   const obj=l.__lineObj;if(!obj)return;
   const at=listing?tableEntry(start,E(beat),l.slot,4):networkStart+l.slot*.12;
   // Links are local cylinders along Z; rebuild their endpoints from this frame's nodes.
   const a=typeof l.source==='object'?l.source:nodes.find(n=>n.id===l.source),z=nodes[0].object.position;
   obj.position.copy(a.object.position);obj.lookAt(graph.localToWorld(z.clone()));obj.scale.z=a.object.position.distanceTo(z)*clamp((t-at-.35)/.4);
   obj.visible=network&&l.type===kind&&t>=at+.35;
   if(l.type==='supplier'&&l.slot===(t>=S(9)?0:3)&&missing>.5)obj.visible=false;
  });
  if(beat===7){
   city.position.y=.48+land(t,start,.26,.4);
   [hospital,traffic,pump].forEach((o,i)=>{o.position.y=land(t,start+i*.13,.2,.35);o.rotation.z=.045*hit(t,S(7)+1.1+i*.12)*outage;});
  }else [hospital,traffic,pump].forEach(o=>{o.position.y=0;o.rotation.z=0;});
  if(recap===0){
   const at=S(10);turntable.update(t,assets.map((_,i)=>at+i*.3));turntable.g.position.y=.12+land(t,at,.25,.4);
  }
  if(recap===1){
   const at=S(10)+(E(10)-S(10))/3;access.userData.open(pulse(t,at+.2,at+.6,at+1.1,at+1.5));
   tokens[0].position.x=lerp(-.65,.25,ramp(t,at+.3,at+1.5));
  }
  // Follow each named item with a hand; concern causes a small, visible retreat.
  const act=pulse(t,start+.1,start+.5,Math.min(start+1.8,E(beat)-.3),E(beat));
  maya.bend=.08*act;applicant.bend=(missing>0?-.08:.06)*act;
  maya.present('R',origin.clone().add(side(selected<0?0:-1.08+selected*.72,.7,.65)),act);
  if(missing>0){placePerson(applicant,origin,.88+.08*missing,.15,.48);applicant.present('L',maya.g.position.clone().setY(1),missing);}
  weight(maya,t,1);weight(applicant,t,3);
  const examine=origin.clone().add(side(selected<0?0:-1.08+selected*.72,.8,.65));
  exchange(maya,applicant,examine,t,start,E(beat));
  exchange(applicant,maya,examine,t,start,E(beat),.45);
  // Hands explain the model, then return to rest; nobody holds a point in empty space.
  maya.present('R',examine,.65*act);applicant.present('R',examine,.3*act*(1-missing));
  maya.bend=.055*act;applicant.bend=.07*act*(1-missing)-.07*missing;
  maya.smile=.1*(1-missing);applicant.smile=.08*(1-missing);
  if(beat===3||beat===10)acknowledge(applicant,t,start+2);
  if(beat===7||beat===9){
   acknowledge(maya,t,start+1.5,true);acknowledge(applicant,t,start+2.1,true,.65);
   const settle=beatWindow(t,start+1.2,E(beat));
   applicant.present('L',maya.g.position.clone().setY(1),.35*settle);
  }
  beads.forEach(({l,j,m})=>{
   const a=typeof l.source==='object'?l.source:nodes.find(n=>n.id===l.source),z=nodes[0].object.position;
   const dead=l.type==='supplier'&&l.slot===(t>=S(9)?0:3)&&missing>.05;
   m.visible=network&&l.__lineObj?.visible&&!dead&&stage.outage<.05;if(!m.visible)return;
   m.position.copy(a.object.position).lerp(z,((t*.55+j/3+(l.slot||0)*.17)%1));
  });
  stage.focus=network?graph:identity?access:turntable.g;
  frameShots(stage,t,[{x:origin.x,y:.64,z:origin.z,w:2.95,e:.24,f:.39}]);
 };
}
