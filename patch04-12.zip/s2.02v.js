// A sign-in page that only looks right.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['omar', 'maya'];
export default chapterHall((S, E, D) => ({
  lesson: '2.1',
  actors: { omar: 'desk', maya: 'beside' },
  shots: [[0,'pair'], [S(1),'desk'], [S(2),'display'], [S(6),'desk'], [S(8),'display'], [S(9),'pair'], [S(13),'desk']],
  actions: {
    omar: [[0,S(7),'read'], [S(7),S(8),'type'], [S(8),S(9),'read'], [S(9),S(13),'talk','maya'], [S(13),D.T,'type']],
    maya: [[0,S(9),'listen','omar'], [S(9),E(9),'talk','omar'], [S(10),D.T,'listen','omar']],
  },
  displays: { desk: [[0,S(2),'mail','Mailbox suspension','alert','inbox'], [S(2),S(7),'lock','Sign in','alert','login'], [S(7),D.T,'mail','Official mailbox','safe','inbox']] },
  plates: [[S(1),E(1),'Mailbox suspension'], [S(2),E(2),'Sign in'], [S(6),E(6),'Page closed'], [S(9),E(9),'One password']],
  pages: [
    hero(S(3), S(6), 'Fake sign-in pages steal credentials', 'made/laptop+lock', [
      ['Username and password', S(3), 'v-amber'],
      ['Check the web address', S(4), 'v-teal'],
    ]),
    hero(S(7), S(9), 'Type the official address yourself', 'computer+link', [
      ['Official mailbox', S(8), 'v-teal'],
    ]),
    hero(S(11), S(13), 'Business email compromise', 'mail+money', [
      ['Requests for money', S(11), 'v-amber'],
    ]),
    hero(S(14), D.T, 'Entered your password? Report now', 'lock+bell', [
      ['Report immediately', S(14), 'v-teal'],
    ]),
  ],
}));
