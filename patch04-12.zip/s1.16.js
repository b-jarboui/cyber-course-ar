// 1.16 The first decision: an urgent AI request, Shaima's safe choice, and a look back over the week.
import { V, C, pulse, mesh, rbox, folder } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, mail, btn, chain, reveal } from './screens.js';
import { office, seat1, typing, call, model, timer, SHOT } from './sets.js';

export const texts = [];
export const cast = ['maya', 'lena'];

export default async function ({ stage, scene, S, E, ui }) {
  const maya = createPerson('maya', scene), lena = createPerson('lena', scene), { w1 } = office(scene);
  await model('desk-phone', scene, -2.42, 0.78, -1.82, 0.13);
  const handset = mesh(rbox(0.05, 0.05, 0.2, 0.02), C.dark, 0, 0, 0, scene);
  const req = (extra = '') => win('Shaima’s inbox', mail('Director’s Office', 'Claims director approval', 'URGENT: new AI service', 'For the Licensing Review, upload today’s applicant records to the new AI service. The Director has approved this.') + extra);

  return t => {
    const k = timer(t, S);
    maya.reset(); lena.reset(); seat1(maya); maya.idle(t, 1); lena.idle(t, 2);
    const stop = pulse(t, S(2), S(2) + 0.6, S(11), S(11) + 0.6);
    const calling = pulse(t, S(9) + 0.3, S(9) + 1, S(10) + 2.4, S(10) + 3);
    typing(maya, w1, t, 1 - stop);
    maya.bend = 0.14 * stop; maya.smile = 0.1 + 0.42 * k(11, 0.8);
    maya.reach('R', V(-2.42, 0.9, -1.82), pulse(t, S(9), S(9) + 0.3, S(9) + 0.4, S(9) + 0.7));
    call(maya, calling);
    handset.visible = calling > 0.3;
    if (handset.visible) { maya.handPos('R', handset.position); handset.rotation.set(1.2, 0.78, 0); }
    lena.go(t, S(12), S(12) + 3, 1.1, -3.2, -1.7, -2.8, -1, -1.2);
    if (t > S(12) + 2.6) { maya.look(lena.g.position.clone().setY(1.6), 1); lena.look(maya.g.position.clone().setY(1.2), 1); lena.smile = 0.45; maya.gaze = 0; }
    ui.lead = 0.5;

    ui.play(t, [
      [S(0), S(1), req()],
      [S(1), S(2), req(row('Claim', 'Director approved', 'warn'))],
      [S(2), S(3), req(row('Refers to', 'Your real project', 'warn'))],
      [S(4), S(5), win('Applicant record', row('Name', 'Yousef Nasser', 'hi') + row('Home address', 'Hidden here', 'hi') + row('Bank details', 'Hidden here', 'hi') + note('Sensitive. It stays in the case system.', 'warn'))],
      [S(5), S(6), q => win('Approved AI tools', row('Search', 'New AI service') + (q > 0.4 ? row('Result', 'No approval found', 'no') : row('Result', 'Searching', 'wait')))],
      [S(6), S(7), win('Authority', row('The message says', 'Director approved', 'warn') + row('Approval record', 'Nothing yet', 'no'))],
      [S(8), S(9), q => win('What should Shaima do?', reveal([row('Upload immediately'), row('Reply to confirm'), row('Verify through approved channels')], q * 1.4))],
      [S(9), S(10), q => win('Verify through approved channels', row('Records', 'Not uploaded', 'ok') + row('Calling', 'Director’s office, from the directory', 'hi'), 'good')],
      [S(10), S(11), q => win('Three steps', reveal([row('Independent check', 'Director’s office called', 'ok'), row('Tool and use', 'Not on the approved list', 'no'), row('Report', 'Sent, reference 3290', 'ok')], q * 1.3))],
      [S(11), S(12), win('Applicant records', row('Location', 'Inside the case system', 'ok') + row('External upload', 'Never started', 'ok') + row('Checks', 'Still in progress', 'wait'), 'good')],
      [S(12), S(13), q => win('The service keeps working', reveal([row('Access', 'Still restricted', 'ok'), row('Details', 'Unchanged', 'ok'), row('Service', 'Available', 'ok')], q * 1.3))],
      [S(13), S(14), q => win('What AI changes', row('The message', 'More polished', 'warn') + (q > 0.4 ? row('Same request', 'Sent to 60 inboxes', 'warn') : ''))],
      [S(14), S(15), q => win('What stays essential', reveal([row('Responsibility', 'Omar owns the report', 'ok'), row('Layered protection', 'Records stayed protected', 'ok'), row('Verification', 'Directory call made', 'ok'), row('Early reporting', 'Receipt 3290', 'ok')], q))],
      [S(15), E(15) + 0.4, q => win('Next: one request, many channels', reveal([row('Email'), row('Websites'), row('Telephone calls'), row('Workplace messages')], q))],
    ]);

    stage.shots(t, [
      SHOT.seated,
      { t0: S(12) + 1.2, t1: S(12) + 3, x: -2.3, y: 1.6, z: -2.4, w: 3, e: 0.42, f: 0.24 },
      { t0: S(14) - 0.2, t1: S(14) + 1, ...SHOT.seated },
    ]);
  };
}
