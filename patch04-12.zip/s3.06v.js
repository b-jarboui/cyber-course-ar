// A face that belongs to two people
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["maya", "omar", "citizenYoung"];
export default chapterHall((S, E, D) => ({
  lesson: "3.2",
  actors: { maya: 'counter', omar: 'colleague', citizenYoung: 'exit' },
  enter: { citizenYoung: S(9) }, walks: { citizenYoung: [[S(9),E(9),'visitor']] },
  shots: [[0,'her'], [S(1),'counterDisplay'], [S(5),'counter'], [S(9),'gathering'], [S(10),'counter'], [S(11),'counterDisplay'], [S(12),'counter']],
  actions: { maya: [[0,S(9),'read'], [S(9),S(10),'type'], [S(10),S(11),'listen','citizenYoung'], [S(11),S(12),'read'], [S(12),S(13),'talk','citizenYoung'], [S(13),D.T,'type']], citizenYoung: [[S(9),S(10),'listen','maya'], [S(10),E(10),'paper'], [S(11),D.T,'listen','maya']], omar: [[0,S(11),'listen','maya'], [S(12),D.T,'listen','citizenYoung']] },
  setupProps: evidence({
    camera: true,
    surfaces: { counter: [[0,S(9),'portrait','Uploaded photo','citizenYoung'], [S(9),S(13),'compare','Uploaded and counter photos','citizenYoung']], 'paper:citizenYoung': [[S(10),E(10),'identity','Original identity document','citizenYoung']] },
    inserts: [[S(1),E(1),'counter'], [S(11),E(11),'counter']],
    pointAt: [[S(11),E(11),'omar','counter']],
  }),
  displays: { counter: [[S(13),D.T,'folder','Referred for review','safe']] },
  plates: [[S(1),E(1),'Uploaded photo'], [S(10),E(10),'Original identity document'], [S(13),E(13),'Referred for review']],
  pages: [
    hero(S(2), S(5), "Face swap and morphing", "made/id_badge+made/laptop", [
      ["Two faces in one photo", S(3), "v-amber"],
    ]),
    hero(S(6), S(9), "Synthetic identity: real and invented data combined", "made/id_badge+made/case_folder", [
      ["Invented personal details", S(6), "v-amber"],
    ]),
    hero(S(9), S(11), "Trust the photo taken here", "made/id_badge+computer", [
      ["Original identity document", S(10), "v-teal"],
    ]),
  ],
}));
