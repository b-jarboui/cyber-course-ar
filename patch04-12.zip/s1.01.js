// 1.01 A service starts with trust: the applicant, the folder, Shaima, and everything turning behind them.
import { THREE, C, V, mesh, rbox, box, cyl, group, folder, ramp, pulse, lerp } from './kit.js';
import { createPerson } from './people.js';
import { frameShots, caseCard, conduit, quietScreens, local, clearForeground, badge, stamp } from './astra.js';
import { records, aiCore } from './objects.js';
import { libraryModel, carousel, dome, glyph, backOut, clamp } from './round2.js';
import { weight, eye, acknowledge, beatWindow } from './colleagues.js';

export const texts = [0, 7, 11];
export const cast = ['maya', 'citizen'];

// A small public building that folds up like a pop-up book.
function authority(parent) {
  const hinge = group(parent), g = group(hinge, 0, 0, 0);
  mesh(rbox(1.12, .07, .66, .02), C.sand, 0, .035, 0, g);
  mesh(rbox(.96, .46, .44, .02), C.paper, 0, .3, -.05, g);
  for (const x of [-.36, -.12, .12, .36]) mesh(cyl(.035, .04, .42, 16), C.wallTop, x, .28, .22, g);
  mesh(rbox(1.08, .07, .62, .02), C.tealD, 0, .54, 0, g);
  mesh(rbox(.26, .3, .02, .01), C.navy, 0, .22, .175, g);
  mesh(cyl(.012, .012, .42, 10), C.metalD, 0, .76, 0, g);
  mesh(box(.2, .12, .01), C.teal, .1, .9, 0, g);
  return hinge;
}

export default async function ({ stage, scene, b, createCounter, S, E, ui }) {
  clearForeground(b);
  createCounter(scene);
  const maya = createPerson('maya', scene), citizen = createPerson('citizen', scene);
  const file = folder(scene, 0, 0, 0, 1.05);
  const receipt = caseCard(scene);

  // Everything behind the service stands on one turntable in front of the counter.
  const spot = V(-.61, 0, 1.03), base = group(scene, spot.x, 0, spot.z); base.rotation.y = Math.PI / 4;
  const holder = () => group();
  const items = [holder(), holder(), holder(), holder(), holder()];
  records(items[0], 0, 0, 0, 1.15);
  badge(items[1]).scale.setScalar(.95);
  (await libraryModel('laptop', items[2], .42)).rotation.y = Math.PI;
  (await libraryModel('Prop_SatelliteDish', items[3], .62)).rotation.y = Math.PI / 4;
  stamp(items[4]).scale.setScalar(1.15);
  const table = carousel(base, items, .82);
  const shield = dome(base, 1.02);
  const building = authority(base);
  const question = group(base, 0, .78, 0);
  await glyph(question, '?', .72, 'amber');
  const decision = group(base, -.22, .2, .15);
  caseCard(decision, 0, 0, 0, .8);
  const decisionStamp = stamp(decision);
  const rack = group(base, -.46, .1, .08), ai = group(base, .46, .1, .08);
  await libraryModel('server-rack', rack, 1);
  const core = aiCore(ai, 0, .34, 0, 1.05);
  const route = conduit(base, [V(-.9, 1.22, -1.1), V(-.78, 1.22, -.52), V(-.55, .85, .1), V(-.46, .62, .35), V(0, .78, .5), V(.46, .62, .35)], C.teal, .032);
  const courier = caseCard(base, 0, 0, 0, .42);
  const rings = [0, 1, 2].map(() => {
    const m = mesh(new THREE.TorusGeometry(.56, .024, 10, 80), new THREE.MeshStandardMaterial({ color: '#7fd8cf', emissive: '#7fd8cf', emissiveIntensity: .6, transparent: true }), -1.2, 0, -.3, scene);
    m.rotation.x = Math.PI / 2; m.castShadow = false; return m;
  });

  // The applicant's phone, with a confirmation tick that appears on its screen.
  const phone = group(scene);
  mesh(rbox(0.11, 0.012, 0.21, 0.008), C.dark, 0, 0, 0, phone);
  const face = (w, d, c, x, z) => { const m = mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ color: c }), x, 0.0072, z, phone); m.rotation.x = -Math.PI / 2; m.castShadow = false; return m; };
  face(0.098, 0.19, '#e4edf7', 0, 0);
  const tick = mesh(new THREE.CircleGeometry(0.03, 28), new THREE.MeshBasicMaterial({ color: C.teal }), 0, 0.0082, -0.025, phone);
  tick.rotation.x = -Math.PI / 2; tick.castShadow = false;

  const A = [1.55, 1.0], B = [-1.2, -0.3], R0 = 0.78, R1 = -Math.PI / 2;
  const HALF = 0.23;
  const atApplicant = V(-1.6, 1.16, -0.3), mid = V(-1.99, 1.17, -0.3), desk = V(-2.3, 1.09, 0.4);
  const hp = V(0, 0, 0), p = V(0, 0, 0), carry = V(0, 0, 0), right = V(0, 0, 0), fwd = V(0, 0, 0);
  const qCarry = new THREE.Quaternion(), qFlat = new THREE.Quaternion(), qDesk = new THREE.Quaternion().setFromAxisAngle(V(0, 1, 0), 0.3);
  const basis = new THREE.Matrix4(), DOWN = V(0, -1, 0), axisY = V(0, 0, 0), keys = V(-2.42, 1.09, -0.45), monitorAt = V(-2.1, 1.47, -0.66);
  const TEACH = { x: -1.3, y: .86, z: .36, w: 3.1, e: .42, f: .4 };
  const named = [0, 1, 2, 3, 4].map(i => S(5) + (E(5) - S(5)) * i / 5);

  return t => {
    const tWalk = S(1) + 1.6, tArrive = S(2) + 0.7;
    const up = ramp(t, tArrive - 0.4, tArrive + 0.6);
    const give = ramp(t, tArrive + 0.9, tArrive + 2.2);
    const lay = ramp(t, S(2) + 1.9, S(2) + 2.5);
    const open = ramp(t, S(2) + 2.05, S(2) + 2.45);
    const phoneUp = 1 - ramp(t, tWalk - 0.5, tWalk + 0.1);
    const atWork = ramp(t, S(2) + 2.5, S(2) + 3.2);
    const teach = ramp(t, S(5) - .6, S(5) + .4);

    citizen.reset(); maya.reset();
    citizen.go(t, tWalk, tArrive, A[0], A[1], B[0], B[1], R0, R1);
    citizen.g.rotation.y = lerp(citizen.g.rotation.y, .7, teach);
    maya.at(-2.8, -0.45, 1.5 + atWork * 0.3);
    citizen.idle(t); maya.idle(t, 2);
    weight(maya, t, 2); if (t >= tArrive) weight(citizen, t, 0);

    const ang = citizen.g.rotation.y, fx = Math.sin(ang), fz = Math.cos(ang);
    citizen.reach('L', hp.set(citizen.g.position.x + fx * 0.3 + fz * 0.04, 1.14, citizen.g.position.z + fz * 0.3 - fx * 0.04), phoneUp);
    phone.visible = phoneUp > 0.03;
    citizen.handPos('L', phone.position); phone.position.y += 0.035;
    phone.rotation.set(0.22, ang, 0, 'YXZ');
    tick.scale.setScalar(Math.max(0.001, ramp(t, S(0) + 0.5, S(0) + 1.1)));

    // Carried at the side, the top edge of the folder sits in the closed right hand.
    citizen.grip.R = 0.95;
    citizen.handPos('R', carry);
    fwd.set(fx, 0, fz);
    axisY.crossVectors(DOWN, fwd).normalize();
    basis.makeBasis(fwd, axisY, DOWN);
    qCarry.setFromRotationMatrix(basis);
    carry.addScaledVector(DOWN, 0.15).addScaledVector(fwd, 0.02);

    // On the counter each person holds one end; Shaima then opens it beside her keyboard.
    p.copy(atApplicant).lerp(mid, give); if (lay > 0) p.lerp(desk, lay);
    p.lerp(carry, 1 - up);
    file.position.copy(p);
    qFlat.identity().slerp(qDesk, lay);
    file.quaternion.copy(qCarry).slerp(qFlat, up);
    file.userData.open(open);

    const release = ramp(t, S(2) + 1.8, S(2) + 2.1);
    citizen.bend = 0.1 * up * (1 - release);
    citizen.grip.R = lerp(.95, .32, release);
    citizen.reach('R', hp.copy(p).add(right.set(HALF, 0.03, 0).applyQuaternion(file.quaternion)), up * (1 - release));
    const hold = pulse(t, tArrive + 1.1, tArrive + 1.9, S(2) + 3.4, S(2) + 3.9);
    maya.bend = 0.1 * hold + 0.08 * atWork * (1 - teach);
    maya.grip.R = lerp(.32, .9, hold);
    maya.reach('R', hp.copy(p).add(right.set(-HALF, 0.03, -.13).applyQuaternion(file.quaternion)), hold);
    // At work: her hands go to the keyboard until the turntable draws her attention.
    const typing = atWork * (1 - teach);
    if (hold < 0.05) {
      maya.reach('R', hp.copy(keys).add(right.set(0, 0.008 * Math.sin(t * 13), .1)), typing);
      maya.reach('L', hp.copy(keys).add(right.set(0, 0.008 * Math.cos(t * 11), -.1)), typing);
    }

    const toShaima = ramp(t, tArrive - 0.4, tArrive + 0.2);
    citizen.head.rotation.x = 0.46 * phoneUp;
    citizen.look(V(-3, 1.5, -0.4), toShaima * (1 - teach));
    maya.look(citizen.g.position.clone().setY(1.5), 1 - atWork);
    if (atWork > 0) maya.look(monitorAt, atWork * (1 - teach));
    const away = ramp(t, S(10) - .6, S(10) + .2);
    if (teach > 0) { maya.look(hp.set(spot.x, .7, spot.z), teach); citizen.look(hp, teach * (1 - away)); }
    if (away > 0) maya.look(citizen.g.position.clone().setY(1.5), away);
    // Acknowledge the arrival, check understanding, and return attention to the person.
    const greeting = beatWindow(t, tArrive - .2, tArrive + 1.1);
    maya.look(eye(citizen), greeting); citizen.look(eye(maya), greeting);
    const checkIn = Math.max(beatWindow(t, S(3) + .3, E(3)), beatWindow(t, S(6) + 1, E(6)), beatWindow(t, S(8) + 1.6, S(8) + 3.4));
    maya.look(eye(citizen), checkIn); citizen.look(eye(maya), checkIn);
    if (t >= S(10)) citizen.look(eye(maya), beatWindow(t, S(10) + .25, S(11) + .5));
    acknowledge(maya, t, tArrive + .1); acknowledge(citizen, t, S(6) + 1.8);
    maya.smile = .12 + .14 * greeting + .1 * ramp(t, S(10), S(11));
    citizen.smile = .06 + .16 * ramp(t, S(6) + 1, S(6) + 2);

    // The digital receipt lifts off the phone, then folds into the carried case.
    const lift = ramp(t, S(0), E(0));
    const fold = ramp(t, S(1) + .5, tWalk + .2);
    receipt.visible = t < tWalk + .2;
    receipt.position.copy(phone.position).add(local(.22 * lift, .07 + .2 * lift, 0)).lerp(file.position, fold);
    receipt.rotation.set(lerp(.22, -.1, lift), ang, 0, 'YXZ');
    receipt.scale.setScalar(lerp(.12, .84, lift) * (1 - fold * .7));

    // The turntable rises out of the floor, then gives way to each following idea in turn.
    const show = ramp(t, S(5) - .5, S(5) + .2) * (1 - ramp(t, S(10) - .6, S(10)));
    base.visible = show > .002; base.scale.setScalar(Math.max(.001, show)); base.position.y = lerp(-.4, 0, show);
    const active = table.update(t, named, S(6), .55);
    const items1 = 1 - ramp(t, S(7) - .2, S(7) + .2);
    table.spin.visible = items1 > .002; table.spin.scale.setScalar(Math.max(.001, items1));
    const guard = pulse(t, S(6), S(6) + .7, S(7) - .3, S(7) + .1);
    shield.visible = guard > .002; shield.scale.setScalar(Math.max(.001, guard)); shield.userData.net.rotation.y = t * .25;
    const rise = backOut(clamp((t - S(7) - .15) / .6)), down = ramp(t, S(8) - .45, S(8) - .05);
    building.visible = t > S(7) && down < 1; building.rotation.x = -(1 - rise) * Math.PI / 2 - down * Math.PI / 2; building.position.z = -.1;
    const q = backOut(clamp((t - S(8)) / .5)) * (1 - ramp(t, S(9) - .35, S(9)));
    question.visible = q > .002; question.scale.setScalar(Math.max(.001, q * .65)); question.rotation.y = .2 * Math.sin(t); question.position.set(.45, .78, 0);
    decision.visible = t >= S(8) && t < S(9); decision.scale.setScalar(Math.max(.001, q));
    decisionStamp.position.y = .08 + .55 * (1 - ramp(t, S(8) + .4, S(8) + 1.2));
    const toRack = ramp(t, S(9) + .2, S(9) + 2.7), toAi = ramp(t, S(9) + 3, S(9) + 5.5);
    const rackK = backOut(clamp((t - S(9) - 2) / .5)), aiK = backOut(clamp((t - S(9) - 3.1) / .5)), inSystems = t >= S(9);
    rack.visible = inSystems && rackK > .002; rack.scale.setScalar(Math.max(.001, rackK));
    ai.visible = inSystems && aiK > .002; ai.scale.setScalar(Math.max(.001, aiK)); core.userData.ring.rotation.z = t * .9;
    const along = .62 * toRack + .38 * toAi;
    route.update(t, inSystems ? Math.max(.02, along) : 0, .15); route.bead.visible = false;
    courier.visible = inSystems && along > .001; route.curve.getPointAt(Math.min(.999, along), courier.position); courier.position.y += .08; courier.rotation.set(.9, 0, 0);

    // Protection rises gently around the applicant, below the face.
    rings.forEach((m, i) => {
      const u = t < S(11) ? 0 : ((t - S(11)) * .55 + i / 3) % 1;
      m.visible = t >= S(11) - .05; m.position.y = .03 + u * 1; m.material.opacity = Math.sin(Math.PI * u) * ramp(t, S(11), S(11) + .4);
    });

    quietScreens(ui, t);
    stage.focus = t < S(2) ? receipt : t < S(5) ? file : t < S(6) ? table.slots[active].lift : null;
    frameShots(stage, t, [
      { x: 1.62, y: 1.38, z: 1.1, w: 1.6, e: 0.46, f: .46 },
      { t0: S(1) - 0.2, t1: S(1) + 0.6, x: 1.62, y: 1.1, z: 1.1, w: 2.6, e: 0.46, f: 0.42 },
      { t0: S(1) + 1.4, t1: tWalk + 1.2, x: 0.7, y: 0.95, z: 0.5, w: 4.4, e: 0.5 },
      { t0: tArrive - 1.4, t1: tArrive + 0.6, x: -1.95, y: 1.15, z: -0.3, w: 3.1, e: 0.42 },
      { t0: S(2) + 3.2, t1: E(2), x: -2.4, y: 1.2, z: -0.1, w: 2.7, e: 0.6 },
      { t0: S(3), t1: S(3) + 1, x: -1.2, y: 1.2, z: -.25, w: 2.5, e: .42 },
      { t0: S(4) - .3, t1: S(4) + .5, x: -2.6, y: 1.3, z: -.45, w: 2.5, e: .42 },
      { t0: S(5) - .9, t1: S(5) + .5, ...TEACH },
      { t0: S(10) - 0.6, t1: S(10) + 0.8, x: -1.2, y: 1.25, z: -.3, w: 2.25, e: .36, f: .44 },
    ]);
  };
}
