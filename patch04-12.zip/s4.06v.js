// The real page behind a fake one.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['priya', 'omar'];
export default chapterHall((S, E, D) => ({
  lesson: '4.2',
  actors: { priya: 'desk', omar: 'beside' },
  landline: 'desk',
  shots: [[0, 'desk'], [S(1), 'display'], [S(2), 'desk'], [S(9), 'pair'], [S(11), 'display'], [S(12), 'desk'], [S(13), 'pair']],
  actions: {
    priya: [[0, S(11), 'read'], [S(11), S(12), 'type'], [S(12), S(13), 'read'], [S(13), S(14), 'extension'], [S(14), D.T, 'type']],
    omar: [[0, S(12), 'listen', 'priya'], [S(12), S(13), 'talk', 'priya'], [S(13), D.T, 'listen', 'priya']],
  },
  displays: {
    desk: [[0, S(1), 'mail', 'Shared payment file', 'neutral', 'inbox'], [S(1), S(11), 'lock', 'Sign in', 'alert', 'login'], [S(11), S(13), 'computer', 'Official sign-in', 'safe', 'login'], [S(13), D.T, 'bell', 'Report sent', 'safe']],
  },
  plates: [[S(0), E(0), 'Rania · Finance'], [S(1), E(1), 'Shared payment file'], [S(11), E(11), 'Address typed directly'], [S(12), E(12), 'No shared file found']],
  pages: [
    hero(S(2), S(4), 'A familiar page is not proof', 'made/laptop+lock', [
      ['Adversary-in-the-middle', S(3), 'v-amber'],
    ]),
    hero(S(4), S(10), 'Codes can be relayed live', 'link+key+lock', [
      ['Session token stolen', S(5), 'v-coral'],
      ['Works without password or code', S(6), 'v-amber'],
    ]),
    hero(S(10), S(13), 'Type the address yourself', 'computer+link+key', [
      ['Passkeys check the real address', S(10), 'v-teal'],
      ['Do not forward the email', S(12), 'v-navy'],
    ]),
    hero(S(14), D.T, 'Entered details? Report at once', 'bell+computer', [
      ['End active sessions', S(15), 'v-teal'],
    ]),
  ],
}));
