// The manager's voice, but not the manager.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['finance', 'maya', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '2.3',
  actors: { finance: 'beside', maya: 'counter', official: 'door' },
  handsets: { finance: [[S(1),S(4),'chat'], [S(4),S(11),'mobile'], [S(14),D.T,'bell']] },
  shots: [[0,'hall'], [S(1),'finance'], [S(3),'finance'], [S(7),'pair'], [S(10),'finance'], [S(11),'finance'], [S(11)+.24*(E(11)-S(11)),'door'], [S(14),'door']],
  walks: { finance: [[(S(11)+E(11))/2,S(11)+.68*(E(11)-S(11)),'aisle'], [S(11)+.68*(E(11)-S(11)),E(11),'office']] },
  actions: {
    finance: [[S(1),S(2),'text'], [S(2),S(4),'call'], [S(4),S(11),'text'], [S(11),(S(11)+E(11))/2,'call'], [E(11),S(14),'listen','official'], [S(14),D.T,'text']],
    official: [[S(11),(S(11)+E(11))/2,'call'], [S(12),D.T,'talk','finance']],
    maya: [[0,S(10),'type'], [S(10),D.T,'listen','finance']],
  },
  plates: [[S(1),E(1),'Voice message'], [S(3),E(3),'Private payment request'], [S(7),E(7),'Another messaging app'], [S(10),E(10),'No reply'], [S(12),E(12),'No payment requested'], [S(14),E(14),'Message retained']],
  pages: [
    hero(S(2), S(3), 'A familiar voice is not proof', 'mobile+made/id_badge', [
      ['Hamad’s voice', S(2), 'v-amber'],
    ]),
    hero(S(4), S(7), 'Deepfakes copy voices and faces', 'mobile+made/headset', [
      ['An imitation of the manager', S(4), 'v-amber'],
    ]),
    hero(S(8), S(10), 'Do not move to a private channel', 'mobile+chat', [
      ['Private payment request', S(8), 'v-amber'],
      ['Request for secrecy', S(9), 'v-amber'],
    ]),
    hero(S(13), S(14), 'Call back on the known number', 'made/register_book+mobile', [
      ['Hamad’s internal extension', S(13), 'v-teal'],
    ]),
  ],
}));
