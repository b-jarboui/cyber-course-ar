// A rumour reaches the hall
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["maya", "omar", "citizen", "citizenYoung", "comms", "supplier"];
export default chapterHall((S, E, D) => ({
  lesson: "3.3",
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor', citizenYoung: 'teamEnd', comms: 'exit', supplier: 'door' },
  walks: { supplier: [[S(13),E(14),'aisle']] },
  shots: [[0,'hall'], [S(1),'counter'], [S(4),'her'], [S(10),'counter'], [S(11),'counterDisplay'], [S(12),'counter'], [S(14),'wide'], [S(15),'staff']],
  actions: { citizen: [[0,S(1),'listen','maya'], [S(1),S(5),'text'], [S(10),D.T,'listen','maya']], maya: [[0,S(10),'listen','citizen'], [S(10),S(12),'type'], [S(12),S(14),'talk','citizen'], [S(15),D.T,'type']], omar: [[0,S(13),'listen','citizen'], [S(13),D.T,'listen','supplier']], citizenYoung: [[S(1),D.T,'text']], comms: [[S(13),D.T,'text']], supplier: [[E(14),D.T,'text']] },
  setupProps: evidence({ surfaces: { 'phone:citizen': [[S(1),S(5),'message','Refunds end tomorrow?']] }, inserts: [[S(2),E(2),'phone:citizen']] }),
  displays: { counter: [[S(11),S(12),'computer','Official website','neutral'], [S(12),S(15),'tick','Refund service open','safe'], [S(15),D.T,'bell','Report sent','safe']] },
  plates: [[S(2),E(2),'Forwarded message'], [S(3),E(3),'Forwarded by a cousin'], [S(14),E(14),'Same message in the queue']],
  pages: [
    hero(S(5), S(6), "Misinformation: false, shared by mistake", "mobile+chat", [
      ["Forwarded by a cousin", S(5), "v-navy"],
    ]),
    hero(S(6), S(10), "Disinformation: false, spread on purpose", "made/laptop+chat", [
      ["Deliberately false claim", S(6), "v-amber"],
    ]),
    hero(S(11), S(14), "Answer from official sources only", "computer+file-text", [
      ["Internal staff notices", S(11), "v-teal"],
      ["Refund service open", S(12), "v-teal"],
    ]),
  ],
}));
