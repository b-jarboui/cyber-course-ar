// Two recordings, one voice
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["official", "maya", "omar", "priya", "lena"];
export default chapterHall((S, E, D) => ({
  lesson: "3.1",
  actors: { official: 'signer', maya: 'counter', omar: 'colleague', priya: 'team', lena: 'director' },
  shots: [[0,'hall'], [S(1),'gathering'], [S(4),'counter'], [S(10),'staff'], [S(15),'gathering']],
  actions: {
    official: [[0,S(2),'talk','maya'], [S(2),S(5),'listen','omar'], [S(5),D.T,'talk','maya']],
    maya: [[0,D.T,'listen','official']], omar: [[0,S(4),'listen','official'], [S(4),E(4),'talk','official']],
    priya: [[0,D.T,'listen','official']], lena: [[0,D.T,'listen','official']],
  },
  setupProps: evidence({
    surfaces: { counterPhone: [[0,S(3),'wave','Recording 1'], [S(3),S(15),'wave','Recording 2']] },
    inserts: [[S(2),E(3),'counterPhone']],
    pointAt: [[S(2),E(3),'official','counterPhone'], [S(15),E(15),'official','counterPhone']],
  }),
  plates: [[S(1),E(1),'Before opening'], [S(4),E(4),'Two recordings']],
  pages: [
    hero(S(5), S(6), "Voice cloning", "mobile+made/headset", [
      ["Two recordings", S(5), "v-navy"],
    ]),
    hero(S(6), S(9), "A few seconds of audio can be enough", "mobile+clock", [
      ["A voicemail", S(7), "v-amber"],
    ]),
    hero(S(11), S(15), "Check the request, not the voice", "made/register_book+mobile", [
      ["Number already on file", S(13), "v-teal"],
      ["Report early", S(14), "v-teal"],
    ]),
  ],
}));
