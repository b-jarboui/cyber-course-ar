// 1.11 Trust arrives through other people: a supplier's access is limited, and two inside cases are reported as facts.
import { V, pulse, ramp } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, chain, reveal } from './screens.js';
import { office, seat1, seat2, typing, desk, timer, SHOT } from './sets.js';

export const texts = [3, 5, 7];
export const cast = ['priya', 'supplier', 'maya', 'omar'];

export default function ({ stage, scene, S, E, ui }) {
  const rania = createPerson('priya', scene), supplier = createPerson('supplier', scene), maya = createPerson('maya', scene), omar = createPerson('omar', scene), { w1, w2 } = office(scene);

  return t => {
    const k = timer(t, S);
    for (const p of [rania, supplier, maya, omar]) p.reset();
    seat1(maya); seat2(omar); maya.idle(t, 1); omar.idle(t, 2); rania.idle(t, 3); supplier.idle(t, 4);
    typing(maya, w1, t, 1 - pulse(t, S(6) + 0.6, S(6) + 1.2, S(8) - 0.5, S(8))); typing(omar, w2, t, 1 - k(11, 0.6));
    // Rania and the supplier talk over his access, standing in the open office.
    rania.at(-0.7, 0.3, 1.6); supplier.at(0.4, 0.45, -1.5);
    rania.look(supplier.g.position.clone().setY(1.6), 1); supplier.look(rania.g.position.clone().setY(1.55), 1);
    supplier.present('R', V(-0.2, 1.1, 0.4), pulse(t, S(0) + 0.5, S(0) + 1.2, S(1) - 0.4, S(1)));
    rania.present('L', V(-0.2, 1.1, 0.4), pulse(t, S(3) + 0.3, S(3) + 1, S(4) - 0.4, S(4)));
    if (t > S(11)) omar.look(maya.g.position.clone().setY(1.2), 1);
    maya.bend = 0.14 * pulse(t, S(6) + 0.6, S(6) + 1.2, S(8) - 0.5, S(8));
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), win('Hosted service', row('Supplier', 'ID check provider') + row('Used by', 'Shaima’s case system', 'ok') + note('Sadeed relies on this every day.'))],
      [S(1), S(2), q => win('Supplier compromised', chain([['Supplier update', 'Tampered with by an attacker', 'no'], ['Case system', 'Affected', 'no'], ['Shaima', 'Work stopped', 'wait']].slice(0, 1 + Math.floor(q * 3))), 'alert')],
      [S(2), S(3), win('Supply-chain risk', row('Their problem') + row('Becomes our problem', '', 'no') + note('It reaches Sadeed through trusted connections.', 'warn'))],
      [S(3), S(4), q => win('Rania reviews supplier access', reveal([row('Task', 'ID checks only', 'ok'), row('Account', 'Limited to that task', 'ok'), row('Monitoring', 'Switched on', 'ok'), row('Next review', 'In 6 months', 'ok')], q))],
      [S(4), S(5), win('Inside the boundary', row('Account', 'Signed in, permitted') + row('Record', 'Used beyond its purpose', 'no') + note('Harm can start from inside.', 'warn'))],
      [S(5), S(6), q => win('Confirmed case review', row('Permitted task', 'Payroll queries') + (q > 0.45 ? row('Actually used for', 'Private address lookups', 'no') : ''), 'alert')],
      [S(6), S(7), q => win('Shaima’s message', row('Sent to', q > 0.45 ? 'All staff, by mistake' : 'Case team') + row('Attachment', 'Application 2048', q > 0.45 ? 'no' : '') + (q > 0.6 ? note('She sees it at once.', 'warn') : ''))],
      [S(7), S(8), win('Two reviews', row('Both cases', 'Beyond the authorized purpose', 'no') + row('Intent', 'Different', 'warn') + note('Different investigations. Access is for an authorized purpose.'))],
      [S(8), S(9), win('Report a concern', row('Observed', 'File sent to all staff') + row('When', 'Today, 10:15') + row('Motive', 'Not required', 'ok'))],
      [S(9), S(10), win('Check report facts', row('Document', 'Application 2048') + row('Observed audience', 'All staff') + row('What I saw', 'Sent in error'))],
      [S(10), S(11), q => q < 0.5 ? win('Draft report', row('“He must be careless”', 'Opinion', 'no')) : win('Draft report', row('“The file reached all staff at 10:15”', 'Fact', 'ok'), 'good')],
      [S(11), E(11) + 0.4, q => win('Omar’s team', reveal([row('Recipient list', 'Checked', 'ok'), row('Message', 'Recalled', 'ok'), row('Investigation', 'Still open', 'wait')], q * 1.3))],
    ]);

    stage.shots(t, [
      { x: -0.1, y: 1.55, z: 0.4, w: 2.8, e: 0.42, f: 0.24 },
      { t0: S(4) - 0.5, t1: S(4) + 0.2, ...SHOT.seated },
      { t0: S(11) - 0.4, t1: S(11) + 0.3, ...SHOT.seated2 },
    ]);
  };
}
