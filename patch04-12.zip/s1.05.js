// 1.05 A single service bridge rests on people, technology and organization.
// Repair the conditions around the person, then watch the same case pass safely.
import { THREE,C,V,mesh,mat,rbox,box,cyl,sph,group,bar,ramp,pulse,lerp } from './kit.js';
import { createPerson } from './people.js';
import { workplace,typing,SHOT } from './sets.js';
import { label,sign,showSprite,appModule } from './objects.js';
import { conduit,caseCard,badge,stamp,frameShots,quietScreens,frac,clearForeground } from './astra.js';
import { placePerson,side,clamp,glyph } from './round2.js';
import { enter,hit,land,sentence } from './motion.js';
import { weight, join, eye, exchange, acknowledge, beatWindow } from './colleagues.js';
import { pierFoot,pierCartridge,pierHead,adjustableSupport } from './detailed-props.js';
export const texts=[1,2,3,7];
export const cast=['maya','omar','lena'];
export default async function({stage,scene,b,S,E,ui}) {
 clearForeground(b);
 const maya=createPerson('maya',scene),omar=createPerson('omar',scene),lena=createPerson('lena',scene);
 const w1=workplace(scene,-3.3,-2.2);
 const root=group(scene,1.9,.1,.1);root.rotation.y=Math.PI/4;
 mesh(rbox(3.1,.12,1.35,.04),C.navy,0,.12,0,root);
 const piers=[],middle=[],spans=[],legends=[];
 for(let i=0;i<3;i++) {
  const x=-1+i;
  const p=group(root,x,.24,0);piers.push(p);
  pierFoot(p);
  const cartridge=pierCartridge(p,i===1?C.powderD:C.teal);cartridge.position.y=.75;middle.push(cartridge);
  pierHead(p);
  const h=group(root,x-.46,1.8,0);spans.push(h);
  // The repair shores stand in front of the piers. Extend the load-bearing
  // deck over them so their heads actually meet its underside.
  mesh(rbox(.94,.08,1.2,.025),C.paper,.46,0,.23,h).name='Service bridge deck';
  bar(V(0,.07,.80),V(.92,.07,.80),.018,C.teal,h);
  legends.push(label(['People','Technology','Organization'][i],root,x,.24,.9,.17));
 }
 const traveling=caseCard(root,-1.4,1.9,0,.62);
 const destination=label('Approved service',root,0,2.62,.1,.22);
 // Pressure is physically visible as a stack leaning over the first support.
 const tasks=group(root,-1,2.35,0),papers=[];
 for(let i=0;i<14;i++){const p=caseCard(tasks,0,i*.055,0,.55);p.rotation.y=i*.11;papers.push(p);}
 const urgent=label('14 waiting · Unusual request',root,0,3.58,.4,.18,C.amber);
 const halt=sign('stop',root,-1,2.4,.6,.3);
 // The approved update is a missing structural piece, held beside its own gap.
 const patch=pierCartridge(root,C.teal);patch.position.set(.65,1,.65);
 const patchLabel=label('Approved update · Not installed',root,0,3.58,.4,.18,C.amber);
 // The approval token keeps returning because the central ownership socket is empty.
 const approval=stamp(root),ownerSocket=group(root,1,2.05,0);
 mesh(rbox(.53,.045,.53,.025),C.navy,0,0,0,ownerSocket);
 const noOwner=sign('q',root,1,2.5,.1,.34);
 const noOwnerLabel=label('Who approves?',root,0,3.58,.4,.2,C.amber);
 const damage=label('Weaknesses reinforce each other',root,0,3.58,.4,.19,C.coral);
 // A warning cube turns from a tangled surface into a simple, readable instruction.
 const warning=group(root,0,2.9,.45);
 mesh(rbox(1.55,.68,.08,.03),C.paper,0,0,0,warning);
 const tangle=group(warning);
 for(let i=0;i<13;i++){const s=mesh(box(.5+(i%3)*.22,.016,.012),C.powderD,Math.sin(i*2.3)*.25,-.24+i*.04,.05,tangle);s.rotation.z=Math.sin(i)*.28;}
 const clear=label('Use the approved portal',warning,0,0,.07,.19,C.teal);
 const warnIcon=sign('alert',warning,-.57,0,.1,.24);
 const simpleWarning=group(warning);
 bar(V(-.35,-.04,.08),V(-.14,-.2,.08),.035,C.teal,simpleWarning);
 bar(V(-.14,-.2,.08),V(.27,.2,.08),.035,C.teal,simpleWarning);
 simpleWarning.position.y=.13;
 const instruction=await glyph(warning,'USE APPROVED PORTAL',.095,'teal');instruction.position.set(0,-.15,.09);
 // A folded detour makes the delay visible. The later repair gives the same case a direct route.
 const detour=conduit(root,[V(-1.4,2.2,.7),V(-.8,2.7,.7),V(.8,2.7,.7),V(.8,3.15,.7),V(-.8,3.15,.7),V(-.8,3.6,.7),V(1.4,3.6,.7)],C.amber,.025);
 const slow=label('Approved process · Hard to find',root,0,4.12,.6,.18,C.amber);
 const supports=[],supportLabels=[];
 for(let i=0;i<5;i++) {
  const x=-1.25+i*.625,p=adjustableSupport(root,x);supports.push(p);
  supportLabels.push(label(['Training','Process','Maintenance','Owner','Support'][i],root,x,2.6,.9,.135));
 }
 const resolved=label('A workable process',root,0,3.1,.35,.23,C.teal);
 const review=label('Review conditions + controls',scene,-2.6,2.22,-1.8,.2);
 const report=conduit(scene,[V(-2.95,.94,-1.8),V(-2.4,1.55,-1.1),V(-2.05,1.25,-2.45)],C.teal,.025);
 const origin=V(-1.9,0,-.3);
 return t=>{
  for(const p of [maya,omar,lena])p.reset();maya.at(-3.25,-2.15,.78);maya.sit(1);maya.idle(t,1);
  const stopping=pulse(t,S(1)+1.4,S(1)+2,S(2)-.3,S(2));typing(maya,w1,t,1-stopping);
  maya.smile=.08+.3*ramp(t,S(8),S(8)+1);omar.idle(t,2);lena.idle(t,3);
  omar.go(t,S(10)-2.6,S(10)+.4,1.2,-1.2,-2.1,-.8,-1,-1.4);
  lena.go(t,S(9)-2,S(9)+.6,1.2,-2.6,-2.05,-2.45,-1,-1.2);
  omar.g.visible=t>=S(10)-2.6;lena.g.visible=t>=S(9)-2;
  if(t>S(9)){lena.look(V(-3.1,1.2,-2),1);lena.present('R',V(-2.8,1.1,-1.7),ramp(t,S(9)+.3,S(9)+.9));maya.look(V(-2.05,1.5,-2.45),.8);}
  if(t>S(10))omar.look(V(-2.8,1.1,-1.7),1);quietScreens(ui,t);
  root.visible=t<S(9)+.4;root.position.y=lerp(-.6,.1,ramp(t,S(0),S(0)+1.2));
  const fixed=ramp(t,S(7),S(7)+4.7);
  middle.forEach((o,i)=>{
   const weak=ramp(t,S(i+1)+.4,S(i+1)+1.3)*(1-fixed);
   o.position.x=weak*(i===0?-.36:.5);o.rotation.z=weak*(i===0?-.2:.18);
   spans[i].rotation.z=weak*(-.08-.24*ramp(t,S(4),S(4)+1));
  });
  const pressure=pulse(t,S(1),S(1)+.6,E(1)-.2,S(2));
  tasks.visible=pressure>0;tasks.rotation.z=-.12*pressure;tasks.position.y=2.35+.05*Math.sin(t*3);
  showSprite(urgent,pressure);showSprite(halt,stopping);
  patch.visible=t>=S(2)&&t<S(7)+4.7;
  patch.position.set(lerp(.65,0,fixed),1,lerp(.65,0,fixed));patch.rotation.y=.3*(1-fixed)*Math.sin(t);
  showSprite(patchLabel,t>=S(2)&&t<S(3)?1:0);
  approval.visible=t>=S(3)&&t<S(4)||t>=S(7)&&t<S(9);
  approval.scale.setScalar(.7);approval.position.set(1+(1-fixed)*.45*Math.sin(t*2.4),2.08,.2);
  showSprite(noOwner,t>=S(3)&&t<S(7)?1:0);showSprite(noOwnerLabel,t>=S(3)&&t<S(4)?1:0);
  showSprite(damage,t>=S(4)&&t<S(5)?1:0);
  warning.visible=t>=S(5)&&t<S(6);const clearer=ramp(t,S(5)+1.3,S(5)+2.4);warning.rotation.y=.15*(1-clearer);
  tangle.visible=clearer<.7;simpleWarning.visible=clearer>=.7;showSprite(clear,clearer);showSprite(warnIcon,1-clearer);
  const maze=pulse(t,S(6),S(6)+.7,E(6)-.3,S(7));detour.update(t,maze,.13);showSprite(slow,maze);
  supports.forEach((o,i)=>{const k=ramp(t,S(7)+i*.75,S(7)+i*.75+1);o.rotation.z=lerp(-Math.PI/2,0,k);o.visible=k>0;showSprite(supportLabels[i],k);});
  showSprite(resolved,ramp(t,S(7)+4.8,S(7)+5.5));
  const blocked=t>=S(1)&&t<S(7)+4.7;
  const q=blocked?Math.min(.27,frac((t-S(0))*.17)):frac((t-S(7)-4.7)*.25);
  traveling.position.set(lerp(-1.4,1.4,q),1.92,0);traveling.rotation.y=.05*Math.sin(t*2);
  legends.forEach(o=>showSprite(o,t<S(7)?1:0));showSprite(destination,t>=S(5)&&t<S(7)?0:1);
  report.update(t,pulse(t,S(8),S(8)+.6,S(9)-.3,S(9)+.1),.3);
  showSprite(review,ramp(t,S(10),S(10)+.7));
  frameShots(stage,t,[{x:1.9,y:1.95,z:.1,w:4.1,e:.6,f:.45},
   {t0:S(1)-.4,t1:S(1)+.6,x:1.65,y:2.45,z:.35,w:3.9,e:.55,f:.45},
   {t0:S(4)-.4,t1:S(4)+.5,x:1.9,y:2.15,z:.1,w:4.1,e:.55,f:.45},
   {t0:S(6)-.4,t1:S(6)+.5,x:1.9,y:2.85,z:.1,w:4.1,e:.55,f:.45},
   {t0:S(7)-.4,t1:S(7)+.8,x:1.9,y:2.2,z:.1,w:4.1,e:.55,f:.45},
   {t0:S(8)+1.8,t1:S(9),x:-2.8,y:1.3,z:-1.9,w:3.5,e:.45,f:.43},
   {t0:S(10)-.6,t1:S(10)+.5,x:-2.6,y:1.3,z:-1.8,w:3.8,e:.45,f:.43}]);
  // Shaima handles the particular weak support; the whole bridge returns for the repair.
  maya.reset();maya.idle(t,1);placePerson(maya,origin,-.88,.15,1.02);
  omar.reset();omar.idle(t,2);
  join(omar,origin,t,S(3)-3,S(3)+.25,3.1,.15,.88,.15,.48);
  lena.reset();lena.idle(t,3);
  join(lena,origin,t,S(9)-3.3,S(9)+.25,-3,-.8,0,-.8,.78);
  maya.look(origin.clone().add(side(0,.65,.7)),1);omar.look(origin.clone().add(side(0,.65,.7)),1);
  lena.look(maya.g.position.clone().setY(1.5),1);
  root.visible=true;root.position.copy(origin).add(side(0,-.1832,.6));root.scale.setScalar(.78);
  root.children[0].visible=false;report.g.visible=false;
  const single=t<S(4),which=t<S(1)?Math.min(2,Math.floor(ramp(t,S(0),E(0))*3)):t<S(2)?0:t<S(3)?1:2;
  const structure=t<S(5)||t>=S(7);
  piers.forEach((p,i)=>{p.visible=structure&&(!single||i===which);p.position.x=single?0:-1+i;});
  spans.forEach((p,i)=>{p.visible=structure&&(!single||i===which);p.position.x=(single?0:-1+i)-.46;});
  tasks.position.set(0,1.85,0);tasks.scale.setScalar(.65);papers.forEach((p,i)=>p.position.y=i*.025);
  patch.position.set(lerp(.7,0,fixed),1,lerp(.45,0,fixed));patch.visible=t>=S(2)&&t<S(3)||t>=S(7)&&t<S(7)+4.7;
  ownerSocket.visible=t>=S(3)&&t<S(4)||t>=S(7);ownerSocket.position.set(single?0:1,1.6,0);
  approval.visible=t>=S(3)&&t<S(4)||t>=S(7);approval.position.set((single?0:1)+.4*Math.sin(t*2.4)*(1-fixed),1.6,.2);
  warning.position.set(0,.95,.15);warning.scale.setScalar(1.45);
  detour.g.position.y=-1.65;detour.g.scale.setScalar(.9);
  supports.forEach(o=>o.visible=t>=S(7)&&o.visible);
  traveling.visible=structure;traveling.position.x=single?0:lerp(-1.4,1.4,q);
  // Hold the pressure stack, then push the patch / take the approval stamp / support the repaired span.
  const targetY=t>=S(1)&&t<S(2)?1.55:t>=S(2)&&t<S(3)?1:t>=S(3)&&t<S(4)?1.6:t>=S(5)&&t<S(6)?1:.9;
  const target=root.localToWorld(V(t>=S(2)&&t<S(3)?.7:-.4,targetY,.2));
  maya.smile=blocked?.06:.18;
  noOwner.visible=false;halt.visible=false;
  const beat=sentence(t,S,11),start=S(beat),age=t-start;
  traveling.rotation.z=0;supports.forEach(o=>o.position.y=.24);
  // Load the supports, rather than leaving a static stack over them.
  piers.forEach((p,i)=>{
   const at=beat===0?S(0)+(E(0)-S(0))*i/3:start;
   p.position.y=.24+(beat===0?land(t,at,.35,.42):0);p.rotation.z=0;
  });
  if(beat===1){
   tasks.scale.setScalar(.85);tasks.position.y=1.85;
   const load=ramp(t,start+.6,start+3.7);
   papers.forEach((p,i)=>{const at=start+i*.23;p.visible=t>=at;p.position.y=i*.052+land(t,at,.62,.4);p.rotation.z=.1*hit(t,at+.4);});
   tasks.rotation.z=-.16*load+.035*hit(t,start+2.7);
   middle[0].position.x=-.34*load;middle[0].rotation.z=-.32*load;
   piers[0].rotation.z=0;spans[0].rotation.z=-.23*load;
   traveling.position.y=1.92-.18*load;
  }else papers.forEach(p=>p.visible=true);
  if(beat===2){
   patch.position.y=1+land(t,start,.4,.45);patch.rotation.z=.25*hit(t,start+.45);
   patch.rotation.y=.35*Math.sin(age*2)*Math.exp(-.5*Math.max(0,age));
   middle[1].position.x=.5*enter(t,start+.6,.55);
   spans[1].rotation.z=-.2*ramp(t,start+.7,start+1.2)+.04*hit(t,start+1.2);
   traveling.position.y=1.92-.1*ramp(t,start+.7,start+1.2);
  }else patch.rotation.z=0;
  if(beat===3){
   const cycle=frac(Math.max(0,age)/2.1),hop=Math.sin(Math.PI*clamp(cycle/.6));
   approval.position.set(.32*Math.cos(age*2.3),1.6+.34*hop,.2);approval.rotation.z=.14*Math.sin(age*3);
   ownerSocket.position.y=1.6+land(t,start,.24,.4);
   omar.present('L',maya.g.position.clone().setY(.95),pulse(t,start+.6,start+1.1,E(3)-.5,E(3)));
   omar.look(maya.g.position.clone().setY(1.5),ramp(t,start+.5,start+1));
  }else{approval.rotation.z=0;ownerSocket.position.y=1.6;}
  if(beat===4){
   middle.forEach((o,i)=>{const k=enter(t,start+i*.35,.45);o.position.x=(i===0?-.36:.5)*k;o.rotation.z=(i===0?-.28:.25)*k;spans[i].rotation.z=-.32*k+.045*hit(t,start+i*.35+.45);});
   traveling.position.y=1.92-.28*ramp(t,start+.4,start+1.3);
  }
  warning.position.y=.95+land(t,S(5),.36,.45);warning.rotation.z=.08*hit(t,S(5)+.45);
  // The tangled strokes peel away before the clear instruction settles into place.
  tangle.children.forEach((o,i)=>{o.position.x=Math.sin(i*2.3)*.25+clearer*(i%2?1:-1)*.55;o.rotation.z=Math.sin(i)*.28+clearer*.6;});
  simpleWarning.scale.setScalar(enter(t,S(5)+1.8,.3));
  instruction.visible=clearer>=.7;instruction.scale.setScalar(enter(t,S(5)+1.8,.3));
  if(beat===6){
   detour.g.position.y=-1.65+.2*(1-enter(t,start,.55));
   traveling.visible=true;traveling.position.copy(detour.curve.getPointAt(.66*ramp(t,start+.3,E(6)-.3))).multiplyScalar(.9);traveling.position.y-=1.65;traveling.position.y+=.07;
   traveling.rotation.z=.08*hit(t,start+1.2);
  }
  if(beat===7){
   // Slide the upright shores into place on the floor; their bases never tip.
   supports.forEach((o,i)=>{const at=start+i*(E(7)-start)/5;o.rotation.z=0;o.position.y=.24;o.position.z=.58+.7*(1-enter(t,at,.6));o.visible=t>=at;});
   patch.position.y=1+.035*hit(t,start+3.8);
   approval.position.y=1.6+.4*(1-ramp(t,start+5.8,start+6.4))+.05*hit(t,start+6.4);
  }
  // The closing sentences still use the same bridge: report, make room, review each support.
  if(beat>=8){
   const q=ramp(t,start+.3,E(beat)-.4);
   traveling.position.set(lerp(-1.35,1.35,q),1.92+land(t,start,.26,.4),0);
   if(beat===8){traveling.position.x=lerp(-1.35,.8,q);omar.present('R',root.localToWorld(traveling.position),beatWindow(t,start+.5,E(8)));}
   if(beat===9){lena.present('R',root.localToWorld(V(0,1.5,0)),pulse(t,start+.2,start+.7,E(9)-.4,E(9)));}
   if(beat===10){
    const i=Math.min(2,Math.floor(q*3));spans.forEach((p,n)=>p.rotation.z=n===i?.06*Math.sin(q*3*Math.PI):0);
    maya.look(root.localToWorld(V(-1+i,1.5,0)),1);omar.look(root.localToWorld(V(-1+i,1.5,0)),1);
   }
  }else if(beat!==7) supports.forEach(o=>{o.position.y=.24;o.position.z=.58;});
  supports.forEach((o,i)=>o.userData.crank.rotation.y=2.5*ramp(t,S(7)+i*(E(7)-S(7))/5,S(7)+i*(E(7)-S(7))/5+.8));
  supports.forEach(o=>{
   const deck=spans[THREE.MathUtils.clamp(Math.floor(o.position.x+1.46),0,2)],a=deck.rotation.z;
   const underside=deck.position.y+(o.position.x-deck.position.x)*Math.tan(a)-.04/Math.cos(a);
   o.userData.setBearing(underside-o.position.y,a);
  });
  const act=pulse(t,start+.15,start+.65,Math.min(start+2,E(beat)-.3),E(beat));
  maya.bend=(beat===1?-.06:.09)*act;maya.present('R',root.localToWorld(V(0,1.2,.1)),act);
  if(beat===1||beat===4)maya.smile=.02;
  // Share the diagnosis, watch a colleague's contribution, then acknowledge the repair.
  const examine=root.localToWorld(V(0,1.4,.1));
  weight(maya,t,1);if(t>=S(3)+.7)weight(omar,t,2);if(t>=S(9)+.7)weight(lena,t,3);
  if(omar.g.visible){
   exchange(maya,beat>=9?lena:omar,examine,t,start,E(beat));
   omar.look(examine,ramp(t,S(3)+.25,S(3)+.8));
   if(t>=S(3)+.8)exchange(omar,maya,examine,t,start,E(beat),.4);
  }
  maya.present('L',target,.45*act);
  if(lena.g.visible){
   lena.look(eye(maya),ramp(t,S(9)+.25,S(9)+.8));
   if(t>=S(9)+.8)exchange(lena,omar,examine,t,start,E(beat),.2);
   lena.bend=.045*act;lena.present('R',examine,.45*act);
  }
  if(beat===3||beat===4){acknowledge(omar,t,start+1.6,true);omar.smile=.02;}
  if(beat>=7){
   const relief=ramp(t,S(7)+4.7,S(7)+5.5);
   maya.smile=.07+.16*relief;omar.smile=.06+.14*relief;lena.smile=.16;
   acknowledge(maya,t,beat===7?S(7)+5:start+1.6);
   acknowledge(omar,t,beat===7?S(7)+5.4:start+2.1);
   if(beat===9)acknowledge(lena,t,start+2.4);
  }
  stage.focus=t>=S(5)&&t<S(6)?warning:t>=S(6)&&t<S(7)?detour.g:single?piers[which]:root;
  frameShots(stage,t,[{x:origin.x,y:.64,z:origin.z,w:3.05,e:.24,f:.39}]);
 };
}
