// Where does my question go?
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'omar', 'citizen'];
export default chapterHall((S, E, D) => ({
  lesson: '6.1',
  actors: { maya: 'counter', omar: 'colleague', citizen: 'visitor' },
  file: [[0, E(0), 0, 1]],
  shots: [[0, 'hall'], [S(1), 'counter'], [S(2), 'staff'], [S(3), 'counterDisplay'], [S(4), 'her'], [S(14), 'counter']],
  actions: {
    maya: [[0, S(1), 'file'], [S(1), S(2), 'read'], [S(2), S(4), 'listen', 'omar'], [S(4), S(14), 'read'], [S(14), D.T, 'listen', 'omar']],
    omar: [[0, S(2), 'listen', 'maya'], [S(2), S(3), 'talk', 'maya'], [S(3), S(14), 'paper'], [S(14), D.T, 'talk', 'maya']],
    citizen: [[0, D.T, 'listen', 'maya']],
  },
  displays: {
    counter: [
      [0, S(1), 'folder', 'Case 2048', 'neutral'],
      [S(1), S(14), 'computer', 'Approved AI assistant', 'neutral'],
      [S(14), D.T, 'bell', 'Check before you type', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Case 2048'],
    [S(1), E(1), 'Approved AI assistant'],
    [S(2), E(2), 'Where does my question go?'],
    [S(14), E(14), 'Know the tool before you type'],
  ],
  pages: [
    hero(S(4), S(7), 'Generative AI and the model', 'made/own_computer+made/own_chat', [
      ['Predicts next words, does not understand', S(5), 'v-amber'],
      ['Can sound sure and still be wrong', S(6), 'v-coral'],
    ]),
    hero(S(7), S(10), 'More than the model', 'made/laptop+made/own_link+made/own_folder', [
      ['Model, instructions, information, tools', S(8), 'v-teal'],
      ['Every connection is a path for information', S(9), 'v-amber'],
    ]),
    hero(S(10), S(14), 'Where your information goes', 'made/case_folder+made/register_book', [
      ['Hosted inside or by a third party', S(10), 'v-navy'],
      ['Keep confidential data out unless approved', S(11), 'v-coral'],
    ]),
    hero(S(14), D.T, 'Know the tool before you type', 'made/signpost+made/own_bell', [
      ['What is it, what can it reach, who approved it?', S(14), 'v-teal'],
      ['Unsure? Stop, verify and report', S(15), 'v-amber'],
    ]),
  ],
}));
