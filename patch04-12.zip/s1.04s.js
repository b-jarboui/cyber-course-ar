// Sample part: 3D catches attention and shows the easy ideas, 2D carries the complex ones.
// 2D opening, 3D at the door, 2D the weakness, 3D the crowd, 2D the risk matrix, then a question.
import { THREE, C, V, mesh, rbox, box, cyl, group, folder, ramp, pulse, lerp } from './kit.js';
import { createPerson } from './people.js';
import { records } from './objects.js';
import { frameShots, quietScreens, clearForeground } from './astra.js';
import { crowd, glyph, side } from './round2.js';

export const texts = [];
export const cast = ['citizenYoung'];

const NS = 'http://www.w3.org/2000/svg';
const INK = '#26305a', TEAL = '#2f7477', CORAL = '#c6543b', AMBER = '#d78c22', SOFT = '#e4dfd3', PAPER = '#fffdf8';
const el = (tag, attrs, parent, text) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (text !== undefined) e.textContent = text; parent?.append(e); return e; };
const write = (p, x, y, s, size, fill = INK, weight = 700, anchor = 'middle') => el('text', { x, y, 'font-size': size, 'font-weight': weight, fill, 'text-anchor': anchor, 'font-family': 'Segoe UI, Arial, sans-serif' }, p, s);

// A plain page that replaces the 3D picture. Header and caption stay above it.
function createBoard() {
  const page = document.createElement('div');
  page.style.cssText = `position:absolute;inset:0;background:#f2eee6;pointer-events:none`;
  document.getElementById('stage').after(page);
  const svg = el('svg', { viewBox: '0 0 360 640', width: '100%', height: '100%', preserveAspectRatio: 'xMidYMid meet' }, page);
  return { page, svg, panel: () => el('g', { opacity: 0 }, svg) };
}

export default async function ({ stage, scene, b, S, E, D, ui }) {
  clearForeground(b);
  b.group.children.forEach(o => { if (o.isGroup && o.position.x > 4.5 && o.position.z > 1.5) o.visible = false; });
  document.getElementById('kicker').textContent = 'Sample · Week 1';
  const g = window.gsap, tl = g.timeline({ paused: true });
  const board = createBoard();

  // ---------- 3D moment one: someone without permission tries the records room ----------
  const P = V(1.2, 0, -.8), door = group(scene, P.x, 0, P.z); door.rotation.y = Math.PI / 4;
  const wallMat = '#e6e0d2';
  mesh(rbox(1.9, 2.6, .18, .01), wallMat, -1.5, 1.3, 0, door);
  mesh(rbox(1.9, 2.6, .18, .01), wallMat, 1.5, 1.3, 0, door);
  mesh(rbox(1.1, .42, .18, .01), wallMat, 0, 2.39, 0, door);
  mesh(rbox(5, .14, .22, .01), C.navy, 0, .07, 0, door);
  for (const x of [-.54, .54]) mesh(rbox(.07, 2.2, .24, .01), C.navyD, x, 1.1, 0, door);
  mesh(rbox(1.15, .07, .24, .01), C.navyD, 0, 2.18, 0, door);
  const glass = mesh(box(1.02, 2.14, .03), new THREE.MeshStandardMaterial({ color: '#bcd4cf', transparent: true, opacity: .32, roughness: .15, depthWrite: false }), 0, 1.08, 0, door); glass.castShadow = false;
  mesh(rbox(.04, .5, .05, .01), C.metal, .4, 1.1, .06, door);
  const inside = group(door, 0, 0, -.7);
  mesh(box(2, 2.4, .05), '#c9c4b8', 0, 1.2, -.42, inside);
  for (const x of [-.34, .34]) records(inside, x, 0, -.2, 2.1, C.navy);
  const name = await glyph(door, 'RECORDS', .13); name.position.set(0, 2.42, .12);
  const reader = group(door, 1.02, 1.22, .1);
  mesh(rbox(.17, .26, .04, .016), C.dark, 0, 0, 0, reader);
  const led = mesh(new THREE.SphereGeometry(.034, 20, 14), new THREE.MeshStandardMaterial({ color: '#555', emissive: '#000' }), 0, .06, .028, reader);
  const halo = mesh(new THREE.TorusGeometry(.062, .009, 10, 40), new THREE.MeshStandardMaterial({ color: '#555', emissive: '#000' }), 0, .06, .026, reader);
  door.updateMatrixWorld(true);
  const readerAt = reader.getWorldPosition(V(0, 0, 0)), through = inside.localToWorld(V(0, 1.2, 0));

  // A dark figure, with no face and no costume: the idea is an unknown person, not a type of person.
  const stranger = createPerson('citizenYoung', scene);
  stranger.g.traverse(o => { if (o.isMesh) { o.material = new THREE.MeshStandardMaterial({ color: '#20263d', roughness: .75 }); o.material.skinning = true; } });
  const from = P.clone().add(side(2.7, 0, .75)), to = P.clone().add(side(.5, 0, .62));

  // ---------- 3D moment two: the same folder, and everyone who can open it ----------
  const spot = V(-1.6, 0, 2.3), plinth = group(scene, spot.x, 0, spot.z);
  mesh(cyl(.5, .54, .1, 64), C.navy, 0, .05, 0, plinth);
  const big = folder(plinth, 0, .13, 0, 1.15); big.rotation.y = Math.PI / 4; big.userData.open(1);
  const flood = crowd(group(scene, spot.x, 0, spot.z), 5, 340, .07);

  // ---------- 2D one: three words ----------
  const p1 = board.panel(), tiles = [['Threat', CORAL], ['Vulnerability', AMBER], ['Risk', TEAL]].map(([s, c], i) => {
    const q = el('g', { opacity: 0 }, p1), y = 170 + i * 96;
    el('rect', { x: 40, y, width: 280, height: 74, rx: 16, fill: PAPER, stroke: c, 'stroke-width': 3 }, q);
    write(q, 180, y + 48, s, 30, c, 800);
    return q;
  });

  // ---------- 2D two: a weakness is a gap in the protection ----------
  const p2 = board.panel();
  write(p2, 180, 128, 'Vulnerability', 34, AMBER, 800);
  write(p2, 180, 158, 'a weakness that could allow harm', 17, INK, 600);
  const bricks = [], gapY = 3;
  for (let i = 0; i < 7; i++) bricks.push(el('rect', { x: 164, y: 196 + i * 36, width: 34, height: 32, rx: 4, fill: C.navy }, p2));
  const file = el('g', {}, p2);
  el('rect', { x: 262, y: 276, width: 62, height: 76, rx: 7, fill: TEAL }, file);
  el('rect', { x: 262, y: 266, width: 30, height: 16, rx: 4, fill: TEAL }, file);
  write(file, 293, 378, 'Records', 16, TEAL);
  const ring = el('circle', { cx: 181, cy: 196 + gapY * 36 + 16, r: 30, fill: 'none', stroke: AMBER, 'stroke-width': 4, opacity: 0 }, p2);
  const gapName = write(p2, 181, 470, 'The gap', 20, AMBER, 800); gapName.setAttribute('opacity', 0);
  const threat = el('g', { opacity: 0 }, p2);
  el('circle', { cx: 56, cy: 196 + gapY * 36 + 16, r: 20, fill: CORAL }, threat);
  const threatName = write(p2, 56, 196 + gapY * 36 + 62, 'Threat', 18, CORAL, 800); threatName.setAttribute('opacity', 0);
  const could = el('line', { x1: 140, y1: 320, x2: 252, y2: 320, stroke: CORAL, 'stroke-width': 4, 'stroke-dasharray': '8 8', opacity: 0 }, p2);

  // ---------- 2D three: risk is likelihood and seriousness together ----------
  const p3 = board.panel(), X = 76, Y = 166, CELL = 76;
  write(p3, 180, 116, 'Risk', 36, TEAL, 800);
  write(p3, 180, 146, 'how likely, and how serious', 17, INK, 600);
  const shades = ['#e7f0e8', '#f7ecd2', '#f6dcd1', '#f1e8cf', '#f6dcd1', '#eeb9a8', '#f6dcd1', '#eeb9a8', '#e0917b'];
  const cells = shades.map((c, i) => el('rect', { x: X + (i % 3) * CELL, y: Y + (2 - Math.floor(i / 3)) * CELL, width: CELL - 4, height: CELL - 4, rx: 6, fill: c, opacity: 0 }, p3));
  const axisX = write(p3, X + 117, Y + 3 * CELL + 24, 'How likely?', 19, INK, 700);
  const axisY = write(p3, 0, 0, 'How serious?', 19, INK, 700); axisY.setAttribute('transform', `translate(${X - 16} ${Y + 117}) rotate(-90)`);
  [axisX, axisY].forEach(o => o.setAttribute('opacity', 0));
  const dot = el('circle', { cx: 0, cy: 0, r: 15, fill: INK, stroke: PAPER, 'stroke-width': 4, opacity: 0 }, p3);
  const at = (i, j) => ({ x: X + i * CELL + 36, y: Y + (2 - j) * CELL + 36 });
  const pills = [['Sensitivity', CORAL], ['Exposure', CORAL], ['Protections', TEAL]].map(([s, c], i) => {
    const q = el('g', { opacity: 0 }, p3), x = 22 + i * 108;
    el('rect', { x, y: 440, width: 102, height: 36, rx: 18, fill: PAPER, stroke: c, 'stroke-width': 2 }, q);
    write(q, x + 51, 464, s, 15, c, 700);
    return q;
  });

  // ---------- 2D four: the question ----------
  const p4 = board.panel();
  write(p4, 180, 130, 'Open to 340 people.', 24, INK, 800);
  write(p4, 180, 162, 'Nobody has misused it yet.', 21, INK, 600);
  write(p4, 180, 208, 'What is this?', 24, TEAL, 800);
  const choices = ['Threat', 'Vulnerability', 'Incident'].map((s, i) => {
    const q = el('g', { opacity: 0 }, p4), y = 240 + i * 74;
    const r = el('rect', { x: 46, y, width: 268, height: 60, rx: 14, fill: PAPER, stroke: SOFT, 'stroke-width': 3 }, q);
    const w = write(q, 180, y + 39, s, 24, INK, 700);
    return { q, r, w };
  });
  const tick = write(p4, 290, 240 + 74 + 41, '✓', 30, PAPER, 800); tick.setAttribute('opacity', 0);

  // ---------- timing ----------
  const show = (p, a, z) => {
    tl.set(p, { opacity: 1 }, a); if (z) tl.set(p, { opacity: 0 }, z);
  };
  const wipe = (a, open) => tl.fromTo(board.page, { clipPath: open ? 'inset(0 0 0 100%)' : 'inset(0 0 0 0%)' }, { clipPath: open ? 'inset(0 0 0 0%)' : 'inset(0 100% 0 0%)', duration: .4, ease: 'power2.inOut', immediateRender: false }, a);
  const a3 = S(1) - .45, a4 = S(3) - .5, a5 = S(4) - .45, a6 = S(5) - .5, a7 = S(7) - .5;
  show(p1, 0, a3 + .4);
  tiles.forEach((q, i) => tl.fromTo(q, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: .4, ease: 'power2.out', immediateRender: false }, S(0) + .25 + i * .55));
  wipe(a3, false);
  tl.set(board.page, { visibility: 'hidden' }, a3 + .41);

  const openBoard = a => { tl.set(board.page, { visibility: 'visible' }, a); wipe(a, true); };
  openBoard(a4); show(p2, a4, a5 + .4);
  bricks.forEach((o, i) => tl.fromTo(o, { opacity: 0, x: -14 }, { opacity: 1, x: 0, duration: .22, immediateRender: false }, a4 + .3 + i * .06));
  tl.fromTo(file, { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a4 + .55);
  tl.fromTo([threat, threatName], { opacity: 0 }, { opacity: 1, duration: .3, immediateRender: false }, a4 + .75);
  tl.to(bricks[gapY], { x: 44, opacity: 0, duration: .45, ease: 'power2.in' }, S(3) + 1.1);
  tl.to(ring, { opacity: 1, duration: .25 }, S(3) + 1.5);
  tl.to(gapName, { opacity: 1, duration: .25 }, S(3) + 1.6);
  tl.to(threat, { x: 96, duration: .9, ease: 'power1.inOut' }, S(3) + 1.8);
  tl.to(could, { opacity: 1, duration: .3 }, S(3) + 2.7);
  wipe(a5, false); tl.set(board.page, { visibility: 'hidden' }, a5 + .41);

  openBoard(a6); show(p3, a6, a7);
  cells.forEach((o, i) => tl.fromTo(o, { opacity: 0 }, { opacity: 1, duration: .2, immediateRender: false }, a6 + .3 + i * .05));
  tl.to(axisX, { opacity: 1, duration: .3 }, S(5) + .6);
  tl.set(dot, { attr: { cx: at(0, 0).x, cy: at(0, 0).y }, opacity: 1 }, S(5) + .6);
  tl.to(dot, { attr: { cx: at(1, 0).x }, duration: .7, ease: 'power2.inOut' }, S(5) + 1.3);
  tl.to(axisY, { opacity: 1, duration: .3 }, S(5) + 2.7);
  tl.to(dot, { attr: { cy: at(1, 1).y }, duration: .7, ease: 'power2.inOut' }, S(5) + 3.3);
  const named = [S(6) + .5, S(6) + 2.1, S(6) + 3.5];
  tl.to(pills[0], { opacity: 1, duration: .25 }, named[0]);
  tl.to(dot, { attr: { cy: at(1, 2).y }, duration: .6, ease: 'power2.inOut' }, named[0] + .2);
  tl.to(pills[1], { opacity: 1, duration: .25 }, named[1]);
  tl.to(dot, { attr: { cx: at(2, 2).x }, duration: .6, ease: 'power2.inOut' }, named[1] + .2);
  tl.to(pills[2], { opacity: 1, duration: .25 }, named[2]);
  tl.to(dot, { attr: { cx: at(1, 2).x, cy: at(1, 1).y }, duration: .8, ease: 'power2.inOut' }, named[2] + .2);

  show(p4, a7);
  choices.forEach(({ q }, i) => tl.fromTo(q, { opacity: 0, x: 18 }, { opacity: 1, x: 0, duration: .3, immediateRender: false }, S(7) + 3.4 + i * .5));
  choices.forEach(({ q, r, w }, i) => {
    if (i === 1) { tl.to(r, { attr: { fill: TEAL, stroke: TEAL }, duration: .3 }, S(8)); tl.to(w, { attr: { fill: PAPER }, duration: .3 }, S(8)); tl.to(tick, { opacity: 1, duration: .3 }, S(8) + .1); }
    else tl.to(q, { opacity: .3, duration: .3 }, S(8));
  });
  tl.set({}, {}, D.T);

  return t => {
    tl.time(t, false);
    quietScreens(ui, t);

    // The door: a walk, one try at the reader, a refusal, a look through the glass. Nothing repeats.
    const walk0 = S(1) - .4, walk1 = S(1) + 2.1, tap = S(1) + 2.7, refused = S(1) + 3.05;
    stranger.reset(); stranger.go(t, walk0, walk1, from.x, from.z, to.x, to.z, -Math.PI / 4, -Math.PI * .75); stranger.idle(t);
    stranger.reach('R', readerAt, pulse(t, walk1 + .2, tap, refused + .5, refused + 1.1));
    stranger.look(through, ramp(t, S(2) + .3, S(2) + 1.2));
    const on = t >= refused;
    led.material.color.set(on ? '#ff3b2f' : '#7c7f86'); led.material.emissive.set(on ? '#ff2a1a' : '#000000'); led.material.emissiveIntensity = on ? 1.8 + Math.sin(t * 9) * .7 : 0;
    halo.material = led.material;

    big.userData.open(1);
    flood.update(t, S(4) + .05, S(4) + 2.8, 1e9);
    stage.focus = null;

    const aim = P.clone().add(side(.42, 0, .25)), near = { x: aim.x, y: 1.2, z: aim.z, w: 3.3, e: .2, f: .44 };
    const room = { x: spot.x, y: .1, z: spot.z, w: 3.5, e: 1.15, f: .46 };
    frameShots(stage, t, [
      near,
      { t0: S(1) + 1.8, t1: S(2) + 2.5, ...near, y: 1.34, w: 2.5 },
      { t0: a5 - .02, t1: a5, ...room },
      { t0: S(4), t1: S(4) + 3, ...room, w: 3.9 },
    ]);
  };
}
