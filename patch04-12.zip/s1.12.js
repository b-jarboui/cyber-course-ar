// 1.12 When a digital problem becomes a public problem: the application stalls at the counter, and people feel it.
import { V, pulse, folder } from './kit.js';
import { createPerson } from './people.js';
import { win, phone, row, note, head, chain, reveal } from './screens.js';
import { atCounter, timer, SHOT } from './sets.js';

export const texts = [3, 4, 7];
export const cast = ['maya', 'citizen', 'citizenWoman', 'citizenYoung'];

export default function ({ stage, scene, createCounter, S, E, ui }) {
  createCounter(scene);
  const maya = createPerson('maya', scene), applicant = createPerson('citizen', scene), woman = createPerson('citizenWoman', scene), young = createPerson('citizenYoung', scene);
  const file = folder(scene, -2.28, 1.09, 0.1, 1.05); file.rotation.y = 0.3; file.userData.open(1);

  return t => {
    const k = timer(t, S);
    const explain = pulse(t, S(0) + 3, S(0) + 3.6, S(1) + 0.2, S(1) + 0.6) + pulse(t, S(9) - 0.5, S(9), 200, 201);
    atCounter(maya, applicant, t, 1 - Math.min(1, explain));
    woman.reset(); young.reset();
    woman.at(3.25, 2.2, -Math.PI / 2 - 0.3); woman.sit(1); woman.idle(t, 3);
    young.at(3.25, 3.2, -Math.PI / 2 - 0.3); young.sit(1); young.idle(t, 4);
    maya.smile = 0.1 + 0.3 * k(10, 0.6); applicant.smile = 0.05 + 0.45 * k(10, 0.6, 1.5);
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), win('Case 2048 · Next step', row('Identity check') + row('Service', 'Unavailable', 'no') + note('Shaima explains the delay to the applicant.', 'warn'), 'alert')],
      [S(1), S(2), win('Case 2048', row('Identity check', 'Failed to connect', 'no') + row('Application', 'Cannot be completed', 'no'), 'alert')],
      [S(2), S(3), phone('Payment status', row('Expected', 'Monday', 'wait') + row('Today', 'Wednesday') + row('Payment', 'Still pending', 'no'))],
      [S(3), S(4), q => win('One shared provider is down', row('Provider', 'Interrupted', 'no') + head('Each one depends on it separately') + reveal([row('Sadeed counter', 'Paused', 'wait'), row('Health office', 'Paused', 'wait'), row('Licensing office', 'Paused', 'wait')], q * 1.3), 'alert')],
      [S(4), S(5), q => win('What people feel', reveal([row('Operational', 'Applications stalled', 'no'), row('Financial', 'Payments delayed', 'no'), row('Societal', 'Queues grow', 'no')], q * 1.3))],
      [S(5), S(6), win('Traffic control centre', row('Signals', 'Out at a junction', 'no') + row('Police', 'Directing traffic', 'ok') + note('Some attacks can also put safety at risk.', 'no'), 'alert')],
      [S(6), S(7), q => win('It depends', row('Out 10 minutes', 'A short wait', 'ok') + (q > 0.35 ? row('Out 2 days', 'Long queues', 'no') : '') + (q > 0.65 ? row('With a paper form', 'Essential work continues', 'ok') : ''))],
      [S(7), S(8), q => win('Prepared in advance', reveal([row('Critical services', 'Identified', 'ok'), row('Paper procedure', 'Rehearsed', 'ok'), row('Test application', 'Completed after recovery', 'ok')], q * 1.3))],
      [S(8), S(9), q => win('Shaima during the outage', reveal([row('Applicant’s file', 'Kept secure', 'ok'), row('Outage', 'Reported early', 'ok'), row('Paper procedure', 'Opened', 'ok')], q * 1.3))],
      [S(10), E(10) + 0.4, q => win('At the counter', reveal([row('Shared only with the applicant', 'Confidential', 'ok'), row('Details checked', 'Integrity', 'ok'), row('Record retrieved', 'Available', 'ok')], q * 1.3), 'good')],
    ]);

    stage.shots(t, [
      SHOT.shaima,
      { t0: S(0) + 2.6, t1: S(0) + 3.4, x: -1.95, y: 1.6, z: -0.35, w: 2.8, e: 0.42, f: 0.24 },
      { t0: S(1) - 0.2, t1: S(1) + 0.4, ...SHOT.shaima },
      { t0: S(4) - 0.2, t1: S(4) + 0.8, x: 3.1, y: 1.3, z: 2.7, w: 2.8, e: 0.46, f: 0.24 },
      { t0: S(7) - 0.5, t1: S(7) + 0.2, ...SHOT.shaima },
      { t0: S(9) - 0.5, t1: S(9) + 0.5, x: -1.5, y: 1.3, z: -0.25, w: 2.3, e: 0.42 },
      { t0: S(10), t1: S(10) + 0.6, x: -1.9, y: 1.6, z: -0.35, w: 2.8, e: 0.42, f: 0.24 },
    ]);
  };
}
