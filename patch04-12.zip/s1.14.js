// 1.14 AI increases operational speed: seen from the defenders' desk, with human review as the limit.
import { V, pulse } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, cols, reveal } from './screens.js';
import { office, seat1, seat2, typing, timer, SHOT } from './sets.js';

export const texts = [1, 3, 5];
export const cast = ['omar', 'analyst'];

export default function ({ stage, scene, S, E, ui }) {
  const omar = createPerson('omar', scene), analyst = createPerson('analyst', scene), { w1, w2 } = office(scene);

  return t => {
    const k = timer(t, S);
    omar.reset(); analyst.reset(); seat1(omar); seat2(analyst); omar.idle(t, 1); analyst.idle(t, 2);
    typing(omar, w1, t); typing(analyst, w2, t);
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), win('Incident summary', row('Harmful file', 'Blocked by defenders', 'ok') + row('Written with', 'AI assistance, likely', 'warn') + note('Reviewed by Omar. No technical detail is shown here.'))],
      [S(1), S(2), win('Analyst’s review', row('AI-assisted analysis', 'Software weakness found', 'warn') + row('AI-assisted file', 'Harmful', 'no') + row('Certainty', 'Medium', 'warn'))],
      [S(2), S(3), q => win('Incident inbox', row('Suspicious messages', `${Math.round(40 + q * 460)} today`, 'warn') + row('Staff accounts targeted', `${Math.round(5 + q * 115)}`, 'warn') + note('Automation repeats the same task at speed.', 'warn'))],
      [S(3), S(4), q => win('Review queue', row('Task 1', q > 0.5 ? 'Approved by a person' : 'Awaiting human approval', q > 0.5 ? 'ok' : 'wait') + row('Task 2', 'Awaiting human approval', 'wait') + note('People still approve the important parts.'))],
      [S(4), S(5), q => win('Delegated task list', head('Goal: sort today’s reports') + reveal([row('Next task chosen', 'Group similar reports', 'ok'), row('No human step', 'Within its limits', 'ok'), row('Delete records', 'Not permitted, stopped', 'no')], q * 1.3))],
      [S(5), S(6), win('Two outputs compared', cols(head('Output A') + row('Task met', '', 'ok'), head('Output B') + row('Incomplete', '', 'no')) + note('Capability varies.', 'warn'))],
      [S(6), S(7), win('Omar’s review', row('Generated item', 'Failed', 'no') + row('AI conclusion', 'Contradicted by logs', 'no') + row('Omar', 'Corrected the record', 'ok'))],
      [S(7), S(8), win('A claim in the news', row('“Fully autonomous attack”', 'Claim', 'warn') + row('Review history', 'People approved each step', 'no') + note('The evidence does not support the claim.', 'warn'))],
      [S(8), S(9), q => win('What defenders do', row('Approved update', 'Completed', 'ok') + (q > 0.5 ? row('New concern', 'Reviewed in 10 minutes', 'ok') : ''))],
      [S(9), S(10), q => win('Three practical actions', reveal([row('Unneeded access', 'Removed', 'ok'), row('Systems', 'Maintained', 'ok'), row('Concern', 'Escalated', 'ok')], q * 1.3))],
      [S(10), E(10) + 0.4, q => win('Check the evidence', reveal([row('“Fully autonomous”', 'No evidence', 'no'), row('“Fully protected”', 'Gaps found', 'no')], q * 1.5) + note('Labels do not tell the whole story.'))],
    ]);

    stage.shots(t, [
      SHOT.seated,
      { t0: S(1) - 0.4, t1: S(1) + 0.3, ...SHOT.seated2 },
      { t0: S(3) - 0.4, t1: S(3) + 0.3, ...SHOT.seated },
      { t0: S(5) - 0.4, t1: S(5) + 0.3, ...SHOT.seated2 },
      { t0: S(6) - 0.4, t1: S(6) + 0.3, ...SHOT.seated },
      { t0: S(9) - 0.4, t1: S(9) + 0.5, ...SHOT.both },
    ]);
  };
}
