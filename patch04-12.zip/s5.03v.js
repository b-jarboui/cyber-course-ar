// Open to anyone, kept too long.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['omar', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '5.1',
  actors: { omar: 'desk', official: 'beside' },
  shots: [[0, 'pair'], [S(1), 'display'], [S(3), 'pair'], [S(9), 'desk'], [S(10), 'display'], [S(11), 'pair'], [S(14), 'desk']],
  actions: {
    omar: [[0, S(9), 'read'], [S(9), S(11), 'type'], [S(11), S(14), 'listen', 'official'], [S(14), D.T, 'type']],
    official: [[0, S(3), 'paper'], [S(3), S(9), 'listen', 'omar'], [S(9), S(11), 'listen', 'omar'], [S(11), D.T, 'talk', 'omar']],
  },
  displays: {
    desk: [
      [0, S(9), 'link', 'Anyone with the link', 'alert'],
      [S(9), S(14), 'lock', 'Named people only', 'safe'],
      [S(14), D.T, 'tick', 'Approved disposal', 'safe'],
    ],
  },
  plates: [
    [S(0), E(0), 'Closed case files'],
    [S(1), E(1), 'Anyone with the link'],
    [S(9), E(9), 'Contractor removed'],
    [S(14), E(14), 'Old counter laptop'],
  ],
  pages: [
    hero(S(4), S(9), 'Named people only', 'folder+link+lock', [
      ['No open-to-anyone links', S(6), 'v-coral'],
      ['Remove finished contractors', S(7), 'v-amber'],
    ]),
    hero(S(10), S(11), 'Approved locations', 'made/filing_cabinet+shield', [
      ['Never personal phones or drives', S(10), 'v-amber'],
    ]),
    hero(S(11), S(12), 'Keep only as long as required', 'calendar+made/case_folder', [
      ['Follow the retention schedule', S(11), 'v-teal'],
    ]),
    hero(S(12), D.T, 'Approved disposal', 'made/laptop+made/shredder+bell', [
      ['Deleting files is not enough', S(14), 'v-amber'],
      ['Close open access and report', S(15), 'v-teal'],
    ]),
  ],
}));
