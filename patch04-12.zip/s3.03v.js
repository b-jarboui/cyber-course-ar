// The right voice, the right answers
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["maya", "citizen"];
export default chapterHall((S, E, D) => ({
  lesson: "3.1",
  actors: { maya: 'desk', citizen: 'visitor' },
  landline: 'desk',
  enter: { citizen: S(13) }, leave: { citizen: S(14) },
  shots: [[0,'desk'], [S(1),'display'], [S(3),'desk'], [S(10),'pair'], [S(13),'counter'], [S(14),'desk']],
  actions: { maya: [[0,S(12),'extension'], [S(12),S(13),'read'], [S(13),S(14),'extension'], [S(14),D.T,'type']], citizen: [[S(13),E(13),'call']] },
  displays: { desk: [[0,S(3),'folder','Case 2048','neutral'], [S(3),S(13),'mobile','Change of mobile number','alert'], [S(13),S(14),'mobile','Number already on file','safe'], [S(14),D.T,'folder','Call noted in file','safe']] },
  setupProps: evidence({
    surfaces: { deskPaper: [[0,D.T,'checklist','Identity check']] },
    inserts: [[S(2),E(2),'deskPaper']],
  }),
  plates: [[S(0),E(0),'Service line'], [S(3),E(3),'Change of mobile number'], [S(13),E(13),'Number already on file']],
  pages: [
    hero(S(4), S(6), "A voice is not proof of identity", "made/headset+made/id_badge", [
      ["Service line", S(4), "v-navy"],
    ]),
    hero(S(6), S(10), "Known answers can be stolen", "made/case_folder+made/id_badge", [
      ["Date of birth", S(6), "v-amber"],
      ["Caller number", S(8), "v-amber"],
    ]),
    hero(S(10), S(13), "Change records only after verification", "made/id_badge+made/case_folder", [
      ["Official digital service", S(11), "v-teal"],
    ]),
  ],
}));
