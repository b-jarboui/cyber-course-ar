// 1.04 Six readings of one folder: possibility, weakness, risk, evidence, event, assessment.
import { THREE,C,V,mesh,mat,rbox,box,cyl,sph,group,bar,ramp,pulse,lerp } from './kit.js';
import { createPerson } from './people.js';
import { workplace,typing,SHOT } from './sets.js';
import { label,sign,showSprite,pawn } from './objects.js';
import { conduit,caseCard,frameShots,quietScreens,frac,clearForeground } from './astra.js';
import { libraryModel,placePerson,side,glyph,clamp,crowd } from './round2.js';
import { enter,hit,land,sentence } from './motion.js';
import { weight, join, eye, acknowledge, beatWindow } from './colleagues.js';
export const texts=[1,3,5,7,10];
export const cast=['maya','omar'];
export default async function({stage,scene,b,S,E,ui}) {
 clearForeground(b);
 const maya=createPerson('maya',scene),omar=createPerson('omar',scene);
 const w1=workplace(scene,-3.3,-2.2),w2=workplace(scene,-.6,-2.6);
 const root=group(scene,1.9,.1,.1);root.rotation.y=Math.PI/4;
 mesh(rbox(2.7,.16,1.6,.04),C.navy,0,.12,0,root);
 const core=caseCard(root,0,1.4,0,1.6);core.rotation.x=1.12;
 const coreLabel=label('Confidential applications',root,0,2.28,.2,.2);
 // A ring of physical boundary slats; the opening grows, while the record stays put.
 const boundary=group(root,0,.55,0),slats=[];
 for(let i=0;i<22;i++) {
  const a=i/22*Math.PI*2;
  const p=group(boundary,Math.sin(a)*.9,0,Math.cos(a)*.65);p.rotation.y=a;
  mesh(rbox(.13,1.24,.035,.01),C.teal,0,.62,0,p);slats.push(p);
 }
 const unknown=pawn(root,-1.25,.3,.65,1.4),unknownLabel=label('Not authorized',root,-1.05,.24,.85,.16,C.amber);
 const potential=sign('q',root,-1.2,1.3,.65,.32);
 const exposure=label('5 permitted / 340 can open',root,0,.48,.9,.18,C.coral);
 const exposed=caseCard(root,1.16,1.35,.65,.85);exposed.rotation.x=1.1;
 const incident=sign('alert',root,1.14,2.04,.65,.34);
 const evidence=label('Access confirmed · Outside team',root,0,.47,.9,.17,C.coral);
 // Risk is a balance, physically loaded by sensitivity and exposure, opposed by protection.
 const scale=group(root,0,2.5,0);
 mesh(cyl(.06,.1,.43),C.metalD,0,.2,0,scale);
 const beam=group(scale,0,.42,0);bar(V(-1,0,0),V(1,0,0),.035,C.sand,beam);
 const pans=[];
 for(const x of [-.86,.86]) {
  bar(V(x,0,0),V(x,-.45,0),.012,C.metal,beam);
  const pan=group(beam,x,-.45,0);pans.push(pan);
  mesh(rbox(.67,.055,.58,.02),C.paper,0,0,0,pan);
 }
 const weights=[mesh(box(.28,.28,.28),C.coral,-.15,.16,0,pans[0]),mesh(box(.25,.25,.25),C.amber,.15,.15,0,pans[0]),mesh(box(.3,.3,.3),C.teal,0,.18,0,pans[1])];
 const likelihood=label('Likelihood + consequence',root,0,3.83,.2,.19);
 const sensitivity=label('Sensitivity · Exposure',root,-.8,2.15,.6,.16,C.coral),protection=label('Protections',root,.86,2.15,.6,.16,C.teal);
 // A continuous observation rail makes the difference between event, alert and proof visible.
 const timeline=conduit(root,[V(-1.15,.8,.7),V(-.8,.9,.7),V(0,.92,.7),V(.8,.9,.7),V(1.15,.8,.7)],C.powderD,.025);
 const dots=Array.from({length:11},(_,i)=>mesh(sph(.055),C.powder,-1.1+i*.22,.92,.7,root));
 const lens=group(root,0,1.37,.8);
 mesh(new THREE.TorusGeometry(.3,.035,10,48),C.amber,0,0,0,lens);bar(V(.2,-.2,0),V(.45,-.5,0),.04,C.navy,lens);
 const assessed=sign('q',root,0,1.96,.85,.32);
 const eventLabel=label('Event · Something happened',root,0,.48,.9,.18);
 const alertLabel=label('Alert · Assess the evidence',root,0,.48,.9,.18,C.amber);
 const terms=['Threat','Vulnerability','Risk','Incident','Event','Alert'];
 const termLabels=terms.map(s=>label(s,root,0,4.3,0,.3));
 const report=conduit(scene,[V(-2.85,.92,-1.85),V(-2,1.9,-1.2),V(-.35,1.5,-1.8),V(-.25,.96,-2.15)],C.teal,.028);
 const reportLabel=label('Report received · 3107',scene,-.55,1.95,-2.55,.18);
 const origin=V(-.1,0,.5);
 const question=await glyph(root,'?',.4,'amber');
 const centre=origin.clone().add(side(.35,0,.2)),flood=crowd(group(scene,centre.x,0,centre.z),5,340);
 const clipboard=await libraryModel('clipboard',root,.55);clipboard.position.set(0,.85,.25);clipboard.rotation.y=.15;
 // This library model lies flat: normalize its longest dimension, not its thin Y axis.
 const clipBounds=new THREE.Box3().setFromObject(clipboard).getSize(V(0,0,0));
 clipboard.scale.multiplyScalar(.66/Math.max(clipBounds.x,clipBounds.y,clipBounds.z));
 clipboard.rotation.set(.72,.15,0);
 const keycard=await libraryModel('Prop_KeyCard',root,.34);keycard.position.set(.65,.7,.2);
 const handReport=await libraryModel('clipboard',scene,.3);
 const reportBounds=new THREE.Box3().setFromObject(handReport).getSize(V(0,0,0));
 handReport.scale.multiplyScalar(.38/Math.max(reportBounds.x,reportBounds.y,reportBounds.z));
 const reportRoute=conduit(scene,[origin.clone().add(side(-.55,.94,.05)),origin.clone().add(side(0,1.05,.15)),origin.clone().add(side(.55,.94,.05))],C.teal,.025);
 return t=>{
  maya.reset();omar.reset();maya.at(-3.25,-2.15,.78);maya.sit(1);omar.at(-.55,-2.55,.78);omar.sit(1);maya.idle(t,1);omar.idle(t,2);
  const noticed=pulse(t,S(3)+.4,S(3)+1,S(11)-.5,S(11));typing(maya,w1,t,1-noticed);typing(omar,w2,t,1-ramp(t,S(12)+1,S(12)+2));
  maya.bend=.18*noticed;maya.smile=.25-.22*noticed;omar.smile=.15;
  const receiving=ramp(t,S(12)+.8,S(12)+1.7);if(receiving>0)omar.look(V(-3.2,1.1,-2.15),receiving);
  if(t>=S(11))maya.look(V(-.55,1.2,-2.55),ramp(t,S(11),S(11)+.7));quietScreens(ui,t);
  const show=pulse(t,S(1)-.4,S(1)+.6,S(11)-.7,S(11)+.2);root.visible=show>.001;root.position.y=lerp(-.8,.1,show);
  let term=t<S(3)?0:t<S(5)?1:t<S(7)?2:t<S(9)?3:t<S(10)?4:5;
  termLabels.forEach((o,i)=>{o.position.y=term>=4?3.15:4.3;showSprite(o,i===term?1:0);});
  const broad=ramp(t,S(3),S(3)+1.2);
  slats.forEach((p,i)=>{const a=i/22*Math.PI*2;p.rotation.z=Math.sin(a)*broad*.6;p.position.x=Math.sin(a)*(.9+broad*.25);p.position.y=-broad*(i>6&&i<15?1.1:0);p.visible=term<4;});
  boundary.rotation.y=.12*Math.sin(t*.7)*(1-broad);
  unknown.visible=term===0||term===1;showSprite(unknownLabel,unknown.visible?1:0);showSprite(potential,term===0?1:0);
  showSprite(exposure,term===1?1:0);
  core.rotation.y=.04*Math.sin(t);core.visible=term<4;
  exposed.visible=term===3;exposed.position.x=lerp(.1,1.16,ramp(t,S(7),S(7)+1));
  showSprite(incident,term===3?1:0);showSprite(evidence,term===3?1:0);showSprite(coreLabel,term<4?1:0);
  scale.visible=term===2;beam.rotation.z=.28*ramp(t,S(5)+.3,S(5)+1.5)-.12*ramp(t,S(6)+2,S(6)+3);
  weights.forEach((o,i)=>o.position.y=(i===2?.18:.16)+.7*(1-ramp(t,S(5)+i*.6,S(5)+i*.6+.6)));
  showSprite(likelihood,term===2?1:0);showSprite(sensitivity,term===2?1:0);showSprite(protection,term===2?1:0);
  timeline.update(t,term>=4?1:0,.18);
  dots.forEach((o,i)=>{o.visible=term>=4;o.position.x=-1.1+frac(t*.12+i/11)*2.2;});
  const alert=term===5;lens.visible=alert;lens.position.x=.65*Math.sin((t-S(10))*.65);
  showSprite(assessed,alert?1:0);assessed.position.x=lens.position.x;
  showSprite(eventLabel,term===4?1:0);showSprite(alertLabel,alert?1:0);
  report.update(t,ramp(t,S(12)+.1,S(12)+1.8),.4);report.bead.position.copy(report.curve.getPointAt(ramp(t,S(12)+.1,S(12)+1.8)));
  showSprite(reportLabel,ramp(t,S(12)+1.1,S(12)+1.65));
  frameShots(stage,t,[SHOT.both,
   {t0:S(1)-.5,t1:S(1)+.5,x:1.9,y:2.1,z:.1,w:3.8,e:.55,f:.46},
   {t0:S(5)-.4,t1:S(5)+.6,x:1.9,y:2.65,z:.1,w:3.8,e:.55,f:.46},
   {t0:S(7)-.4,t1:S(7)+.6,x:1.9,y:2.1,z:.1,w:3.8,e:.55,f:.46},
   {t0:S(9)-.4,t1:S(9)+.4,x:1.9,y:1.7,z:.1,w:3.8,e:.5,f:.46},
   {t0:S(11)-.6,t1:S(11)+.4,...SHOT.both,f:.42},
   {t0:S(12)+1,t1:S(12)+2,x:-.6,y:1.35,z:-2.4,w:2.6,e:.45,f:.43}]);
  // Shaima stands beside, touches and reacts to each mechanism; none is stacked above her.
  // Clear the earlier seated typing pose before the portrait blocking takes over.
  maya.reset();omar.reset();maya.idle(t,1);omar.idle(t,2);
  placePerson(maya,origin,-.94,-.12,1.02);maya.dy=0;
  maya.leg('L',0,0);maya.leg('R',0,0);
  const ending=t>=S(11);
  omar.dy=0;omar.leg('L',0,0);omar.leg('R',0,0);
  join(omar,origin,t,S(11)-3,S(11)+.2,3.1,-.12,.87,-.12,.48);
  root.position.copy(origin).add(side(.35,-.18,.2));root.scale.setScalar(.78);root.visible=!ending;
  boundary.position.y=.4;
  scale.position.y=.65;
  core.visible=false;clipboard.visible=term<4&&term!==2;
  boundary.visible=term<2||term===3;keycard.visible=term===0;
  coreLabel.visible=false;unknownLabel.visible=false;
  scale.visible=term===2;
  const touch=root.localToWorld(V(term===2?-.86:-.85,term===2?1.08:1.5,.2));
  if(!ending){maya.look(root.localToWorld(V(0,1.1,0)),1);}
  else {
   maya.reach('L',origin.clone().add(side(-.5,1.03,.05)),1);
   omar.reach('R',origin.clone().add(side(.5,1.03,.05)),1);
   maya.look(omar.g.position.clone().setY(1.5),1);omar.look(maya.g.position.clone().setY(1.5),1);
  }
  const delivered=ramp(t,S(12),S(12)+1.8);
  handReport.name='colleague-report';handReport.visible=ending;handReport.position.copy(reportRoute.curve.getPointAt(delivered));handReport.rotation.set(.15,.78,0);
  reportRoute.update(t,ending?1:0,.15);reportRoute.bead.visible=false;report.g.visible=false;
  // Motion follows the final portrait placement, so it cannot be overwritten by staging.
  const beat=sentence(t,S,13),start=S(beat),age=t-start;
  clipboard.position.set(0,.85+(beat===0?.6*(1-enter(t,start)):.025*hit(t,start+.6)),.25);
  clipboard.rotation.set(.72+.22*hit(t,start+.65),.15+(beat===4?.32*ramp(t,start+.3,start+1.5):0),0);
  slats.forEach((p,i)=>{
   const a=i/22*Math.PI*2;
   const fall=clamp((t-S(3)-i*.075)/.4);
   p.position.set(Math.sin(a)*.9,.4*(1-enter(t,S(0)+i*.018))-.32*fall,Math.cos(a)*.65);
   p.rotation.set(-Math.cos(a)*fall*1.45,a,Math.sin(a)*fall*1.45);
   // A second bank falls as the broad-sharing example is named.
   if(i%2===0&&t<S(4)){p.position.y=.4*(1-enter(t,S(0)+i*.018));p.rotation.set(0,a,0);}
   if(i%2===0&&t>=S(4)){
    const k=clamp((t-S(4)-(i/2)*.08)/.38);p.position.y=-.32*k;p.rotation.set(-Math.cos(a)*k*1.45,a,Math.sin(a)*k*1.45);
   }
  });
  boundary.rotation.y=0;
  unknown.position.set(lerp(-1.45,-1.02,ramp(t,start+.35,start+1.2))-.07*hit(t,start+1.2),.3+land(t,start,.28),.65);
  unknown.rotation.z=-.1*hit(t,start+1.2);
  keycard.position.set(lerp(-1.4,-.92,ramp(t,S(2)+.4,S(2)+1.6)),.7,.2);
  scale.position.y=.65+(beat===5?land(t,start,.35):0);
  if(term===2){
   const times=beat===5?[start+.35,start+1.05,start+2]:[start,start+(E(6)-start)/3,start+2*(E(6)-start)/3];
   weights.forEach((o,i)=>{o.position.y=(i===2?.18:.16)+land(t,times[i],.7);});
   beam.rotation.z=.19*ramp(t,times[0]+.55,times[0]+.85)+.18*ramp(t,times[1]+.55,times[1]+.85)-.24*ramp(t,times[2]+.55,times[2]+.85)
    +times.reduce((v,a,i)=>v+(i===2?-.13:.13)*hit(t,a+.55),0);
  }
  if(term===3){
   const k=ramp(t,S(7)+.3,S(7)+1.6);exposed.position.set(lerp(.05,1.16,k),1.35+.22*Math.sin(k*Math.PI)+.05*hit(t,S(7)+1.6),.65);
   exposed.rotation.z=.12*hit(t,start+.65);
   keycard.visible=beat===8;keycard.position.set(1.1,.65+land(t,start,.4),.4);
   // Keep the unapproved accessor beside the exposed copy when the evidence is discussed.
   unknown.visible=beat===8;unknown.position.set(.87,.3,.85);unknown.rotation.z=0;
  }
  lens.position.y=1.37+.25*(1-enter(t,S(10)));lens.rotation.z=.35*hit(t,S(10)+.65);
  question.visible=term===0||term===5;question.position.set(term===0?-1.2:lens.position.x,term===0?1.3:1.96,.85);
  question.rotation.y=.5*Math.sin(age*2);potential.visible=assessed.visible=false;
  weight(maya,t,1);if(t>=S(11)+.7)weight(omar,t,2);
  if(!ending){
   const act=pulse(t,start+.2,start+.65,Math.min(E(beat)-.4,start+1.8),E(beat));
   maya.bend=.08*act;maya.smile=[0,1,3,5].includes(term)?.02:.08;
   maya.present('R',root.localToWorld(V(0,1.1,.2)),act);
   // Examine without pretending to touch a distant fence or moving balance.
   maya.present('L',touch,.45*act);maya.gaze=.1*(1-act);
   maya.head.rotation.x+=.025*Math.sin(age*.8);
   if(beat===1||beat===7)maya.bend=-.06*beatWindow(t,start+.7,start+2);
   if(beat===8)acknowledge(maya,t,start+1.3,true);
   if(omar.g.visible){
    omar.look(eye(maya),ramp(t,S(11)-.2,S(11)+.5));
    maya.look(eye(omar),beatWindow(t,S(11)-.5,S(11)+.6));
   }
  }else{
   const exchange=ramp(t,S(12),S(12)+1.8);
   handReport.position.y+=.16*(1-enter(t,S(11),.5))+.1*Math.sin(exchange*Math.PI)+.025*hit(t,S(12)+1.8);
   handReport.rotation.z=.12*hit(t,S(11)+.6)+.08*hit(t,S(12)+1.8);
   maya.present('R',omar.g.position.clone().setY(.95),pulse(t,S(11)+.2,S(11)+.7,E(11)-.3,E(11)));
   omar.bend=.06*pulse(t,S(12)+1,S(12)+1.7,E(12)-.4,E(12));omar.smile=.16;
   // Both palms meet the report during transfer; the receiver then brings it in.
   const offer=ramp(t,S(12),S(12)+.9),take=ramp(t,S(12)+.9,S(12)+1.8);
   const step=.37*pulse(t,S(12)-.3,S(12)+.3,E(12)-.5,E(12));
   placePerson(maya,origin,-.94+step,-.12,1.02);
   placePerson(omar,origin,.87-step,-.12,.48);
   const feet=beatWindow(t,S(12)-.3,S(12)+.3)+beatWindow(t,E(12)-.5,E(12));
   maya.walk((t-S(12)+.3)*5,.24*feet);omar.walk((t-S(12)+.3)*5+Math.PI,.24*feet);
   const shared=origin.clone().add(side(-.03,1.15,0));
   const left=origin.clone().add(side(-.52,1.1,.08)).lerp(shared,offer);
   const right=shared.clone().lerp(origin.clone().add(side(.48,1.1,.08)),take);
   maya.reach('L',left,1-ramp(t,S(12)+1,S(12)+1.5));
   omar.reach('R',right,ramp(t,S(12)+.35,S(12)+.85));
   // The report stays at a solved palm at each end, with an absolute-time handoff.
   const from=maya.handPos('L'),to=omar.handPos('R');
   handReport.position.copy(t<S(12)+.9?from:to);handReport.position.y+=.025;
   const inspect=beatWindow(t,S(12)+.1,S(12)+2.1);
   maya.look(handReport.position,inspect);omar.look(handReport.position,inspect);
   acknowledge(omar,t,S(12)+2);maya.smile=.12+.08*ramp(t,S(12)+1.8,S(12)+2.5);
  }
  flood.update(t,S(4)+.05,S(4)+2.9,S(5)-.15);
  const flooded=t>=S(4)&&t<S(5);
  stage.focus=flooded?null:ending?handReport:term===2?beam:term>=4?lens:term===3?exposed:boundary;
  const close={x:origin.x,y:.64,z:origin.z,w:3.05,e:.24,f:.39};
  frameShots(stage,t,[close,{t0:S(4)-.3,t1:S(4)+.5,...close,w:3.3,e:.5},{t0:S(5)-.4,t1:S(5)+.2,...close}]);
 };
}
