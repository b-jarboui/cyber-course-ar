// New bank details from a trusted supplier.
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['finance', 'admin', 'supplier'];
export default chapterHall((S, E, D) => ({
  lesson: '2.3',
  actors: { finance: 'desk', admin: 'aisle', supplier: 'counter' },
  carryLaptop: ['admin', S(0) + .76 * (E(0) - S(0)), E(0)],
  shots: [[0,'pair'], [S(1),'desk'], [S(2),'display'], [S(4),'pair'], [S(9),'desk'], [S(11),'her'], [S(12),'desk'], [S(14),'pair']],
  walks: { admin: [[S(0),E(0),'beside']] },
  enter: { supplier: S(10) },
  actions: {
    supplier: [[S(10),E(12),'call']],
    admin: [[S(1),S(3),'talk','finance'], [S(3),D.T,'listen','finance']],
    finance: [[0,S(9),'read'], [S(9),S(10),'type'], [S(10),E(12),'call'], [S(13),S(14),'talk','admin'], [S(14),D.T,'type']],
  },
  displays: { desk: [[0,S(2),'mail','Saeed · Supplier','neutral','inbox'], [S(2),S(9),'credit-card','New bank account','alert','inbox'], [S(9),S(10),'clock','Payment on hold','safe'], [S(10),D.T,'mobile','Supplier record','safe']] },
  plates: [[S(1),E(1),'Saeed · Supplier'], [S(2),E(2),'New bank account'], [S(11),E(11),'Bank details unchanged'], [S(14),E(14),'Joint report']],
  pages: [
    hero(S(3), S(9), 'A real thread can carry a fake request', 'mail+file-text', [
      ['Earlier invoice thread', S(3), 'v-amber'],
      ['Same invoice number', S(8), 'v-amber'],
    ]),
    hero((S(9)+E(9))/2, S(10), 'Changed bank details: stop and verify', 'money+clock', [
      ['Payment on hold', S(9), 'v-teal'],
    ]),
    hero((S(10)+E(10))/2, S(11), 'Call the number already on file', 'made/register_book+mobile', [
      ['Supplier record', S(10), 'v-teal'],
    ]),
    hero(S(13), S(14), 'No change without verification', 'made/rubber_stamp+credit-card', [
      ['Verify before saving', S(13), 'v-teal'],
    ]),
  ],
}));
