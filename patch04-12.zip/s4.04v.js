// A new phone, the same person?
import { chapterHall, hero } from './chapter2-hall.js';

export const texts = [];
export const cast = ['maya', 'comms', 'official'];
export default chapterHall((S, E, D) => ({
  lesson: '4.1',
  actors: { maya: 'counter', comms: 'visitor', official: 'colleague' },
  enter: { official: S(13) },
  file: [[S(5), E(5), 0, 1], [S(13), E(13), 1, 1]],
  habits: true,
  handsets: { comms: [[0, S(5), 'mobile']] },
  shots: [[0, 'counter'], [S(1), 'hall'], [S(2), 'counter'], [S(5), 'counterDisplay'], [S(8), 'her'], [S(13), 'staff'], [S(14), 'habits']],
  actions: {
    comms: [[0, S(2), 'text'], [S(2), S(5), 'talk', 'maya'], [S(5), D.T, 'listen', 'maya']],
    maya: [[0, S(5), 'listen', 'comms'], [S(5), S(6), 'file'], [S(6), S(13), 'read'], [S(13), S(14), 'type'], [S(14), D.T, 'listen', 'official']],
    official: [[S(13), D.T, 'talk', 'maya']],
  },
  displays: {
    counter: [[0, S(5), 'mobile', 'Change of mobile number', 'neutral'], [S(5), S(13), 'file-text', 'Official record', 'neutral'], [S(13), D.T, 'tick', 'Identity verified', 'safe']],
  },
  plates: [[S(0), E(0), 'Case 2048'], [S(2), E(2), 'Change of mobile number'], [S(5), E(5), 'Original identity document'], [S(13), E(13), 'Supervisor approval']],
  pages: [
    hero(S(3), S(5), 'Account recovery: the open back door', 'made/padlock_open+mobile', [
      ['Controls reset and sign-in', S(4), 'v-amber'],
    ]),
    hero(S(6), S(10), 'Verify identity by the procedure', 'made/id_badge+made/register_book', [
      ['Basic details are not enough', S(6), 'v-amber'],
      ['Original document against official record', S(8), 'v-teal'],
    ]),
    hero(S(10), S(13), 'Call back on the number on file', 'made/register_book+mobile', [
      ['Lost phone or key? Report at once', S(11), 'v-teal'],
      ['Official IT channel', S(12), 'v-teal'],
    ]),
  ],
}));
