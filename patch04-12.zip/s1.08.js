// 1.08 Locked, copied, destroyed: Shaima loses her files, and the response team decides what to do.
import { V, pulse, ramp, folder } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, chain, cols, reveal } from './screens.js';
import { atCounter, timer, SHOT } from './sets.js';

export const texts = [0, 1, 4, 8];
export const cast = ['maya', 'citizen', 'omar', 'lena'];

export default function ({ stage, scene, createCounter, S, E, ui }) {
  createCounter(scene);
  const maya = createPerson('maya', scene), applicant = createPerson('citizen', scene), omar = createPerson('omar', scene), lena = createPerson('lena', scene);
  const file = folder(scene, -2.28, 1.09, 0.1, 1.05); file.rotation.y = 0.3;

  return t => {
    const k = timer(t, S);
    atCounter(maya, applicant, t, 1 - k(0, 0.5, 2) + k(1, 0.5) * 0);
    omar.reset(); lena.reset(); omar.idle(t, 3); lena.idle(t, 4);
    omar.go(t, S(8) - 0.2, S(8) + 2.6, -4.4, 3, -3.5, -1.2, 0, 0.6);
    lena.go(t, S(9) + 0.2, S(9) + 3, -2.2, 3, -3.6, 0.1, 0, 1.2);
    if (t > S(8) + 2) { omar.look(maya.g.position.clone().setY(1.5), 1); maya.look(omar.g.position.clone().setY(1.6), 1); }
    maya.smile = 0.05; applicant.smile = 0.05;
    ui.lead = 0.5;

    ui.play(t, [
      [S(0), S(1), q => q < 0.5 ? win('Case files', row('Case 2048', 'Cannot open', 'no') + row('Case 2049', 'Cannot open', 'no') + row('Case 2050', 'Cannot open', 'no'), 'alert') : win('Message on screen', row('Your files are encrypted', '', 'no') + row('Demand', 'Pay to get them back', 'no') + note('The applicant is still waiting.', 'warn'), 'alert')],
      [S(1), S(2), win('Stolen information', cols(head('Inside Sadeed') + row('Case 2048', 'Original', 'ok'), head('Outside') + row('Case 2048', 'Stolen copy', 'no')) + note('An unauthorized copy is outside Sadeed.', 'no'), 'alert')],
      [S(2), S(3), q => win('Message from the criminals', row('Threat', 'We will publish these records', 'no') + (q > 0.45 ? row('Could be affected', '340 applicants', 'warn') : ''), 'alert')],
      [S(3), S(4), win('Two different cases', cols(head('Theft only') + row('Files', 'Still open', 'ok') + row('Copy', 'Stolen', 'no'), head('Theft and locked') + row('Files', 'Locked', 'no') + row('Copy', 'Stolen', 'no')))],
      [S(4), S(5), q => win('Case system', row('Records', q > 0.4 ? 'Erased' : 'Disappearing', 'no') + row('Service', 'Cannot retrieve them', 'no') + note('Records erased. Destruction can come with extortion.', 'no'), 'alert')],
      [S(5), S(6), q => win('What each option cannot do', row('Paying the demand', 'Recovery not guaranteed', 'no') + (q > 0.5 ? row('Working backup', 'Restores records', 'ok') + row('Stolen copy', 'Still out there', 'no') : ''))],
      [S(6), S(7), q => win('Three kinds of harm', reveal([row('Staff cannot open files', 'Locked', 'no'), row('Private records exposed', 'Copied', 'no'), row('Records missing', 'Destroyed', 'no')], q * 1.3))],
      [S(7), S(8), win('One incident, Case 2048', row('Access', 'Locked', 'no') + row('Copy', 'Disclosed', 'no') + row('Records', 'Some erased', 'no') + note('These harms can all happen together.', 'no'), 'alert')],
      [S(8), S(9), q => win('Shaima reports immediately', row('What I see', 'Ransom demand, files locked') + row('When', 'Now, 09:40') + (q > 0.55 ? row('Report sent', 'Reference 3201', 'ok') : ''))],
      [S(9), S(10), win('Response plan opened', row('Shaima', 'Stop, keep the screen as it is', 'hi') + row('Do not', 'Reply or pay', 'no') + note('Omar takes over from here.'))],
      [S(10), E(10) + 0.4, q => win('Lina assigns the response', reveal([row('Containment', 'Technical team', 'ok'), row('Recovery', 'Service owner', 'ok'), row('Communication', 'Authorized spokesperson', 'ok'), row('The demand', 'Senior decision only', 'ok')], q))],
    ]);

    stage.shots(t, [
      SHOT.shaima,
      { t0: S(8) + 1.6, t1: S(8) + 2.8, x: -3.1, y: 1.62, z: -0.7, w: 2.6, e: 0.42, f: 0.24 },
      { t0: S(10) - 0.5, t1: S(10) + 0.4, x: -3.2, y: 1.62, z: -0.5, w: 3, e: 0.42, f: 0.24 },
    ]);
  };
}
