// Everyone on the call looked real
import { chapterHall, hero } from "./chapter2-hall.js";
import { evidence } from "./chapter3-evidence.js";

export const texts = [];
export const cast = ["priya", "official", "finance", "supplier"];
export default chapterHall((S, E, D) => ({
  lesson: "3.2",
  actors: { priya: 'desk', official: 'director', finance: 'door', supplier: 'visitor' },
  enter: { official: S(13), finance: D.T, supplier: D.T },
  shots: [[0,'desk'], [S(1),'display'], [S(3),'desk'], [S(10),'pair'], [S(12),'desk'], [S(13),'staff'], [S(14),'desk']],
  actions: { priya: [[0,S(10),'read'], [S(10),S(12),'type'], [S(12),S(13),'dial'], [S(13),S(14),'call'], [S(14),D.T,'type']], official: [[S(13),E(13),'call']] },
  displays: { desk: [[0,S(1),'calendar','Meeting invitation','neutral'], [S(11),S(14),'computer','Meeting ended','safe'], [S(14),D.T,'bell','Report sent','safe']] },
  setupProps: evidence({
    surfaces: { desk: [[S(1),S(11),'meeting','Video meeting',['official','finance','supplier']]], deskPaper: [[0,D.T,'form','Unsigned transfer']], 'phone:priya': [[S(12),S(13),'call','Hamad · Manager']] },
    inserts: [[S(1),E(2),'desk'], [S(3),E(3),'deskPaper']],
  }),
  plates: [[S(0),E(0),'Meeting invitation'], [S(3),E(3),'Unsigned transfer'], [S(13),E(13),'Hamad is downstairs']],
  pages: [
    hero(S(4), S(10), "Live video can be faked", "made/laptop+made/headset", [
      ["Video meeting", S(4), "v-amber"],
    ]),
    hero(S(10), S(13), "Leave the call; verify outside it", "mobile+made/register_book", [
      ["Meeting ended", S(11), "v-navy"],
      ["Internal directory", S(12), "v-teal"],
    ]),
    hero(S(15), D.T, "Approvals don't happen on a call", "file-text+made/rubber_stamp", [
      ["Unsigned transfer", S(15), "v-teal"],
    ]),
  ],
}));
