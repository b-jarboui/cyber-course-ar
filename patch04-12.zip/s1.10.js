// 1.10 The weakness in the software: a real update, a delay, an unknown flaw, and the safe way to get help.
import { V, pulse } from './kit.js';
import { createPerson } from './people.js';
import { win, row, note, head, btn, mail, reveal } from './screens.js';
import { office, seat1, seat2, typing, timer, SHOT } from './sets.js';

export const texts = [0, 1, 3, 6];
export const cast = ['omar', 'maya', 'helpdesk'];

export default function ({ stage, scene, S, E, ui }) {
  const omar = createPerson('omar', scene), maya = createPerson('maya', scene), helpdesk = createPerson('helpdesk', scene), { w1, w2 } = office(scene);

  return t => {
    const k = timer(t, S);
    omar.reset(); maya.reset(); helpdesk.reset(); seat2(omar); seat1(maya); omar.idle(t, 1); maya.idle(t, 2); helpdesk.idle(t, 3);
    typing(omar, w2, t); typing(maya, w1, t);
    helpdesk.go(t, S(10) + 1, S(10) + 3.2, -0.2, 0.2, -2.45, -1.0, 0, -1.5);
    if (t > S(10) + 3) { maya.look(helpdesk.g.position.clone().setY(1.6), 1); helpdesk.look(maya.g.position.clone().setY(1.2), 1); }
    ui.lead = 0.6;

    ui.play(t, [
      [S(0), S(1), win('Case application', row('Version', '4.2') + row('Notice', 'Configuration weakness found', 'warn') + note('Software can have weaknesses, even when it works well.'))],
      [S(1), S(2), q => win('Supplier advisory', row('Fix', 'Update 4.3 available', 'ok') + (q > 0.5 ? row('Omar’s team', 'Preparing it', 'wait') : ''))],
      [S(2), S(3), win('Update postponed', row('Version', 'Still 4.2', 'no') + row('Known weakness', 'Open for 21 days', 'no') + note('Delay leaves the door open.', 'no'), 'alert')],
      [S(3), S(4), win('A different, newly found flaw', row('Unusual activity', 'In the case system', 'no') + row('Supplier', 'Fix not yet available', 'no') + row('Omar', 'Temporary protection on', 'ok'), 'alert')],
      [S(4), S(5), q => win('Known issues list', row('Before today', 'This flaw not listed', 'wait') + (q > 0.5 ? row('Now', 'Added by the supplier', 'ok') : '') + note('In this case, exploitation revealed the flaw. No patch was available.', 'warn'))],
      [S(5), S(6), win('No patch yet', row('Patch', 'Not available', 'no') + row('Work', 'Continues, with care', 'ok') + note('So security cannot rely on patching alone.', 'warn'))],
      [S(6), S(7), q => win('Other protections stay on', reveal([row('Access', 'Unneeded request denied', 'ok'), row('Monitoring', 'Being reviewed', 'ok'), row('Configuration', 'Checked', 'ok'), row('Response team', 'Ready', 'ok')], q))],
      [S(7), S(8), q => win('Update on Shaima’s laptop', q < 0.5 ? row('Approved update', 'Ready') + btn('Install now', 'ok') : row('Update', 'Stopped at 60%', 'no') + row('Support ticket', 'Raised, 3244', 'ok'))],
      [S(8), S(9), q => win('Omar plans the rollout', reveal([row('Test workstation', 'Update passed', 'ok'), row('Service check', 'Working', 'ok'), row('Live update', 'Tonight, with the owner', 'ok')], q * 1.3))],
      [S(9), S(10), win('Unexpected message', mail('IT Repair Tool', 'Unknown sender', 'Your software is broken', 'Click here to fix it now.') + note('Shaima leaves it unopened.', 'no'), 'alert')],
      [S(10), E(10) + 0.4, q => win('Sadeed support portal', row('Problem', 'Update stopped at 60%') + (q > 0.5 ? row('Ticket', 'Received by helpdesk', 'ok') : ''), 'good')],
    ]);

    stage.shots(t, [
      SHOT.seated2,
      { t0: S(7) - 0.5, t1: S(7) + 0.2, ...SHOT.seated },
      { t0: S(8) - 0.5, t1: S(8) + 0.2, ...SHOT.seated2 },
      { t0: S(9) - 0.5, t1: S(9) + 0.2, ...SHOT.seated },
    ]);
  };
}
