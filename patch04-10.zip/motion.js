// Small absolute-time motion curves. No simulation or previous-frame state.
import { backOut, clamp } from './round2.js';
export const enter=(t,start,duration=.65)=>backOut(clamp((t-start)/duration));
export const hit=(t,start)=>{const d=t-start;return d<0?0:Math.exp(-4.8*d)*Math.sin(15*d);};
// A falling object accelerates, contacts its support, then makes two small bounces.
export function land(t,start,height=.45,duration=.55) {
 const u=clamp((t-start)/duration),d=Math.max(0,t-start-duration);
 return height*(1-u*u)+.075*Math.exp(-7*d)*Math.abs(Math.sin(16*d));
}
export function sentence(t,S,count) {
 let i=0;for(let n=1;n<count;n++)if(t>=S(n))i=n;return i;
}
