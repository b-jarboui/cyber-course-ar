// Quiet acting curves. All poses are absolute-time; no state survives a seek.
import { V, ramp, pulse } from './kit.js';
import { side } from './round2.js';

export const beatWindow = (t, a, b) => pulse(t, a, a + .3, Math.max(a + .3, b - .3), b);
export function weight(p, t, seed = 0) {
  const shift = Math.sin(t * .47 + seed * 1.7);
  p.sway += .014 * shift;
  p.dy += .003 * Math.sin(t * .83 + seed);
  p.swing.L += .025 * shift; p.swing.R -= .02 * shift;
}
export function eye(p) {
  p.g.updateMatrixWorld(true);
  return p.g.localToWorld(p.P.Bip01_Head.clone().add(V(0, 12, 0)));
}
export function acknowledge(p, t, at, shake = false, amount = 1) {
  const u = (t - at) / 1.05;
  if (u <= 0 || u >= 1) return;
  const turn = Math.sin(u * Math.PI * 2) * Math.sin(u * Math.PI) * amount;
  if (shake) p.head.rotation.y += .085 * turn;
  else p.head.rotation.x += .09 * turn;
}
// Look down to examine, then check the other person's response and listen.
export function exchange(p, other, target, t, start, end, delay = 0) {
  p.look(target, 1); p.gaze = .08;
  const glance = beatWindow(t, start + 1.35 + delay, Math.min(end, start + 3.25 + delay));
  const listen = beatWindow(t, Math.max(start + 3.5, end - 1.7 + delay * .25), end + .15);
  const contact = Math.max(glance, listen);
  p.look(eye(other), contact); p.gaze *= 1 - contact;
}
// Start beyond the portrait edge and turn along the real path before settling.
export function join(p, origin, t, a, b, u0, d0, u1, d1, finalRotation) {
  const from = origin.clone().add(side(u0, 0, d0)), to = origin.clone().add(side(u1, 0, d1));
  const heading = Math.atan2(to.x - from.x, to.z - from.z);
  p.go(t, a, b, from.x, from.z, to.x, to.z, heading, finalRotation);
  p.g.visible = t >= a;
}
