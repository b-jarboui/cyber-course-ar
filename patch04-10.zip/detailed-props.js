// Original, scene-local prop geometry. All moving parts are posed by scene time.
import { THREE,C,V,mesh,mat,rbox,box,cyl,group,bar } from './kit.js';

const steel=mat('#b8c5ca',{metalness:.65,roughness:.32});
const iron=mat('#42505c',{metalness:.5,roughness:.48});
const enamel=mat(C.teal,{metalness:.22,roughness:.35});
const concrete=mat('#c7bfae',{roughness:.95});
function bolt(p,x,y,z,r=.018) {
 const o=mesh(cyl(r,r,.014,6),steel,x,y,z,p);o.rotation.x=Math.PI/2;return o;
}

export function shutter(parent,s) {
 const g=group(parent,s*.22,.3,0);g.name='Sliding privacy shutter';
 mesh(rbox(.426,.604,.075,.015),enamel,0,0,0,g);
 // Folded horizontal slats, side stiles and a recessed lower panel.
 for(let i=0;i<8;i++){
  mesh(rbox(.365,.043,.022,.008),i%2?C.teal:C.tealD,0,-.245+i*.068,.048,g).rotation.x=-.12;
 }
 for(const x of [-.202,.202])mesh(rbox(.022,.59,.023,.006),steel,x,0,.045,g);
 for(const y of [-.288,.288])mesh(rbox(.42,.024,.027,.006),iron,0,y,.043,g);
 const x=-s*.135;
 bar(V(x,-.06,.08),V(x,.08,.08),.013,steel,g);
 for(const y of [-.065,.085])bar(V(x,y,.045),V(x,y,.08),.012,steel,g);
 for(const x of [-.14,.14]){
  const wheel=mesh(cyl(.028,.028,.025,16),iron,x,.322,0,g);wheel.rotation.x=Math.PI/2;
 }
 return g;
}

export function shutterTrack(parent) {
 for(const y of [-.025,.655]){
  mesh(rbox(1.65,.045,.12,.012),iron,0,y,-.015,parent);
  mesh(rbox(1.6,.012,.025,.004),steel,0,y+.026,.035,parent);
 }
 for(const x of [-.81,.81])bolt(parent,x,.654,.06);
}

export function screwClamp(parent,s) {
 const g=group(parent,s*.38,.28,0);g.name='Screw clamp';
 const body=group(g,0,-.28,0);body.scale.x=-s;
 // A cast C frame, open toward the record, rather than a rectangular block.
 const q=new THREE.Shape();
 q.moveTo(.13,.04);q.lineTo(-.035,.04);q.quadraticCurveTo(-.15,.04,-.15,.15);
 q.lineTo(-.15,.46);q.quadraticCurveTo(-.15,.56,-.04,.56);q.lineTo(.13,.56);
 q.lineTo(.13,.46);q.lineTo(-.025,.46);q.lineTo(-.025,.15);q.lineTo(.13,.15);q.closePath();
 const frame=mesh(new THREE.ExtrudeGeometry(q,{depth:.12,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.014,bevelThickness:.014}),iron,0,0,-.06,body);
 frame.name='Cast C clamp frame';
 mesh(cyl(.024,.024,.47,16),steel,.105,.39,0,body);
 for(let i=0;i<13;i++){
  const thread=mesh(new THREE.TorusGeometry(.026,.006,4,16),steel,.105,.2+i*.027,0,body);thread.rotation.x=Math.PI/2;
 }
 mesh(cyl(.062,.047,.035,20),steel,.105,.18,0,body);
 mesh(rbox(.13,.025,.16,.009),C.tealD,.095,.145,0,body);
 const handle=group(body,.105,.64,0);
 bar(V(-.11,0,0),V(.11,0,0),.013,steel,handle);
 for(const x of [-.115,.115])mesh(cyl(.021,.021,.032,16),iron,x,0,0,handle).rotation.z=Math.PI/2;
 g.userData.handle=handle;return g;
}

export function walkway(parent,length=1.3,width=.38) {
 const g=group(parent);g.name='Hinged steel walkway';
 for(const z of [-width/2,width/2]){
  mesh(rbox(length,.075,.034,.009),enamel,length/2,-.01,z,g);
  for(let i=0;i<=4;i++){
   const x=length*i/4;
   bar(V(x,0,z),V(x,.2,z),.011,steel,g);
   bolt(g,x,-.005,z+.022,.012);
  }
  bar(V(0,.2,z),V(length,.2,z),.013,enamel,g);
  bar(V(0,.105,z),V(length,.105,z),.008,steel,g);
 }
 for(let i=0;i<16;i++)mesh(rbox(length/16-.008,.028,width-.025,.005),i%2?steel:iron,(i+.5)*length/16,.025,0,g);
 const hinge=mesh(cyl(.055,.055,width+.08,24),steel,0,0,0,g);hinge.rotation.x=Math.PI/2;
 return g;
}

export function abutment(parent,x) {
 const g=group(parent,x,.05,0);g.name='Concrete bridge abutment';
 mesh(rbox(.46,.14,.65,.025),concrete,0,0,0,g);
 mesh(rbox(.48,.032,.67,.012),C.sand,0,.083,0,g);
 for(const z of [-.24,.24]){
  mesh(rbox(.37,.04,.07,.008),iron,0,.116,z,g);
  for(const dx of [-.13,.13])bolt(g,dx,0,z>0?.333:-.333,.014);
 }
 for(const dx of [-.15,0,.15])mesh(box(.005,.075,.008),C.sandD,dx,-.015,.327,g);
 return g;
}

export function pierFoot(parent) {
 const g=group(parent);g.name='Anchored pier footing';
 mesh(rbox(.5,.06,.57,.024),concrete,0,.03,0,g);
 mesh(cyl(.145,.218,.36,8),concrete,0,.24,0,g);
 mesh(rbox(.41,.065,.5,.015),steel,0,.465,0,g);
 for(const x of [-.18,.18])for(const z of [-.22,.22]){
  mesh(cyl(.018,.018,.07,6),iron,x,.09,z,g);
  mesh(cyl(.033,.033,.018,6),steel,x,.078,z,g);
 }
 return g;
}

// Removable load-bearing cartridge: the existing weakness/patch animation moves this whole part.
export function pierCartridge(parent,colour=C.teal) {
 const g=group(parent);g.name='Bolted braced pier cartridge';
 const finish=mat(colour,{metalness:.35,roughness:.4});
 for(const y of [-.222,.222])mesh(rbox(.46,.045,.53,.01),steel,0,y,0,g);
 for(const x of [-.17,.17])for(const z of [-.2,.2]){
  mesh(rbox(.038,.42,.038,.006),finish,x,0,z,g);
  for(const y of [-.21,.21])bolt(g,x,y,z+.025,.019);
 }
 for(const z of [-.205,.205]){
  bar(V(-.17,-.2,z),V(.17,.2,z),.021,finish,g);
  bar(V(.17,-.2,z),V(-.17,.2,z),.021,finish,g);
  bolt(g,0,0,z+.025,.026);
 }
 return g;
}

export function pierHead(parent) {
 const g=group(parent);g.name='Forked pier head and bridge bearing';
 mesh(cyl(.13,.15,.22,8),concrete,0,1.115,0,g);
 for(const x of [-1,1]){
  bar(V(0,1.17,0),V(x*.18,1.43,0),.085,concrete,g);
  mesh(rbox(.16,.045,.43,.012),iron,x*.17,1.47,0,g);
  mesh(rbox(.16,.035,.43,.008),steel,x*.17,1.51,0,g);
 }
 return g;
}

export function adjustableSupport(parent,x) {
 const g=group(parent,x,.24,.58);g.name='Adjustable steel shore';
 mesh(rbox(.33,.05,.36,.014),iron,0,.025,0,g);
 mesh(cyl(.065,.077,.83,20),enamel,0,.46,0,g);
 const shaft=mesh(cyl(.039,.039,.648,20),steel,0,1.104,0,g);
 const holes=[];for(let i=0;i<7;i++)holes.push(bolt(g,0,.91+i*.075,.041,.012));
 for(const dx of [-.13,.13])bar(V(dx,.05,0),V(0,.36,0),.023,enamel,g);
 for(let i=0;i<6;i++){
  const ring=mesh(new THREE.TorusGeometry(.068,.009,5,20),steel,0,.77+i*.027,0,g);ring.rotation.x=Math.PI/2;
 }
 const crank=group(g,0,.88,0);
 const wheel=mesh(new THREE.TorusGeometry(.12,.014,7,28),iron,0,0,0,crank);wheel.rotation.x=Math.PI/2;
 for(const a of [0,Math.PI/2])bar(V(-.12*Math.cos(a),0,-.12*Math.sin(a)),V(.12*Math.cos(a),0,.12*Math.sin(a)),.01,steel,crank);
 const head=group(g,0,1.52,0);
 head.name='Articulating shore bearing';
 mesh(rbox(.22,.06,.42,.012),enamel,0,-.052,0,head);
 mesh(rbox(.20,.024,.34,.006),iron,0,-.012,0,head);
 g.userData.crank=crank;
 // The base stays anchored. The telescoping stem and articulating bearing
 // follow the underside while the damaged deck returns to level.
 g.userData.setBearing=(top,slope=0)=>{
  head.position.y=top;head.rotation.z=slope;
  const end=top-.080;
  shaft.position.y=end-.648/2;
  holes.forEach((o,i)=>{o.position.y=end-.53+i*.075;o.visible=o.position.y>.89;});
 };
 g.userData.setBearing(1.52);
 return g;
}

export function identityService(parent,rack) {
 const g=group(parent);g.name='Identity service equipment';
 const server=rack.clone(true);g.add(server);server.position.x=-.09;
 // A card reader and a physical ID badge distinguish the identity service from generic computing.
 const reader=group(g,.17,.22,.12);
 mesh(rbox(.2,.31,.075,.025),iron,0,0,0,reader);
 mesh(rbox(.15,.19,.012,.012),C.glass,0,.025,.045,reader);
 mesh(new THREE.SphereGeometry(.034,16,10),C.teal,0,.06,.061,reader).scale.z=.25;
 mesh(rbox(.08,.044,.009,.014),C.teal,0,-.015,.059,reader);
 mesh(rbox(.12,.016,.012,.004),C.dark,0,-.116,.047,reader);
 bar(V(.17,.02,.08),V(.17,.1,.08),.025,steel,g);
 mesh(rbox(.13,.18,.015,.012),C.sand,.2,.07,.21,g).rotation.z=-.12;
 mesh(rbox(.07,.026,.008,.006),C.teal,.2,.095,.222,g);
 return g;
}

export function paymentTerminal(parent) {
 const g=group(parent);g.name='Payment card terminal';
 mesh(rbox(.29,.045,.27,.025),iron,0,.023,0,g);
 const body=group(g,0,.275,0);body.rotation.x=-.35;
 mesh(rbox(.29,.48,.115,.045),iron,0,0,0,body);
 mesh(rbox(.245,.195,.015,.016),C.dark,0,.109,.065,body);
 mesh(rbox(.211,.157,.009,.009),C.glass,0,.109,.077,body);
 bar(V(-.059,.112,.085),V(-.015,.073,.085),.011,C.teal,body);
 bar(V(-.015,.073,.085),V(.065,.153,.085),.011,C.teal,body);
 for(let y=0;y<4;y++)for(let x=0;x<3;x++)mesh(rbox(.05,.035,.018,.008),y===3?[C.coral,C.sand,C.teal][x]:steel,(x-1)*.072,-.028-y*.045,.071,body);
 mesh(rbox(.19,.016,.02,.005),C.dark,0,-.222,.064,body);
 mesh(rbox(.22,.07,.1,.018),C.navyD,0,.24,-.006,body);
 mesh(rbox(.15,.104,.007,.005),C.paper,0,.29,.052,body);
 for(let i=0;i<3;i++)mesh(box(.095-i*.014,.005,.003),C.metalD,0,.265+i*.022,.057,body);
 return g;
}

export function telecomTower(parent) {
 const g=group(parent);g.name='Lattice telecom tower';
 const point=(i,y)=>{const a=i*Math.PI*2/3;const r=.17-(y/.64)*.125;return V(Math.sin(a)*r,y,Math.cos(a)*r);};
 for(let i=0;i<3;i++){
  const foot=point(i,0);mesh(rbox(.1,.035,.1,.008),concrete,foot.x,.017,foot.z,g);
  bar(point(i,.03),point(i,.64),.013,steel,g);
  for(let k=0;k<4;k++){
   const a=k*.15+.03,b=a+.15;
   bar(point(i,a),point((i+1)%3,a),.009,iron,g);
   bar(point(i,a),point((i+1)%3,b),.008,steel,g);
   bar(point((i+1)%3,a),point(i,b),.008,steel,g);
  }
  const a=i*Math.PI*2/3;
  const panel=group(g,Math.sin(a)*.105,.565,Math.cos(a)*.105);panel.rotation.y=a;
  mesh(rbox(.065,.215,.033,.014),C.paper,0,0,0,panel);
  for(const y of [-.07,.07])bar(V(0,y,0),V(0,y,-.06),.009,iron,panel);
 }
 bar(V(0,.61,0),V(0,.77,0),.009,iron,g);
 mesh(new THREE.SphereGeometry(.022,12,8),C.coral,0,.775,0,g);
 const dish=mesh(new THREE.SphereGeometry(.07,20,12,0,Math.PI*2,0,Math.PI/2),C.paper,.1,.36,.11,g);dish.rotation.x=Math.PI/2;
 bar(V(.1,.36,.11),V(.1,.36,.2),.007,iron,g);
 return g;
}

export function powerTransformer(parent) {
 const g=group(parent);g.name='Distribution transformer';
 mesh(rbox(.45,.045,.39,.02),concrete,0,.022,0,g);
 mesh(rbox(.31,.31,.26,.035),enamel,0,.22,0,g);
 for(const x of [-.18,.18])for(let i=0;i<7;i++)mesh(rbox(.045,.23,.018,.005),steel,x,.2,-.108+i*.036,g);
 mesh(rbox(.38,.035,.32,.012),iron,0,.39,0,g);
 for(const x of [-.12,0,.12]){
  mesh(cyl(.016,.021,.13,16),C.sandD,x,.462,0,g);
  for(let i=0;i<4;i++)mesh(cyl(.033,.036,.013,18),C.paper,x,.42+i*.025,0,g);
  mesh(cyl(.016,.016,.035,12),steel,x,.54,0,g);
 }
 const cable=new THREE.CatmullRomCurve3([V(.12,.55,0),V(.24,.48,0),V(.24,.16,.07),V(.2,.065,.13)]);
 mesh(new THREE.TubeGeometry(cable,16,.012,8,false),iron,0,0,0,g);
 const q=new THREE.Shape();q.moveTo(.015,.11);q.lineTo(-.06,-.015);q.lineTo(-.005,-.015);q.lineTo(-.03,-.1);q.lineTo(.07,.035);q.lineTo(.015,.035);q.closePath();
 mesh(new THREE.ExtrudeGeometry(q,{depth:.006,bevelEnabled:false}),C.sand,0,.22,.137,g);
 for(const x of [-.125,.125])bolt(g,x,.34,.143,.012);
 return g;
}

export function civicHospital(parent,windows) {
 const g=group(parent,-.9,0,0);g.name='Miniature hospital';
 mesh(rbox(.74,.035,.59,.018),concrete,0,.018,0,g);
 for(const x of [-.23,.23]){
  mesh(rbox(.21,.43,.43,.015),C.paper,x,.25,0,g);
  mesh(rbox(.23,.035,.46,.009),C.sand,x,.48,0,g);
  for(const y of [.2,.34])for(const dx of [-.047,.047])windows.push(mesh(rbox(.062,.082,.012,.005),C.sand,x+dx,y,.223,g));
 }
 mesh(rbox(.25,.59,.48,.018),C.paper,0,.325,0,g);
 mesh(rbox(.29,.028,.52,.008),C.sand,0,.63,0,g);
 mesh(rbox(.17,.21,.016,.008),C.navyD,0,.155,.25,g);
 for(const x of [-.043,.043])windows.push(mesh(rbox(.071,.173,.01,.004),C.sand,x,.16,.264,g));
 mesh(box(.01,.18,.012),steel,0,.16,.274,g);
 mesh(rbox(.31,.027,.17,.008),steel,0,.286,.294,g);
 for(const x of [-.115,.115])bar(V(x,.04,.35),V(x,.28,.35),.009,steel,g);
 mesh(rbox(.32,.025,.13,.007),C.sand,0,.04,.31,g);
 mesh(rbox(.13,.032,.015,.004),C.teal,0,.485,.251,g);
 mesh(rbox(.032,.13,.015,.004),C.teal,0,.485,.251,g);
 mesh(rbox(.14,.045,.13,.009),steel,-.2,.522,-.04,g);
 for(let i=0;i<4;i++)mesh(box(.1,.003,.008),iron,-.2,.547,-.08+i*.025,g);
 return g;
}

export function trafficSignal(parent,windows) {
 const g=group(parent);g.name='Hooded traffic signal';
 mesh(rbox(.22,.045,.22,.018),concrete,0,.022,0,g);
 mesh(cyl(.024,.035,.73,20),iron,0,.405,0,g);
 mesh(rbox(.214,.465,.075,.035),iron,0,.665,-.015,g);
 mesh(rbox(.17,.42,.08,.026),C.dark,0,.665,.026,g);
 for(let i=0;i<3;i++){
  const y=.535+i*.13;
  const rim=mesh(new THREE.TorusGeometry(.048,.01,8,24),iron,0,y,.081,g);
  windows.push(mesh(new THREE.SphereGeometry(.039,18,12),i===0?C.teal:C.sandD,0,y,.087,g));
  const hood=mesh(new THREE.CylinderGeometry(.06,.06,.085,20,1,true,Math.PI/2,Math.PI),iron,0,y+.006,.102,g);hood.rotation.x=Math.PI/2;
 }
 for(const y of [.51,.78])bar(V(0,y,-.06),V(0,y,-.105),.013,steel,g);
 return g;
}

export function waterPump(parent,windows) {
 const g=group(parent,.85,0,0);g.name='Motor driven water pump';
 mesh(rbox(.59,.05,.45,.02),concrete,0,.025,0,g);
 for(const x of [-.18,.18])mesh(rbox(.13,.065,.3,.01),iron,x,.08,0,g);
 // Horizontal electric motor, cooling fins, volute, flanged inlet and rising discharge pipe.
 const motor=mesh(cyl(.126,.126,.27,28),enamel,-.13,.235,0,g);motor.rotation.x=Math.PI/2;
 for(let i=0;i<7;i++){
  const fin=mesh(new THREE.TorusGeometry(.127,.012,6,28),iron,-.13,.235,-.12+i*.036,g);
 }
 const housing=mesh(cyl(.14,.14,.125,28),steel,.13,.235,0,g);housing.rotation.x=Math.PI/2;
 bar(V(-.03,.235,0),V(.13,.235,0),.04,iron,g);
 const pipe=new THREE.CatmullRomCurve3([V(.13,.3,0),V(.13,.48,0),V(.2,.54,0),V(.35,.54,0)]);
 mesh(new THREE.TubeGeometry(pipe,20,.036,12,false),enamel,0,0,0,g);
 const flange=mesh(cyl(.064,.064,.025,20),steel,.34,.54,0,g);flange.rotation.z=Math.PI/2;
 bar(V(.13,.235,.03),V(.13,.235,.27),.042,enamel,g);
 const inlet=mesh(cyl(.073,.073,.025,24),steel,.13,.235,.24,g);inlet.rotation.x=Math.PI/2;
 for(let i=0;i<4;i++){const a=i*Math.PI/2;bolt(g,.13+Math.sin(a)*.055,.235+Math.cos(a)*.055,.258,.009);}
 const fan=group(g,-.13,.235,.153);fan.name='Pump motor fan';
 mesh(cyl(.027,.027,.02,16),steel,0,0,0,fan).rotation.x=Math.PI/2;
 for(let i=0;i<3;i++){
  const blade=group(fan);blade.rotation.z=i*Math.PI*2/3;
  mesh(rbox(.062,.041,.01,.012),C.teal,.056,.012,0,blade).rotation.z=.45;
 }
 for(const r of [.1,.13])mesh(new THREE.TorusGeometry(r,.008,6,28),steel,-.13,.235,.177,g);
 for(const a of [0,Math.PI/3,Math.PI*2/3])bar(V(-.13-Math.cos(a)*.12,.235-Math.sin(a)*.12,.18),V(-.13+Math.cos(a)*.12,.235+Math.sin(a)*.12,.18),.004,iron,g);
 windows.push(mesh(new THREE.SphereGeometry(.018,12,8),C.sand,-.13,.39,0,g));
 return {g,fan};
}
