// Icon names replaced by our own objects (made/own_<name>.png). Built by own_art.py.
const MAP = {"bell": "bell", "calendar": "calendar", "chat": "chat", "clock": "clock", "computer": "computer", "credit-card": "credit_card", "file": "file", "file-text": "file", "folder": "folder", "key": "key", "link": "link", "lock": "lock", "mail": "mail", "megaphone": "megaphone", "mobile": "mobile", "money": "money", "puzzle": "puzzle", "setting": "setting", "shield": "shield", "tick": "tick", "tools": "tools", "wifi": "wifi", "zoom": "zoom"};
export const OWN = new Set(Object.keys(MAP));
export const iconSrc = name => MAP[name] ? 'made/own_' + MAP[name] : 'icons3d/' + name;
